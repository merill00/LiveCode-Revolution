~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
RevOnRockets ReadMe
by
Andre Garzia (soapdog@mac.com)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

RevOnRockets is an educational tool based on RevHTTP and some libraries. It provides an enviroment for web developers to use thus freeing them from the tedious task of mantaining an WebServer instalation. RevOnRockets is 100% transcript and it is compatible with RocketsCGI and LibCGI libraries. Develop from inside the IDE! Use the debugger! Put everything on a pendrive and develop on the Run! Learn about AJAX! 

Launch HTTP.rev and click start, then check the demos and the files!

RevHTTP is a web server.
RocketsCGI is a collection of libraries for building text file based CGI.
LibCGI is a library for building stack file based CGI.

Everything free!!!!

Check the stack scripts and button "http" script for fun coding!!!

Happy Solstice!
Andre