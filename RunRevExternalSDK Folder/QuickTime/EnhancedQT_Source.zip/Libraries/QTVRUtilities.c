/*
 *  QTVRUtilities.c
 *  EnhancedQT
 *
 *  Taken from sample code at the Apple site with slight modifications.
 *
 */

#include "QTVRUtilities.h"


//////////
//
// QTVRUtils_GetHotSpotAtomData
// Get a pointer to the hot spot atom data for hot spot having the specified hot spot ID in the specified node.
//
//////////
OSErr QTVRUtils_GetHotSpotAtomData (QTVRInstance theInstance, UInt32 theNodeID, UInt32 theHotSpotID, QTVRHotSpotInfoAtomPtr theHotSpotInfoPtr)
{
    QTAtomContainer			myNodeInfo;
    QTAtom				myHSParentAtom;
    OSErr				myErr = noErr;

    // (1) the node information atom container contains a *hot spot parent atom*;
    // (2) the hot spot parent atom contains one or more *hot spot atoms*;
    // (3) the hot spot atom contains two children, a *general hot spot information atom*
    //     and a *specific hot spot information atom*.
    // We want to return a pointer to the general hot spot information atom data.
    // get the node information atom container for the specified node
    myErr = QTVRGetNodeInfo(theInstance, theNodeID, &myNodeInfo);
    if (myErr != noErr)
        return(myErr);

    // get the single hot spot parent atom in the node information atom container
    myHSParentAtom = QTFindChildByID(myNodeInfo, kParentAtomIsContainer, kQTVRHotSpotParentAtomType, 1, NULL);
    if (myHSParentAtom != 0) {
        QTAtom		myHSAtom;

        // get the hot spot atom whose atom ID is the specified hot spot ID
        myHSAtom = QTFindChildByID(myNodeInfo, myHSParentAtom, kQTVRHotSpotAtomType, theHotSpotID, NULL);
        if (myHSAtom != 0) {
            QTAtom	myAtom;

            // get the single hot spot information atom in the hot spot atom
            myAtom = QTFindChildByIndex(myNodeInfo, myHSAtom, kQTVRHotSpotInfoAtomType, 1, NULL);
            if (myAtom != 0) {
                myErr = QTCopyAtomDataToPtr(myNodeInfo, myAtom, false, sizeof(QTVRHotSpotInfoAtom), theHotSpotInfoPtr, NULL);
            }
        } else {
            myErr = cannotFindAtomErr;
        }
    } else {
        myErr = cannotFindAtomErr;
    }

    QTDisposeAtomContainer(myNodeInfo);
    return(myErr);
}


//////////
//
// QTVRUtils_GetHotSpotName
// Return the name of the hot spot having the specified hot spot ID in the specified node.
// The caller is responsible for disposing of the pointer returned by this function (by calling free).
//
//////////
char *QTVRUtils_GetHotSpotName (QTVRInstance theInstance, UInt32 theNodeID, UInt32 theHotSpotID)
{
    QTVRHotSpotInfoAtom     myHotSpotAtomData;
    char                    *myHotSpotName = NULL;
    OSErr                   myErr = noErr;

    // get the hot spot information atom data
    myErr = QTVRUtils_GetHotSpotAtomData(theInstance, theNodeID, theHotSpotID, &myHotSpotAtomData);
    if (myErr == noErr) {
        QTAtomID                myNameAtomID;

        // get the atom ID of the name string atom
        myNameAtomID = EndianU32_BtoN(myHotSpotAtomData.nameAtomID);
        if (myNameAtomID != 0) {
            QTAtomContainer     myNodeInfo;
            QTAtom              myHSParentAtom;
            QTAtom              myHSAtom;
            QTAtom              myNameAtom = 0;

            // version 2.0 documentation says that the hot spot name is contained in a string atom
            // that is a sibling of the hot spot atom (that is, a child of the hot spot parent atom);
            // some other documents indicate that a string atom is always a sibling of the atom that
            // contains the reference (in this case, a sibling of the hot spot information atom, and
            // hence a child of the hot spot atom); we will look first in the hot spot atom and then
            // in the hot spot parent atom. The version 2.1 documentation corrects the earlier error.
            // Mea culpa!
            // get the hot spot parent atom and the hot spot atom
            myErr = QTVRGetNodeInfo(theInstance, theNodeID, &myNodeInfo);
            if (myErr == noErr) {
                myHSParentAtom = QTFindChildByID(myNodeInfo, kParentAtomIsContainer, kQTVRHotSpotParentAtomType, 1, NULL);
                if (myHSParentAtom != 0) {
                    myHSAtom = QTFindChildByID(myNodeInfo, myHSParentAtom, kQTVRHotSpotAtomType, theHotSpotID, NULL);
                    if (myHSAtom != 0) {
                        QTAtom  myParentAtom;

                        // look for a string atom that is a child of the hot spot atom
                        myParentAtom = myHSAtom;
                        // Modified the atom search for text atom with id = 1 rather than hotSpotID TREVOR
                        myNameAtom = QTFindChildByID(myNodeInfo, myParentAtom, kQTVRStringAtomType, (UInt32)1, NULL); //theHotSpotID, NULL);
                        
                        if (myNameAtom == 0) {
                            // no such atom in the hot spot atom; look in the hot spot parent atom
                            myParentAtom = myHSParentAtom;
                             // Modified the atom search for text atom with id = 1 rather than hotSpotID TREVOR
                            myNameAtom = QTFindChildByID(myNodeInfo, myParentAtom, kQTVRStringAtomType, (UInt32)1, NULL); //theHotSpotID, NULL);
                        }

                        if (myNameAtom != 0)
                            myHotSpotName = QTVRUtils_GetStringFromAtom(myNodeInfo, myParentAtom, myNameAtomID);   
                    }
                }
            }
            
            QTDisposeAtomContainer(myNodeInfo);
        }
    }

    return(myHotSpotName);
}


//////////
//
// QTVRUtils_GetHotSpotComment
// Return the comment of the hot spot having the specified hot spot ID in the specified node.
// The caller is responsible for disposing of the pointer returned by this function (by calling free).
//
//////////
char *QTVRUtils_GetHotSpotComment (QTVRInstance theInstance, UInt32 theNodeID, UInt32 theHotSpotID)
{
    QTVRHotSpotInfoAtom     myHotSpotAtomData;
    char                    *myHotSpotComment = NULL;
    OSErr                   myErr = noErr;

    // get the hot spot information atom data
    myErr = QTVRUtils_GetHotSpotAtomData(theInstance, theNodeID, theHotSpotID, &myHotSpotAtomData);
    if (myErr == noErr) {
        QTAtomID                myCommentAtomID;

        // get the atom ID of the name string atom
        myCommentAtomID = EndianU32_BtoN(myHotSpotAtomData.commentAtomID);
		
        if (myCommentAtomID != 0) {
            QTAtomContainer     myNodeInfo;
            QTAtom              myHSParentAtom;
            QTAtom              myHSAtom;
            QTAtom              myNameAtom = 0;

            // version 2.0 documentation says that the hot spot name is contained in a string atom
            // that is a sibling of the hot spot atom (that is, a child of the hot spot parent atom);
            // some other documents indicate that a string atom is always a sibling of the atom that
            // contains the reference (in this case, a sibling of the hot spot information atom, and
            // hence a child of the hot spot atom); we will look first in the hot spot atom and then
            // in the hot spot parent atom. The version 2.1 documentation corrects the earlier error.
            // Mea culpa!
            // get the hot spot parent atom and the hot spot atom
            myErr = QTVRGetNodeInfo(theInstance, theNodeID, &myNodeInfo);
            if (myErr == noErr) {
                myHSParentAtom = QTFindChildByID(myNodeInfo, kParentAtomIsContainer, kQTVRHotSpotParentAtomType, 1, NULL);
                if (myHSParentAtom != 0) {
                    myHSAtom = QTFindChildByID(myNodeInfo, myHSParentAtom, kQTVRHotSpotAtomType, theHotSpotID, NULL);
                    if (myHSAtom != 0) {
                        QTAtom  myParentAtom;

                        // look for a string atom that is a child of the hot spot atom
                        myParentAtom = myHSAtom;
                        // Modified the atom search for text atom with id = 3 rather than hotSpotID TREVOR
                        myNameAtom = QTFindChildByID(myNodeInfo, myParentAtom, kQTVRStringAtomType, (UInt32)1, NULL); //theHotSpotID, NULL);
                        
                        if (myNameAtom == 0) {
                            // no such atom in the hot spot atom; look in the hot spot parent atom
                            myParentAtom = myHSParentAtom;
                             // Modified the atom search for text atom with id = 3 rather than hotSpotID TREVOR
                            myNameAtom = QTFindChildByID(myNodeInfo, myParentAtom, kQTVRStringAtomType, (UInt32)1, NULL); //theHotSpotID, NULL);
                        }

                        if (myNameAtom != 0)
                            myHotSpotComment = QTVRUtils_GetStringFromAtom(myNodeInfo, myParentAtom, myCommentAtomID);   
                    }
                }
            }
            
            QTDisposeAtomContainer(myNodeInfo);
        }
    }

    return(myHotSpotComment);
}


//////////
//
// QTVRUtils_GetStringFromAtom
// Get the string data from the string atom having the specified ID in the specified atom container.
//
// We use a different strategy here, since we don't know the size of the string data in advance.
//
//////////
char *QTVRUtils_GetStringFromAtom (QTAtomContainer theContainer, QTAtom theParent, QTAtomID theID)
{
    QTVRStringAtomPtr	myStringAtomPtr = NULL;
    QTAtom		myNameAtom;
    char		*myString = NULL;
    OSErr		myErr = noErr;

    if (theContainer == NULL)
        return(myString);

    QTLockContainer(theContainer);
    myNameAtom = QTFindChildByID(theContainer, theParent, kQTVRStringAtomType, theID, NULL);
    if (myNameAtom != 0) {
        myErr = QTGetAtomDataPtr(theContainer, myNameAtom, NULL, (Ptr *)&myStringAtomPtr);
        if ((myErr == noErr) && (myStringAtomPtr != NULL)) {
            UInt16		myLength;
            
            myLength = EndianU16_BtoN(myStringAtomPtr->stringLength);
            if (myLength > 0) {
                myString = malloc(myLength + 1); 
                if (myString != NULL) {
                    memcpy(myString, myStringAtomPtr->theString, myLength);
                    myString[myLength] = '\0';
                }
            }
        }
    }

    QTUnlockContainer(theContainer);

    return(myString);
}
