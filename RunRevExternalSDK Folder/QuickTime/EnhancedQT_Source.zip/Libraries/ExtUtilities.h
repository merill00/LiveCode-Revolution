/*
 *  ExtUtilities.h
 *  QTExternal
 *
 *  Created by Trevor DeVore on Mon Dec 08 2003.
 *
 */

#ifndef _EXTUTILITIES_
#define _EXTUTILITIES_

#include <ctype.h>

#ifdef WIN32
#include <Movies.h>
#undef snprintf
#define snprintf _snprintf
#endif

void 			ExtUtils_Path2Native(char *dptr);
OSErr			ExtUtils_Path2FSSpec(const char *fname, FSSpec *fspec);
void			ExtUtils_ToLowerCase(char *strptr);
void			DispatchRevolutionMessage(char *messagename, char *tmessage);
void			DispatchRevolutionMessageToObject(char *objectname, char *messagename, char *tmessage);
void			DispatchRevMsgToObjWith2Params(char *objectname, char *messagename, char *tmessage1, char *tmessage2);

#endif

#if defined(TARGET_OS_MAC) && defined(DEBUG)
#define debugassert(x, y) { if (x) DebugStr(y); }
#define debugmessage(x) { DebugStr(x); }
#else
#define debugassert(x, y)
#define debugmessage(x)
#endif // defined(TARGET_OS_MAC) && defined(DEBUG)
