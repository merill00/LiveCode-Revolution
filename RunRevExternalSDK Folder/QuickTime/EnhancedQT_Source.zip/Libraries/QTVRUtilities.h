/*
 *  QTVRUtilities.h
 *  EnhancedQT
 *
 *  Created by Trevor DeVore on Tue Dec 16 2003.
 *  Copyright (c) 2003 __MyCompanyName__. All rights reserved.
 *
 */

#ifndef _QTVRUTILITIES_
#define _QTVRUTILITIES_

#include <math.h>
#include <stdlib.h>
#include <string.h>

#include <Movies.h>
#include <QuickTimeVRFormat.h>


char *			QTVRUtils_GetHotSpotName (QTVRInstance theInstance, UInt32 theNodeID, UInt32 theHotSpotID);
char *			QTVRUtils_GetHotSpotComment (QTVRInstance theInstance, UInt32 theNodeID, UInt32 theHotSpotID);
char *			QTVRUtils_GetStringFromAtom (QTAtomContainer theContainer, QTAtom theParent, QTAtomID theID);
OSErr 			QTVRUtils_GetHotSpotAtomData (QTVRInstance theInstance, UInt32 theNodeID, UInt32 theHotSpotID, QTVRHotSpotInfoAtomPtr theHotSpotInfoPtr);
#endif


