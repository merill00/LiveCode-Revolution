/*
 *  QTUtilities.c
 *  QTExternal
 *
 *  Created by Trevor DeVore on Mon Dec 08 2003.
 *  Includes code form Apple QuickTime example projects.
 *  Includes code based on examples by Steve Israelson of Totally Hip.
 *  Copyright (c) 2003 Blue Mango Multimedia. All rights reserved.
 *
 */

#include "QTUtilities.h"
#include "QuickTimeComponents.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../XCmdGlue.h"

//////////
//
// QTUtils_AddEffectToMovieSegment
// Add the specified effect to occur at the specified time and duration.
//
//////////

OSErr QTUtils_AddEffectToMovieSegment (Movie theMovie, OSType theEffectType, long theNumSources, TimeValue theStartTime, TimeValue theDuration)
{
    Track                           myVidTrack1 = NULL;
    Track                           myVidTrack2 = NULL;
    Track                           mySrcTrack1 = NULL;
    Track                           mySrcTrack2 = NULL;
    Media                           mySrcMedia1 = NULL;
    Media                           mySrcMedia2 = NULL;
    Track                           myEffectTrack = NULL;
    Media                           myEffectMedia = NULL;
    Fixed                           myWidth, myHeight;
    TimeScale                       myTimeScale;
    TimeValue                       mySampleTime;
    Rect                            myRect;
    QTAtomContainer                 myInputMap = NULL;
    QTAtomContainer                 myEffectDesc = NULL;
    ImageDescriptionHandle          mySampleDesc = NULL;
    OSType                          myEffectName1 = kSourceNoneName;
    OSType                          myEffectName2 = kSourceNoneName;
    short                           myLayer;
    OSErr                           myErr = noErr;
    
    // make sure we were passed a valid movie
    if (theMovie == NULL)
            return(paramErr);
            
    //////////
    //
    // get some information about the movie
    //
    //////////
    
    myTimeScale = GetMovieTimeScale(theMovie);
    GetMovieBox(theMovie, &myRect);
    myLayer = QTUtils_GetFrontmostTrackLayer(theMovie, VideoMediaType);
    
    myWidth = IntToFixed((myRect.right - myRect.left));
    myHeight = IntToFixed((myRect.bottom - myRect.top));

    //////////
    //
    // retrieve the original video track(s), create the effect's source track(s) and media,
    // then set the new source track(s) to reference the data in the original video track(s)
    //
    //////////
    
    switch (theNumSources) {
            case 2:
                    myVidTrack2 = GetMovieIndTrackType(theMovie, 2, VideoMediaType, movieTrackMediaType | movieTrackEnabledOnly);
                    if (myVidTrack2 == NULL)
                            return(paramErr);
                    
                    mySrcTrack2 = NewMovieTrack(theMovie, myWidth, myHeight, kNoVolume);
                    if (mySrcTrack2 == NULL)
                            return(paramErr);
                            
                    mySrcMedia2 = NewTrackMedia(mySrcTrack2, VideoMediaType, myTimeScale, NULL, 0);
                    if (mySrcMedia2 == NULL)
                            return(paramErr);

#if COPY_MOVIE_MEDIA
                    myErr = BeginMediaEdits(mySrcMedia2);
                    if (myErr != noErr)
                            return(myErr);
#endif			
                    myErr = CopyTrackSettings(myVidTrack2, mySrcTrack2);
                    myErr = InsertTrackSegment(myVidTrack2, mySrcTrack2, theStartTime, theDuration, theStartTime);
                    if (myErr != noErr)
                            return(myErr);

#if COPY_MOVIE_MEDIA
                    EndMediaEdits(mySrcMedia2);
#endif			
                    myEffectName2 = kSourceTwoName;
                    
                    // note that we fall through here!
                            
            case 1:
                    myVidTrack1 = GetMovieIndTrackType(theMovie, 1, VideoMediaType, movieTrackMediaType | movieTrackEnabledOnly);
                    if (myVidTrack1 == NULL)
                            return(paramErr);
                            
                    mySrcTrack1 = NewMovieTrack(theMovie, myWidth, myHeight, kNoVolume);
                    if (mySrcTrack1 == NULL)
                            return(paramErr);
                            
                    mySrcMedia1 = NewTrackMedia(mySrcTrack1, VideoMediaType, myTimeScale, NULL, 0);
                    if (mySrcMedia1 == NULL)
                            return(paramErr);

#if COPY_MOVIE_MEDIA
                    myErr = BeginMediaEdits(mySrcMedia1);
                    if (myErr != noErr)
                            return(myErr);
#endif			
                    myErr = CopyTrackSettings(myVidTrack1, mySrcTrack1);
                    myErr = InsertTrackSegment(myVidTrack1, mySrcTrack1, theStartTime, theDuration, theStartTime);
                    if (myErr != noErr)
                            return(myErr);
                    
#if COPY_MOVIE_MEDIA
                    EndMediaEdits(mySrcMedia1);
#endif			
                    myEffectName1 = kSourceOneName;
                    
                    break;
                    
            case 0:
                    // for 0-source effects, we don't need to create a new source track
                    break;
    
            default:
                    return(paramErr);
    }
    
    //////////
    //
    // create the effects track and media
    //
    //////////

    myEffectTrack = NewMovieTrack(theMovie, myWidth, myHeight, kNoVolume);
    if (myEffectTrack == NULL)
            return(GetMoviesError());
            
    myEffectMedia = NewTrackMedia(myEffectTrack, VideoMediaType, myTimeScale, NULL, 0);
    if (myEffectMedia == NULL)
            return(GetMoviesError());
    
    // create an effect sample description
    mySampleDesc = QTUtils_MakeSampleDescription(theEffectType, FixedToInt(myWidth), FixedToInt(myHeight));
    if (mySampleDesc == NULL)
            goto bail;

    // create an effect description
    myEffectDesc = QTUtils_CreateEffectDescription(theEffectType, myEffectName1, myEffectName2, kSourceNoneName);

    // add the effect description as a sample to the effects track media
    BeginMediaEdits(myEffectMedia);

    myErr = AddMediaSample(myEffectMedia, (Handle)myEffectDesc, 0, GetHandleSize((Handle)myEffectDesc), theDuration, (SampleDescriptionHandle)mySampleDesc, 1, 0, &mySampleTime);
    if (myErr != noErr)
            goto bail;

    EndMediaEdits(myEffectMedia);
    
    // add the media sample to the effects track
    myErr = InsertMediaIntoTrack(myEffectTrack, theStartTime, mySampleTime, theDuration, fixed1);
    if (myErr != noErr)
            goto bail;

    //////////
    //
    // create the input map and add references for the source track(s)
    //
    //////////

    myErr = QTNewAtomContainer(&myInputMap);
    if (myErr != noErr)
            goto bail;
    
    if (mySrcTrack1 != NULL) {	
            myErr = QTUtils_AddTrackReferenceToInputMap(myInputMap, myEffectTrack, mySrcTrack1, kSourceOneName);
            if (myErr != noErr)
                    goto bail;
    }
            
    if (mySrcTrack2 != NULL) {	
            myErr = QTUtils_AddTrackReferenceToInputMap(myInputMap, myEffectTrack, mySrcTrack2, kSourceTwoName);
            if (myErr != noErr)
                    goto bail;
    }
            
    // add the input map to the effects track
    myErr = SetMediaInputMap(myEffectMedia, myInputMap);
    if (myErr != noErr)
            goto bail;

    //////////
    //
    // do any required positioning and graphics mode manipulation
    //
    //////////

    SetTrackLayer(myEffectTrack, myLayer - 1);	// in front of any existing video track
    
    switch (theNumSources) {
            case 2:
                    break;
                    
            case 1:
                    break;
                    
            case 0: {
                    RGBColor	myColor;
                    
                    myColor.red = 0;		// (good for fire, not so good for clouds)
                    myColor.green = 0;
                    myColor.blue = 0;
                    
                    MediaSetGraphicsMode(GetMediaHandler(myEffectMedia), transparent, &myColor);
                    break;
            }
    }
    
bail:
    if (mySampleDesc != NULL)
            DisposeHandle((Handle)mySampleDesc);
    
    if (myInputMap != NULL)
            QTDisposeAtomContainer(myInputMap);
    
    return(myErr);
}


//////////
//
// QTUtils_AddTrackReferenceToInputMap
// Add a track reference to the specified input map.
// 
//////////
OSErr QTUtils_AddTrackReferenceToInputMap (QTAtomContainer theInputMap, Track theTrack, Track theSrcTrack, OSType theSrcName)
{
    QTAtom                      myInputAtom;
    long                        myRefIndex;
    OSType                      myType;
    OSErr                       myErr = noErr;
    
    myErr = AddTrackReference(theTrack, theSrcTrack, kTrackReferenceModifier, &myRefIndex);
    if (myErr != noErr)
        goto bail;
    
    // add a reference atom to the input map
    myErr = QTInsertChild(theInputMap, kParentAtomIsContainer, kTrackModifierInput, myRefIndex, 0, 0, NULL, &myInputAtom);
    if (myErr != noErr)
        goto bail;
    
    // add two child atoms to the parent reference atom
    myType = EndianU32_NtoB(kTrackModifierTypeImage);
    myErr = QTInsertChild(theInputMap, myInputAtom, kTrackModifierType, 1, 0, sizeof(myType), &myType, NULL);
    if (myErr != noErr)
        goto bail;
    
    myType = EndianU32_NtoB(theSrcName);
    myErr = QTInsertChild(theInputMap, myInputAtom, kEffectDataSourceType, 1, 0, sizeof(myType), &myType, NULL);
bail:
    return(myErr);
}


//////////
//
// QTUtils_CreateEffectDescription
// Create an effect description for zero, one, two, or three sources.
// 
// The effect description specifies which video effect is desired and the parameters for that effect.
// It also describes the source(s) for the effect. An effect description is simply an atom container
// that holds atoms with the appropriate information.
//
// Note that because we are creating an atom container, we must pass big-endian data (hence the calls
// to EndianU32_NtoB).
//
// The caller is responsible for disposing of the returned atom container, by calling QTDisposeAtomContainer.
//
//////////
QTAtomContainer QTUtils_CreateEffectDescription (OSType theEffectType, OSType theSourceName1, OSType theSourceName2, OSType theSourceName3)
{
    QTAtomContainer		myEffectDesc = NULL;
    OSType                      myType = EndianU32_NtoB(theEffectType);
    OSErr                       myErr = noErr;
    
    // create a new, empty effect description
    myErr = QTNewAtomContainer(&myEffectDesc);
    if (myErr != noErr)
        goto bail;
    
    // create the effect ID atom: the atom type is kParameterWhatName, and the atom ID is kParameterWhatID
    myErr = QTInsertChild(myEffectDesc, kParentAtomIsContainer, kParameterWhatName, kParameterWhatID, 0, sizeof(myType), &myType, NULL);
    if (myErr != noErr)
        goto bail;
    
    // add the first source
    if (theSourceName1 != kSourceNoneName) {
        myType = EndianU32_NtoB(theSourceName1);
        myErr = QTInsertChild(myEffectDesc, kParentAtomIsContainer, kEffectSourceName, 1, 0, sizeof(myType), &myType, NULL);
        if (myErr != noErr)
            goto bail;
    }
    
    // add the second source
    if (theSourceName2 != kSourceNoneName) {
        myType = EndianU32_NtoB(theSourceName2);
        myErr = QTInsertChild(myEffectDesc, kParentAtomIsContainer, kEffectSourceName, 2, 0, sizeof(myType), &myType, NULL);
        if (myErr != noErr)
            goto bail;
    }
    
    // add the third source
    if (theSourceName3 != kSourceNoneName) {
        myType = EndianU32_NtoB(theSourceName3);
        myErr = QTInsertChild(myEffectDesc, kParentAtomIsContainer, kEffectSourceName, 3, 0, sizeof(myType), &myType, NULL);
    }
    bail:
        return(myEffectDesc);
}


//////////
//
// QTUtils_MakeSampleDescription
// Return a new image description with default and specified values.
// 
//////////
ImageDescriptionHandle QTUtils_MakeSampleDescription (OSType theEffectType, short theWidth, short theHeight)
{
    ImageDescriptionHandle		mySampleDesc = NULL;
    #if USES_MAKE_IMAGE_DESC_FOR_EFFECT
    OSErr                               myErr = noErr;
    
    // create a new sample description
    myErr = MakeImageDescriptionForEffect(theEffectType, &mySampleDesc);
    if (myErr != noErr)
        return(NULL);
#else
    
    // create a new sample description
    mySampleDesc = (ImageDescriptionHandle)NewHandleClear(sizeof(ImageDescription));
    if (mySampleDesc == NULL)
        return(NULL);
    
    // fill in the fields of the sample description
    (**mySampleDesc).cType = theEffectType;
    (**mySampleDesc).idSize = sizeof(ImageDescription);
    (**mySampleDesc).hRes = 72L << 16;
    (**mySampleDesc).vRes = 72L << 16;
    (**mySampleDesc).frameCount = 1;
    (**mySampleDesc).depth = 0;
    (**mySampleDesc).clutID = -1;
#endif
    (**mySampleDesc).vendor = kAppleManufacturer;
    (**mySampleDesc).temporalQuality = codecNormalQuality;
    (**mySampleDesc).spatialQuality = codecNormalQuality;
    (**mySampleDesc).width = theWidth;
    (**mySampleDesc).height = theHeight;
            return(mySampleDesc);
}


//////////
//
// QTUtils_GetFrontmostTrackLayer
// Return the layer number of the frontmost track of the specified kind in a movie.
// 
//////////
short QTUtils_GetFrontmostTrackLayer (Movie theMovie, OSType theTrackType)
{
    short		myLayer = 0;
    short		myIndex = 1;
    Track		myTrack = NULL;
    
    // get the layer number of the first track of the specified kind;
    // if no track of that kind exists in the movie, return 0
    myTrack = GetMovieIndTrackType(theMovie, 1, theTrackType, movieTrackMediaType | movieTrackEnabledOnly);
    
    if (myTrack == NULL)
        return(myLayer);
    myLayer = GetTrackLayer(myTrack);
    
    // see if any of the remaining tracks have lower layer numbers
    while (myTrack != NULL) {
        if (myLayer > GetTrackLayer(myTrack))
            myLayer = GetTrackLayer(myTrack);
        myIndex++;
        myTrack = GetMovieIndTrackType(theMovie, myIndex, theTrackType, movieTrackMediaType | movieTrackEnabledOnly);
    }
    
    return(myLayer);
}


//////////
//
// QTText_CopyCStringToPascal
// Convert the source C string to a destination Pascal string as it's copied.
//
// The destination string will be truncated to fit into a Str255 if necessary.
// If the C string pointer is NULL, the Pascal string's length is set to zero.
//
// This routine is borrowed from CGlue.c, by Nick Kledzik.
//
//////////
void QTUtils_CopyCStringToPascal (const char *theSrc, Str255 theDst)
{
    short					myLength = 0;
    // handle case of overlapping strings
    if ((void *)theSrc == (void *)theDst) {
        unsigned char		*myCurDst = &theDst[1];
        unsigned char		myChar;
        myChar = *(const unsigned char *)theSrc++;
        while (myChar != '\0') {
            unsigned char	myNextChar;
            // use myNextChar so we don't overwrite what we are about to read
            myNextChar = *(const unsigned char *)theSrc++;
            *myCurDst++ = myChar;
            myChar = myNextChar;
            if (++myLength >= 255)
                break;
        }
    } else if (theSrc != NULL) {
        unsigned char		*myCurDst = &theDst[1];
        short 				myOverflow = 255;		// count down, so test it loop is faster
        register char		myTemp;
        // we can't do the K&R C thing of “while (*s++ = *t++)” because it will copy the trailing zero,
        // which might overrun the Pascal buffer; instead, we use a temp variable
        while ((myTemp = *theSrc++) != 0) {
            *(char *)myCurDst++ = myTemp;
            if (--myOverflow <= 0)
                break;
        }
        myLength = 255 - myOverflow;
    }
    // set the length of the destination Pascal string
    theDst[0] = myLength;
}


//////////
//
// QTUtils_ConvertCToPascalString
// Convert a C string into a Pascal string.
//
// The caller is responsible for disposing of the pointer returned by this function (by calling free).
//
//////////
StringPtr QTUtils_ConvertCToPascalString (char *theString)
{
    StringPtr	myString = malloc(min(strlen(theString) + 1, 256));
    short		myIndex = 0;
    while ((theString[myIndex] != '\0') && (myIndex < 255)) {
        myString[myIndex + 1] = theString[myIndex];
        myIndex++;
    }
    myString[0] = (unsigned char)myIndex;
    return(myString);
}

//////////
//
// QTUtils_ConvertPascalToCString
// Convert a Pascal string into a C string.
//
// The caller is responsible for disposing of the pointer returned by this function (by calling free).
//
//////////
char *QTUtils_ConvertPascalToCString (StringPtr theString)
{
	if (theString != NULL) {
		char    *myString = malloc(theString[0] + 1);
		short   myIndex = 0;

		for (myIndex = 0; myIndex < theString[0]; myIndex++)
			myString[myIndex] = theString[myIndex + 1];
		myString[theString[0]] = '\0';
		return(myString);
	} else {
		return NULL;
	}
}


//
// QT Track Functions
//


//////////
//
// QTText_CreateTrack
//
//////////

Track QTUtils_CreateTrack (Movie theMovie, Fixed theWidth, Fixed theHeight, short theVolume)
{
	Track                   myTextTrack = NULL;
	//MatrixRecord		myMatrix;
		
	
	//////////
	//
	// create the text track
	//
	//////////
        myTextTrack = NewMovieTrack(theMovie, theWidth, theHeight, theVolume);
	if (myTextTrack == NULL)
		goto bail;
		
	
	//////////
	//
	// figure out the track geometry
	//
	//////////
	//GetTrackMatrix(myTextTrack, &myMatrix);
	//TranslateMatrix(&myMatrix, 0, theHeight);
	//SetTrackMatrix(myTextTrack, &myMatrix);	
	SetTrackEnabled(myTextTrack, true);
	
	return (myTextTrack);

bail:
	return(myTextTrack);
}


//////////
//
// QTUtils_GetTrackName
// Get the name of the specified movie track.
//
// This routine is modelled on the one contained in Dispatch 2 from the Ice Floe;
// I've modified it to return a C string instead of a Pascal string.
//
// The caller is responsible for disposing of the pointer returned by this function (by calling free).
//
//////////

char *QTUtils_GetTrackName (Track theTrack)
{
	UserData			myUserData = NULL;
	char				*myString = NULL;
 	OSErr				myErr = noErr;

	// make sure we've got a track
	if (theTrack == NULL)
		return(NULL);
		
	// a track's name (if it has one) is stored in the track's user data
	myUserData = GetTrackUserData(theTrack);
	if (myUserData != NULL) {
		Handle			myHandle = NewHandle(0);

		// get the user data item of type kUserDataName;
		// the handle we pass to GetUserData is resized to contain the track name
		myErr = GetUserData(myUserData, myHandle, kUserDataName, 1);
		if (myErr == noErr) {
			long		myLength = GetHandleSize(myHandle);

			if (myLength > 0) {
				myString = malloc(myLength + 1);
				if (myString != NULL) {
					memcpy(myString, *myHandle, myLength);
					myString[myLength] = '\0';
				}
			}			
		}	

		DisposeHandle(myHandle);
	}

	return(myString);
}


//////////
//
// QTUtils_SetTrackName
// Set the name of the specified movie track.
//
// This function adds the specified text to the track's user data;
// the updated user data is written to the movie file when the movie is next updated
// (by calling UpdateMovieResource).
//
//////////

OSErr QTUtils_SetTrackName (Track theTrack, char *theText)
{
    UserData			myUserData = NULL;
    OSErr				myErr = noErr;
    
    // make sure we've got a track and a name
    if ((theTrack == NULL) || (theText == NULL))
        return(paramErr);
    
    // get the track's user data list
    myUserData = GetTrackUserData(theTrack);
    if (myUserData == NULL)
        return(paramErr);
    
    // remove any existing track name
    while (RemoveUserData(myUserData, kUserDataName, 1) == noErr)
        ;
    
    myErr = SetUserDataItem(myUserData, theText, strlen(theText), kUserDataName, 0);
    
    return(myErr);
}


// Extracts a track from a movie, creates a new movie, places the track in it and
// copies it to the scrap
OSErr QTUtils_CreateNewMovieOnScrapFromTrack (Track srcTrack)
{
    Movie		myNewMovie = NULL;
    Track		myNewTrack = NULL;
    Media		srcMedia = NULL;
    Media		myNewMedia = NULL;
    Fixed		srcWidth = 0;
    Fixed		srcHeight = 0;
    TimeValue		myStartTime = 0;
    TimeValue		myEndTime = 0;
    OSType		srcMediaType = NULL;
    OSErr 		myErr = noErr;

    // Create new movie to store track in
    myNewMovie = NewMovie(0L);

    //myErr = AddEmptyTrackToMovie (srcTrack, myNewMovie, NULL, 0, &myNewTrack);
    //myErr = AddClonedTrackToMovie (srcTrack, myNewMovie, , &myNewTrack);

    // Get current track properties
    GetTrackDimensions (srcTrack, &srcWidth, &srcHeight);    
    myEndTime = GetTrackDuration (srcTrack);
    srcMedia = GetTrackMedia(srcTrack);
    GetMediaHandlerDescription(srcMedia, &srcMediaType, NULL, NULL);

    // Create new track and add to movie
    myNewTrack = NewMovieTrack(myNewMovie, srcWidth, srcHeight, GetTrackVolume(srcTrack));
    myNewMedia = NewTrackMedia (myNewTrack, srcMediaType, GetMediaTimeScale(srcMedia), NULL, 0);

    BeginMediaEdits(myNewMedia);
    myErr = InsertTrackSegment(srcTrack, myNewTrack, myStartTime, myEndTime, myStartTime);
    EndMediaEdits(myNewMedia);
      
    // Copy movie to scrap
    PutMovieOnScrap(myNewMovie, 0L);
    DisposeMovie(myNewMovie);

    return myErr;
}



//
// User data functions
//

//////////
//
// QTUtils_AddUserDataTextToMovie
// Add a user data item, of the specified type, containing the specified text to a movie.
//
// This function adds the specified text to the movie's user data;
// the updated user data is written to the movie file when the movie is next updated
// (by calling UpdateMovieResource).
//
//////////
OSErr QTUtils_AddUserDataTextToMovie (Movie theMovie, char *theText, OSType theType)
{
    UserData                myUserData = NULL;
    Handle                  myHandle = NULL;
    long                    myLength = strlen(theText);
    OSErr                   myErr = noErr;

    // get the movie's user data list
    myUserData = GetMovieUserData(theMovie);
    if (myUserData == NULL)
        return(paramErr);
    // copy the specified text into a new handle
    myHandle = NewHandleClear(myLength);
    if (myHandle == NULL)
        return(MemError());
    BlockMoveData(theText, *myHandle, myLength);

    // for simplicity, we assume that we want only one user data item of the specified type in the movie;
    // as a result, we won't worry about overwriting any existing item of that type....
    //
    // if you need multiple user data items of a given type (for example, a copyright notice
    // in several different languages), you would need to modify this code; this is left as an exercise
    // for the reader....
    // add the data to the movie's user data
    myErr = AddUserDataText(myUserData, myHandle, theType, 1, (short)GetScriptManagerVariable(smRegionCode));

    // clean up
    DisposeHandle(myHandle);
    return(myErr);
}


//////////
//
// GetUserDataTextFromMovie
// Get a user data item, of the specified type from a movie.
//
//////////
char *QTUtils_GetUserDataTextFromMovie (Movie theMovie, OSType theType)
{
    UserData		myUserData = NULL;
    char			*myString = NULL;
    Handle			myHandle = NULL;
    OSErr			myErr = noErr;

    // get the movie's user data list
    myUserData = GetMovieUserData(theMovie);
    if (myUserData != NULL)
    {
        myHandle = NewHandle(0);

        myErr = GetUserDataText(myUserData, myHandle, theType, 1, GetScriptManagerVariable(smRegionCode));
        if (myErr == noErr) {
            long myLength = GetHandleSize(myHandle);

            if (myLength > 0) {
                myString = malloc(myLength + 1);
                if (myString != NULL) {
                    // Move handle to C string
                    memcpy (myString, *myHandle, myLength);
                    //BlockMoveData(*myHandle, theText, myLength);
                    myString[myLength] = '\0';
                }
            }
        }

        // clean up
        DisposeHandle(myHandle);
    }
    else
    {
        myString = malloc(29);
        myString = "Unable to get movie user data";
    }

    return(myString);
}


//
// QT MovieController, Track and Media functions
//


//
// Returns the track with a given name
//
Track QTUtils_GetTrackReferenceByName (MovieController mc, char *trackName)
{
    Movie mv = NULL;
    long totalTracks = 0;
    int x = 0;
    if (!trackName)
      return NULL;

    if (mc != NULL && (long)mc > 0) {
        // Add error checking
        mv = MCGetMovie(mc);
        totalTracks = GetMovieTrackCount(mv);
        for (x = 1; x <= totalTracks; ++x)
        {
            Track curTrack = GetMovieIndTrack(mv, x);
            char name[256];
            Handle h = NewHandle(0);
            UserData ud = GetTrackUserData(curTrack);

            if (GetUserData(ud, h, kUserDataName, 1) == noErr)
            {
                long nameLength = GetHandleSize(h);
                if (nameLength > 255)
                    nameLength = 255;
                BlockMoveData(*h, name, nameLength);
                name[nameLength] = 0;
            }
            else
                name[0] = 0;
            DisposeHandle(h);

            if (strcmp(name, trackName) == 0)
                return curTrack;
        }
    }

    return NULL;
}


//
// Returns the media handler of the track with the given name
//
MediaHandler QTUtils_GetTrackMediaReferenceByName (MovieController mc, char *trackName)
{
    Track tk = NULL;
    Media md = NULL;
    MediaHandler mh = NULL;

    if (mc != NULL && (long)mc > 0) {
        // Add error checking
        tk = QTUtils_GetTrackReferenceByName (mc, trackName);

        if (tk != NULL)
        {
            md = GetTrackMedia(tk);
            mh = GetMediaHandler(md);
            return mh;
        }
    }

    return NULL;
}


//
// Returns the media handler of the track with the given index
//
MediaHandler QTUtils_GetTrackMediaReferenceByIndex (MovieController mc, long trackIndex)
{
    Movie mv = NULL;
    Track tr = NULL;
    Media md = NULL;
    MediaHandler mh = NULL;

    if (mc != NULL && (long)mc > 0) {
        mv = MCGetMovie(mc);
        tr = GetMovieTrack(mv, trackIndex);

        if (tr != NULL)
        {
            md = GetTrackMedia(tr);
            mh = GetMediaHandler(md);
            return mh;
        }
    }

    return NULL;
}


//
// Returns the media handler of the track with the given name
//
MediaHandler QTUtils_GetTrackMediaReferenceByType (Movie mv, long index, OSType trackType, long flags)
{
    Track tk = NULL;
    Media md = NULL;
    MediaHandler mh = NULL;

    if (mv != NULL) {
        // Add error checking
        tk = GetMovieIndTrackType (mv, index, trackType, flags);

        if (tk != NULL)
        {
            md = GetTrackMedia(tk);
            mh = GetMediaHandler(md);
            return mh;
        }
    }

    return NULL;
}


//
// Returns a movie controller given the long name of a player
//
MovieController QTUtils_GetRevPlayerMovieController (char *playerLongName)
{
    MovieController mc = NULL;
    char buffer[256];
    char *movieControllerID = NULL;
    int retvalue = 0;
    if (!playerLongName)
      return NULL;

    if (strlen(playerLongName) > 0)
    {
        sprintf(buffer, "the movieControllerID of %s", playerLongName);
        movieControllerID = (char *)EvalExpr(buffer, &retvalue);

        mc = (MovieController)atol(movieControllerID);

        return mc;
    }

    return NULL;
}


//
// Returns the name of a movie stored in the uMovieName property of the player
//
char *QTUtils_GetRevPlayerMovieName (char *playerLongName)
{
	char buffer[512];
    char *movieName = NULL;
    int retvalue = 0;
    if (!playerLongName)
      return NULL;

    if (strlen(playerLongName) > 0)
    {
        sprintf(buffer, "the uMovieName of %s", playerLongName);
        movieName = (char *)EvalExpr(buffer, &retvalue);
		return movieName;
    }

    return NULL;
}


//
// Atom Functions
//

// Checks an action Atom to see if it the supplied action.
Boolean QTUtils_CheckActionAtom(QTAtomContainer container, QTAtom curParent, long action)
{
    short index;
    long itsSize = 0;

    Ptr itsData;
    QTAtom theChild = QTFindChildByID(container, curParent, kWhichAction, 1, &index);
    if (theChild == 0)
        return false;


    QTGetAtomDataPtr(container, theChild, &itsSize, &itsData);

    if (itsSize == 4 && *((long*)itsData) == action)
        return true;

    return false;
}


// Gets the type and dat of an atom
QTAtom QTUtils_GetTypeAndData (QTAtomContainer container, QTAtom curParent, QTAtomType atomType, long index, long *atomSize, Ptr *atomData)
{
    QTAtomID itsID;
    QTAtom theChild = QTFindChildByIndex(container, curParent, atomType, index, &itsID);
    ComponentResult result = noErr;

    if (theChild != 0)
    {
        *atomSize = 0;
        result = QTGetAtomDataPtr(container, theChild, atomSize, atomData);
        if (result != noErr) {
            char buffer[1024];
            int retvalue;
            sprintf(buffer, "put \"Error getting type and data: %ld\" ", result);
            SendMCMessage(buffer, &retvalue);

			return 0;
        }
    }

    return theChild;
}


// Creates an offscreen GWorld with the image of the movie from the speicifed time/poster.  The address of the image as well as the
// image length is set in the imageAddress and imageLenght parameters.
void QTUtils_GetPixMapFromMovie (Movie theMovie, short *movieHeight, short *movieWidth, TimeValue theTime, Boolean usePoster, Boolean maintainAspectRatio, Ptr *imageAddress, long *imageLength)
{
#ifdef __MWERKS__
#pragma unused (maintainAspectRatio)
#endif // __MWERKS__

	GWorldPtr			theGWorld;
	Rect				movieRect;
	PicHandle			thePicHandle;
	PixMap *			myPixMap;
	CGrafPtr			oldPort;
	GDHandle			oldDevice;
	
	//
	// MODIFY THIS CODE
	// The height and width should be the extreme limits that are acceptable.  Code should adjust the height
	// and width so that the image stays within the given boundaries and maintains aspect ratio.
	// The final values are set in the *movieWidth and *movieHeight.
	//
				
	// If a height and width were provided then resize the movie, otherwise
	// use movie dimensions
	if (*movieHeight > 0) {		
		movieRect.left = 0;
		movieRect.top = 0;
		movieRect.right = *movieWidth;
		movieRect.bottom = *movieHeight;
		
		SetMovieBox(theMovie, &movieRect);
	} else {
		GetMovieBox(theMovie, &movieRect);
		*movieHeight = movieRect.bottom;
		*movieWidth = movieRect.right;
	}
	
	GetGWorld(&oldPort, &oldDevice);
	NewGWorld(&theGWorld, k32ARGBPixelFormat, &movieRect, NULL, NULL, 0);
	
	LockPixels(GetGWorldPixMap(theGWorld));
	SetGWorld(theGWorld, NULL);
	EraseRect(&movieRect);
	//SetMovieGWorld(theMovie, theGWorld, GetGWorldDevice(theGWorld));
	
	// Get poster image or point in time depending on request
	if (usePoster == true)
		thePicHandle = GetMoviePosterPict (theMovie);
	else
		thePicHandle = GetMoviePict (theMovie, theTime);
		
	DrawPicture(thePicHandle, &movieRect);
	
	SetGWorld(oldPort, oldDevice);

	myPixMap = *(GetGWorldPixMap(theGWorld));
	myPixMap->rowBytes = (movieRect.right - movieRect.left) * 4; // rowBytes is not set correctly.  Manually set it.
	
	// Pass the address and lenght of the image back to the caller
	*imageAddress = myPixMap->baseAddr; // GetPixBaseAddr(GetGWorldPixMap(theGWorld));
	*imageLength = (movieRect.right - movieRect.left) * (movieRect.bottom - movieRect.top) * 4;
	
	if (theGWorld != NULL)
		UnlockPixels(GetGWorldPixMap(theGWorld));

	// Get rid of the PicHandle
	if (thePicHandle != NULL)
		DisposeHandle((Handle)thePicHandle);
}


// Creates an offscreen GWorld with the image of the movie from the speicifed time/poster.  The address of the image as well as the
// image length is set in the imageAddress and imageLenght parameters.
OSErr QTUtils_SaveMoviePicToFile (Movie theMovie, short *movieHeight, short *movieWidth, TimeValue theTime, Boolean usePoster, Boolean maintainAspectRatio, FSSpec *saveToFile, OSType fileType, OSType fileCreator)
{
	GWorldPtr			theGWorld;
	Rect				movieRect;
	double				imgRatio = 0.0;
	PicHandle			thePicHandle;
	OSErr				myErr = noErr;
				
	// If a height and width were provided then resize the movie, otherwise
	// use movie dimensions
	if (*movieHeight > 0) {
		
		if (maintainAspectRatio == true) {
			GetMovieBox(theMovie, &movieRect);
			
			imgRatio = (double)movieRect.bottom / (double)movieRect.right;
			
			if (imgRatio <= 1) {
				// wider than taller or square
				if ((*movieWidth * imgRatio) > *movieHeight) {
					imgRatio = (double)movieRect.right / (double)movieRect.bottom;
					movieRect.right = (short)(*movieHeight * imgRatio);
					movieRect.bottom = (short)*movieHeight;
				} else {
					movieRect.right = (short)*movieWidth;
					movieRect.bottom = (short)(*movieWidth * imgRatio);
				}
			} else {
				// taller than wider
				if ((*movieHeight * imgRatio) > *movieWidth) {
					movieRect.right = (short)*movieWidth;
					movieRect.bottom = (short)(*movieWidth * imgRatio);
				} else {
					imgRatio = (double)movieRect.right / (double)movieRect.bottom;
					movieRect.right = (short)(*movieHeight * imgRatio);
					movieRect.bottom = (short)*movieHeight;
				}
			}
						
			// passed in values should reflect modified height and width values
			*movieWidth = movieRect.right;
			*movieHeight = movieRect.bottom;
		} else {		
			movieRect.left = 0;
			movieRect.top = 0;
			movieRect.right = *movieWidth;
			movieRect.bottom = *movieHeight;
		}
		
		SetMovieBox(theMovie, &movieRect);
	} else {
		GetMovieBox(theMovie, &movieRect);
		*movieHeight = movieRect.bottom;
		*movieWidth = movieRect.right;
	}
	NewGWorld(&theGWorld, k32ARGBPixelFormat, &movieRect, NULL, NULL, (GWorldFlags)0);
	
	SetGWorld(theGWorld, NULL);
	//SetMovieGWorld(theMovie, theGWorld, GetGWorldDevice(theGWorld));
	
	// Get poster image or point in time depending on request
	if (usePoster == true)
		thePicHandle = GetMoviePosterPict (theMovie);
	else
		thePicHandle = GetMoviePict (theMovie, theTime);
		
	EraseRect(&movieRect);
	DrawPicture(thePicHandle, &movieRect);
	
	myErr = QTUtils_ExportPic (thePicHandle, fileType, fileCreator, saveToFile);

	// Get rid of the PicHandle
	if (thePicHandle != NULL)
		DisposeHandle((Handle)thePicHandle);
		
	return myErr;
}


// Exports a PicHandle in the specified format to the specified file
OSErr QTUtils_ExportPic (PicHandle thePic, OSType fileType, OSType fileCreator, FSSpec *fileSpec)
{
	Handle						h;
    OSErr						err;
    GraphicsImportComponent		gi = 0;
			
	// Convert the picture handle into a PICT file (still in a handle) 
	// by adding a 512-byte header to the start.
	h = NewHandleClear(512);
	err = HandAndHand((Handle)thePic, h);
	
	err = OpenADefaultComponent(
				GraphicsImporterComponentType,
				kQTFileTypePicture,
				&gi);
	if (err) goto bail;
	
	err = GraphicsImportSetDataHandle(gi, h);
	if (err) goto bail;
	
	err = GraphicsImportExportImageFile(
				gi, 
				fileType, 
				fileCreator, 
				fileSpec, 
				smSystemScript);
	if (err) goto bail;
	
	bail:
	if (gi) CloseComponent(gi);
	if (h) DisposeHandle(h);
	return err;
}