//////////
//
//	File:		WiredSpriteUtilities.c
//
//	Contains:	Utilities for creating wired sprite media.
//
//	Written by:	Sean Allen
//	Revised by:	Chris Flick and Tim Monroe
//
//	Copyright:	� 1998-2001 by Apple Computer, Inc., all rights reserved.
//
//	Change History (most recent first):
//
//     <7>      02/21/03    era     kActionTrackSetClip takes a *RgnHandle as its parameter, not a RgnHandle (radar #3115855)
//	   <6>	 	02/28/01	rtm		added movie target utilities
//	   <5>	 	02/14/01	rtm		added QuickTime VR utilities; revised some other utilities
//	   <4>	 	02/02/01	rtm		general clean-up to bring this file into conformance with style of other
//									sample code; added some endian macros; removed some parameters from calls
//									(changes in the action parameters made them orphans)
//	   <3>	 	03/29/98	rtm		added Endian macros to theFlags parameter in WiredUtils_AddActionParameterOptions
//	   <2>	 	03/??/98	cf		added Endian macros
//	   <1>	 	12/??/97	sa		first file
//
//	NOTES:
//
//	***(1)***
//	You need to pay attention to the endianness of the data you pass to these routines. Wired sprite
//	media data is stored in QuickTime atoms and atom containers and must therefore be big-endian. We've
//	tried to conform to this rule: if the data to be written to a wired sprite media is 4 bytes or less,
//	then we will perform the endian swap for you. There are several exceptions to this rule; for instance,
//	we swap the data in any matrices you pass to the WiredUtils_AddSpriteSetMatrixAction function. But we
//	do not swap the data in any matrices passed to WiredUtils_AddActionParameterAtom (since we don't know
//	that they are matrices!). Let the caller beware!
//
//////////

#ifndef _WIREDSPRITEUTILITIES_
#include "WiredSpriteUtilities.h"
#endif


//////////
//
// WiredUtils_AddQTEventAtom
// Add an event atom of the specified type to the specified container. Return the new event atom to the caller.
//
// For an event of type kQTEventFrameLoaded, the theActionAtoms atom should be a sibling of a kSpriteAtomType.
//
//////////

OSErr WiredUtils_AddQTEventAtom (QTAtomContainer theContainer, QTAtom theActionAtoms, QTAtomID theQTEventType, QTAtom *theNewQTEventAtom)
{
	OSErr	myErr = noErr;
	
	if ((theContainer == NULL) || (theQTEventType == 0) || (theNewQTEventAtom == NULL)) {
		myErr = paramErr;
		goto bail;
	}
	
	if (theQTEventType == kQTEventFrameLoaded) {
		*theNewQTEventAtom = QTFindChildByID(theContainer, theActionAtoms, kQTEventFrameLoaded, 1, NULL);
		if (*theNewQTEventAtom == 0)
			myErr = QTInsertChild(theContainer, theActionAtoms, kQTEventFrameLoaded, 1, 1, 0, NULL, theNewQTEventAtom);
	} else {
		*theNewQTEventAtom = QTFindChildByID(theContainer, theActionAtoms, kQTEventType, theQTEventType, NULL);
		if (*theNewQTEventAtom == 0)
			myErr = QTInsertChild(theContainer, theActionAtoms, kQTEventType, theQTEventType, 1, 0, NULL, theNewQTEventAtom);
	}
	
bail:
	return(myErr);
}


//////////
//
// WiredUtils_AddActionAtom
// Add an action atom of the specified type to the specified container. Return the new event atom to the caller.
//
//////////

OSErr WiredUtils_AddActionAtom (QTAtomContainer theContainer, QTAtom theEventAtom, long theActionConstant, QTAtom *theNewActionAtom)
{
	QTAtom	myActionAtom = 0;
	OSErr	myErr = noErr;
	
	if ((theContainer == NULL) || (theActionConstant == 0)) {
		myErr = paramErr;
		goto bail;
	}
	
	myErr = QTInsertChild(theContainer, theEventAtom, kAction, 0, 0, 0, NULL, &myActionAtom);
	if (myErr != noErr)
		goto bail;

	theActionConstant = EndianU32_NtoB(theActionConstant);
	myErr = QTInsertChild(theContainer, myActionAtom, kWhichAction, 1, 1, sizeof(theActionConstant), &theActionConstant, NULL);
	
bail:
	if (theNewActionAtom != NULL) {
		if (myErr != noErr)	
			*theNewActionAtom = 0;
		else
			*theNewActionAtom = myActionAtom;
	}
	
	return(myErr);
}


//////////
//
// WiredUtils_AddActionParameterAtom
// Add a parameter atom of the specified type to the specified action atom. Return the new parameter atom to the caller.
//
// N.B. The caller is responsible for ensuring that the data passed in the theParamData parameter is in big-endian format!
// You've been warned!
//
//////////

OSErr WiredUtils_AddActionParameterAtom (QTAtomContainer theContainer, QTAtom theActionAtom, long theParameterIndex, long theParamDataSize, void *theParamData, QTAtom *theNewParamAtom)
{
	return(QTInsertChild(theContainer, theActionAtom, kActionParameter, 0, (short)theParameterIndex, theParamDataSize, theParamData, theNewParamAtom));
}


//////////
//
// WiredUtils_AddActionParameterOptions
// Add a parameter options atom to the specified action atom.
//
//////////

OSErr WiredUtils_AddActionParameterOptions (QTAtomContainer theContainer, QTAtom theActionAtom, QTAtomID theParamID, long theFlags, long theMinValueSize, void *theMinValue, long theMaxValueSize, void *theMaxValue)
{
	OSErr	myErr = noErr;

	theFlags = EndianU32_NtoB(theFlags);
	myErr = QTInsertChild(theContainer, theActionAtom, kActionFlags, theParamID, 0, sizeof(theFlags), &theFlags, NULL);
	if (myErr != noErr)
		goto bail;
		
	if (theMinValue != NULL)
		myErr = QTInsertChild(theContainer, theActionAtom, kActionParameterMinValue, theParamID, 0, theMinValueSize, theMinValue, NULL);

	if (theMaxValue != NULL)
		myErr = QTInsertChild(theContainer, theActionAtom, kActionParameterMaxValue, theParamID, 0, theMaxValueSize, theMaxValue, NULL);

bail:
	return(myErr);
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Target-setting utilities
//
// Use these functions to set track or sprite targets.
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////
//
// WiredUtils_AddMovieNameActionTargetAtom
// Add a target movie name atom to the specified action atom.
//
//////////

OSErr WiredUtils_AddMovieNameActionTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, Str255 theMovieName, QTAtom *theNewTargetAtom)
{
	QTAtom	myTargetAtom = 0;
	OSErr	myErr = noErr;
	
	if (theNewTargetAtom != NULL)
		*theNewTargetAtom = 0;
	
	myTargetAtom = QTFindChildByIndex(theContainer, theActionAtom, kActionTarget, 1, NULL);
	if (myTargetAtom == 0) {
		myErr = QTInsertChild(theContainer, theActionAtom, kActionTarget, 1, 1, 0, NULL, &myTargetAtom);
		if (myErr != noErr)
			goto bail;
	}
		
	myErr = QTInsertChild(theContainer, myTargetAtom, kTargetMovieName, 1, 1, theMovieName[0] + 1, theMovieName, NULL);

bail:
	if (theNewTargetAtom != NULL)
		*theNewTargetAtom = myTargetAtom;
	return(myErr);
}


//////////
//
// WiredUtils_AddMovieIDActionTargetAtom
// Add a target movie ID atom to the specified action atom.
//
//////////

OSErr WiredUtils_AddMovieIDActionTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, long theMovieID, QTAtom *theNewTargetAtom)
{
	QTAtom	myTargetAtom = 0;
	OSErr	myErr = noErr;
	
	if (theNewTargetAtom != NULL)
		*theNewTargetAtom = 0;
	
	myTargetAtom = QTFindChildByIndex(theContainer, theActionAtom, kActionTarget, 1, NULL);
	if (myTargetAtom == 0) {
		myErr = QTInsertChild(theContainer, theActionAtom, kActionTarget, 1, 1, 0, NULL, &myTargetAtom);
		if (myErr != noErr)
			goto bail;
	}
	
	theMovieID = EndianU32_NtoB(theMovieID);
	myErr = QTInsertChild(theContainer, myTargetAtom, kTargetMovieID, 1, 1, sizeof(theMovieID), &theMovieID, NULL);

bail:
	if (theNewTargetAtom != NULL)
		*theNewTargetAtom = myTargetAtom;
	return(myErr);
}


//////////
//
// WiredUtils_AddTrackNameActionTargetAtom
// Add a target track name atom to the specified action atom.
//
//////////

OSErr WiredUtils_AddTrackNameActionTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, Str255 theTrackName, QTAtom *theNewTargetAtom)
{
	QTAtom	myTargetAtom = 0;
	OSErr	myErr = noErr;
	
	if (theNewTargetAtom != NULL)
		*theNewTargetAtom = 0;
	
	myTargetAtom = QTFindChildByIndex(theContainer, theActionAtom, kActionTarget, 1, NULL);
	if (myTargetAtom == 0) {
		myErr = QTInsertChild(theContainer, theActionAtom, kActionTarget, 1, 1, 0, NULL, &myTargetAtom);
		if (myErr != noErr)
			goto bail;
	}
		
	myErr = QTInsertChild(theContainer, myTargetAtom, kTargetTrackName, 1, 1, theTrackName[0] + 1, theTrackName, NULL);

bail:
	if (theNewTargetAtom != NULL)
		*theNewTargetAtom = myTargetAtom;
	return(myErr);
}


//////////
//
// WiredUtils_AddTrackIDActionTargetAtom
// Add a target track ID atom to the specified action atom.
//
//////////

OSErr WiredUtils_AddTrackIDActionTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, long theTrackID, QTAtom *theNewTargetAtom)
{
	QTAtom	myTargetAtom = 0;
	OSErr	myErr = noErr;
	
	if (theNewTargetAtom != NULL)
		*theNewTargetAtom = 0;
	
	myTargetAtom = QTFindChildByIndex(theContainer, theActionAtom, kActionTarget, 1, NULL);
	if (myTargetAtom == 0) {
		myErr = QTInsertChild(theContainer, theActionAtom, kActionTarget, 1, 1, 0, NULL, &myTargetAtom);
		if (myErr != noErr)
			goto bail;
	}
	
	theTrackID = EndianU32_NtoB(theTrackID);
	myErr = QTInsertChild(theContainer, myTargetAtom, kTargetTrackID, 1, 1, sizeof(theTrackID), &theTrackID, NULL);

bail:
	if (theNewTargetAtom != NULL)
		*theNewTargetAtom = myTargetAtom;
	return(myErr);
}


//////////
//
// WiredUtils_AddTrackTypeActionTargetAtom
// Add a target track type atom to the specified action atom.
//
//////////

OSErr WiredUtils_AddTrackTypeActionTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, OSType theTrackType, QTAtom *theNewTargetAtom)
{
	QTAtom	myTargetAtom = 0;
	OSErr	myErr = noErr;
	
	if (theNewTargetAtom != NULL)
		*theNewTargetAtom = 0;
	
	myTargetAtom = QTFindChildByIndex(theContainer, theActionAtom, kActionTarget, 1, NULL);
	if (myTargetAtom == 0) {
		myErr = QTInsertChild(theContainer, theActionAtom, kActionTarget, 1, 1, 0, NULL, &myTargetAtom);
		if (myErr != noErr)
			goto bail;
	}
			
	theTrackType = EndianU32_NtoB(theTrackType);
	myErr = QTInsertChild(theContainer, myTargetAtom, kTargetTrackType, 1, 1, sizeof(theTrackType), &theTrackType, NULL);

bail:
	if (theNewTargetAtom != NULL)
		*theNewTargetAtom = myTargetAtom;
	return(myErr);
}


//////////
//
// WiredUtils_AddTrackIndexActionTargetAtom
// Add a target track index atom to the specified action atom.
//
//////////

OSErr WiredUtils_AddTrackIndexActionTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, long theTrackIndex, QTAtom *theNewTargetAtom)
{
	QTAtom	myTargetAtom = 0;
	OSErr	myErr = noErr;
	
	if (theNewTargetAtom != NULL)
		*theNewTargetAtom = 0;
	
	myTargetAtom = QTFindChildByIndex(theContainer, theActionAtom, kActionTarget, 1, NULL);
	if (myTargetAtom == 0) {
		myErr = QTInsertChild(theContainer, theActionAtom, kActionTarget, 1, 1, 0, NULL, &myTargetAtom);
		if (myErr != noErr)
			goto bail;
	}
			
	theTrackIndex = EndianU32_NtoB(theTrackIndex);
	myErr = QTInsertChild(theContainer, myTargetAtom, kTargetTrackIndex, 1, 1, sizeof(theTrackIndex), &theTrackIndex, NULL);

bail:
	if (theNewTargetAtom != NULL)
		*theNewTargetAtom = myTargetAtom;
	return(myErr);
}


//////////
//
// WiredUtils_AddSpriteNameActionTargetAtom
// Add a sprite name target atom to the specified action atom.
//
//////////

OSErr WiredUtils_AddSpriteNameActionTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, Str255 theSpriteName, QTAtom *theNewTargetAtom)
{
	QTAtom	myTargetAtom = 0;
	OSErr	myErr = noErr;
	
	if (theNewTargetAtom != NULL)
		*theNewTargetAtom = 0;
	
	myTargetAtom = QTFindChildByIndex(theContainer, theActionAtom, kActionTarget, 1, NULL);
	if (myTargetAtom == 0) {
		myErr = QTInsertChild(theContainer, theActionAtom, kActionTarget, 1, 1, 0, NULL, &myTargetAtom);
		if (myErr != noErr)
			goto bail;
	}

	myErr = QTInsertChild(theContainer, myTargetAtom, kTargetSpriteName, 1, 1, theSpriteName[0] + 1, theSpriteName, NULL);

bail:
	if (theNewTargetAtom != NULL)
		*theNewTargetAtom = myTargetAtom;
	return(myErr);
}


//////////
//
// WiredUtils_AddSpriteIDActionTargetAtom
// Add a sprite ID target atom to the specified action atom.
//
//////////

OSErr WiredUtils_AddSpriteIDActionTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, QTAtomID theSpriteID, QTAtom *theNewTargetAtom)
{
	QTAtom	myTargetAtom = 0;
	OSErr	myErr = noErr;
	
	if (theNewTargetAtom != NULL)
		*theNewTargetAtom = 0;
	
	myTargetAtom = QTFindChildByIndex(theContainer, theActionAtom, kActionTarget, 1, NULL);
	if (myTargetAtom == 0) {
		myErr = QTInsertChild(theContainer, theActionAtom, kActionTarget, 1, 1, 0, NULL, &myTargetAtom);
		if (myErr != noErr)
			goto bail;
	}

	theSpriteID = EndianU32_NtoB(theSpriteID);
	myErr = QTInsertChild(theContainer, myTargetAtom, kTargetSpriteID, 1, 1, sizeof(theSpriteID), &theSpriteID, NULL);

bail:
	if (theNewTargetAtom != NULL)
		*theNewTargetAtom = myTargetAtom;
	return(myErr);
}


//////////
//
// WiredUtils_AddSpriteIndexActionTargetAtom
// Add a sprite index target atom to the specified action atom.
//
//////////

OSErr WiredUtils_AddSpriteIndexActionTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, short theSpriteIndex, QTAtom *theNewTargetAtom)
{
	QTAtom	myTargetAtom = 0;
	OSErr	myErr = noErr;
	
	if (theNewTargetAtom != NULL)
		*theNewTargetAtom = 0;
	
	myTargetAtom = QTFindChildByIndex(theContainer, theActionAtom, kActionTarget, 1, NULL);
	if (myTargetAtom == 0) {
		myErr = QTInsertChild(theContainer, theActionAtom, kActionTarget, 1, 1, 0, NULL, &myTargetAtom);
		if (myErr != noErr)
			goto bail;
	}

	theSpriteIndex = EndianU16_NtoB(theSpriteIndex);
	myErr = QTInsertChild(theContainer, myTargetAtom, kTargetSpriteIndex, 1, 1, sizeof(theSpriteIndex), &theSpriteIndex, NULL);

bail:
	if (theNewTargetAtom != NULL)
		*theNewTargetAtom = myTargetAtom;
	return(myErr);
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// High-level utilities
//
// Use these functions to add event and action atoms, and to set movie, track, and sprite targets.
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////
//
// WiredUtils_AddQTEventAndActionAtoms
// Add event and action atoms to the specified atom.
//
//////////

OSErr WiredUtils_AddQTEventAndActionAtoms (QTAtomContainer theContainer, QTAtom theAtom, long theEvent, long theAction, QTAtom *theActionAtom)
{
	QTAtom	myEventAtom = 0;
	OSErr	myErr = noErr;
	
	myEventAtom = theAtom;
	
	if (theEvent != 0) {
		myErr = WiredUtils_AddQTEventAtom(theContainer, theAtom, theEvent, &myEventAtom);
		if (myErr != noErr)
			goto bail;
	}
	
	myErr = WiredUtils_AddActionAtom(theContainer, myEventAtom, theAction, theActionAtom);

bail:
	return(myErr);
}


//////////
//
// WiredUtils_AddMovieTargetAtom
// Add a movie target atom to the specified action atom.
//
//////////

OSErr WiredUtils_AddMovieTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, long theMovieTargetType, void *theMovieTarget)
{
	OSErr	myErr = noErr;
	
	// allow zero for the default target (the movie that received the event)
	if (theMovieTargetType != 0) {
		switch (theMovieTargetType) {
			case kTargetMovieName: {
				StringPtr myMovieName = (StringPtr)theMovieTarget;
				
				myErr = WiredUtils_AddMovieNameActionTargetAtom(theContainer, theActionAtom, myMovieName, NULL);
				break;
			}
				
			case kTargetMovieID: {
				long myMovieID = (long)theMovieTarget;
				
				myErr = WiredUtils_AddMovieIDActionTargetAtom(theContainer, theActionAtom, myMovieID, NULL);
				break;
			}

			default:
				myErr = paramErr; 
		}
	}
	
//bail:
	return(myErr);
}


//////////
//
// WiredUtils_AddTrackTargetAtom
// Add a track target atom to the specified action atom.
//
// trackTypeIndex only used if trackTargetType is kTargetTrackType; it can be zero for a default index of 1
//
//////////

OSErr WiredUtils_AddTrackTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, long theTrackTargetType, void *theTrackTarget, long theTrackTypeIndex)
{
	OSErr	myErr = noErr;
	
	// allow zero for the default target (the sprite track that received the event)
	if (theTrackTargetType != 0) {
		switch (theTrackTargetType) {
			case kTargetTrackName: {
				StringPtr myTrackName = (StringPtr)theTrackTarget;
				
				myErr = WiredUtils_AddTrackNameActionTargetAtom(theContainer, theActionAtom, myTrackName, NULL);
				break;
			}
				
			case kTargetTrackID: {
				long myTrackID = (long)theTrackTarget;
				
				myErr = WiredUtils_AddTrackIDActionTargetAtom(theContainer, theActionAtom, myTrackID, NULL);
				break;
			}

			case kTargetTrackType: {
				OSType myTrackType = (long)theTrackTarget;
				
				myErr = WiredUtils_AddTrackTypeActionTargetAtom(theContainer, theActionAtom, myTrackType, NULL);
				if (myErr != noErr)
					goto bail;
					
				if (theTrackTypeIndex != 0)
					myErr = WiredUtils_AddTrackIndexActionTargetAtom(theContainer, theActionAtom, theTrackTypeIndex, NULL);
				break;
			}
						
			case kTargetTrackIndex: {
				long myTrackIndex = (long)theTrackTarget;
				
				myErr = WiredUtils_AddTrackIndexActionTargetAtom(theContainer, theActionAtom, myTrackIndex, NULL);
				break;
			}
						
			default:
				myErr = paramErr; 
		}
	}
	
bail:
	return(myErr);
}


//////////
//
// WiredUtils_AddSpriteTargetAtom
// Add a sprite target atom to the specified action atom.
//
//////////

OSErr WiredUtils_AddSpriteTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, long theSpriteTargetType, void *theSpriteTarget)
{
	OSErr	myErr = noErr;
	
	// allow zero for the default target (the sprite that received the event)
	if (theSpriteTargetType != 0) {
		switch (theSpriteTargetType) {
			case kTargetSpriteName: {
				StringPtr mySpriteName = (StringPtr)theSpriteTarget;
				
				myErr = WiredUtils_AddSpriteNameActionTargetAtom(theContainer, theActionAtom, mySpriteName, NULL);
				break;
			}
				
			case kTargetSpriteID: {
				QTAtomID mySpriteID = (QTAtomID)theSpriteTarget;
				
				myErr = WiredUtils_AddSpriteIDActionTargetAtom(theContainer, theActionAtom, mySpriteID, NULL);
				break;
			}

			case kTargetSpriteIndex: {
				short mySpriteIndex = (short)theSpriteTarget;
				
				myErr = WiredUtils_AddSpriteIndexActionTargetAtom(theContainer, theActionAtom, mySpriteIndex, NULL);
				break;
			}
						
			default:
				myErr = paramErr; 
		}
	}
	
//bail:
	return(myErr);
}


//////////
//
// WiredUtils_AddTrackAndSpriteTargetAtoms
// Add track and sprite target atoms to the specified action atom.
//
//////////

OSErr WiredUtils_AddTrackAndSpriteTargetAtoms (QTAtomContainer theContainer, QTAtom theActionAtom, long theTrackTargetType, void *theTrackTarget, long theTrackTypeIndex, long theSpriteTargetType, void *theSpriteTarget)
{
	OSErr	myErr = noErr;
	
	myErr = WiredUtils_AddTrackTargetAtom(theContainer, theActionAtom, theTrackTargetType, theTrackTarget, theTrackTypeIndex);
	if (myErr != noErr)
		goto bail;

	myErr = WiredUtils_AddSpriteTargetAtom(theContainer, theActionAtom, theSpriteTargetType, theSpriteTarget);
	
bail:
	return(myErr);
}


//////////
//
// WiredUtils_AddMovieActionTargetAtom
// Add the movie as a target to the specified atom
//
//////////
OSErr WiredUtils_AddMovieActionTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, QTAtom *theNewTargetAtom)
{
    QTAtom	myTargetAtom = 0;
    OSErr	myErr = noErr;

    if (theNewTargetAtom != NULL)
        *theNewTargetAtom = 0;

    myTargetAtom = QTFindChildByIndex(theContainer, theActionAtom, kActionTarget, 1, NULL);
    if (myTargetAtom == 0) {
        myErr = QTInsertChild(theContainer, theActionAtom, kActionTarget, 1, 1, 0, NULL, &myTargetAtom);
        if (myErr != noErr)
            goto bail;
    }

    myErr = QTInsertChild(theContainer, myTargetAtom, kTargetMovie, 1, 1, NULL, NULL, NULL);

bail:
        if (theNewTargetAtom != NULL)
            *theNewTargetAtom = myTargetAtom;
    return(myErr);
}