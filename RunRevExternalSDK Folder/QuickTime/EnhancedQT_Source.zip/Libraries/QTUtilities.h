/*
 *  QTUtilities.h
 *  QTExternal
 *
 *  Created by Trevor DeVore on Mon Dec 08 2003.
 *  Uses code from QuickTime example files.
 *  Copyright (c) 2003 Blue Mango Multimedia. All rights reserved.
 *
 */

#ifndef _QTUTILITIES_
#define _QTUTILITIES_

#include <stdlib.h>
#include <Script.h>
#include <FixMath.h>

#include <Movies.h>
#include <ImageCodec.h>
#include <Sound.h>

//
// Compiler Macros
//
#ifndef min
#define min(a, b)					((a)<(b)?(a):(b))
#endif

//////////
//
// constants
//
//////////
#define kMaxNumSources                          3           // the maximum number of input tracks we will collect
#define kSourceOneName                          FOUR_CHAR_CODE('srcA')
#define kSourceTwoName                          FOUR_CHAR_CODE('srcB')
#define kSourceThreeName                        FOUR_CHAR_CODE('srcC')
#define kSourceNoneName                         FOUR_CHAR_CODE('srcZ')
#define kVideoTrackTimeScale			600

// QTEffects
OSErr                   QTUtils_AddEffectToMovieSegment (Movie theMovie, OSType theEffectType, long theNumSources, TimeValue theStartTime, TimeValue theDuration);
OSErr                   QTUtils_AddTrackReferenceToInputMap (QTAtomContainer theInputMap, Track theTrack, Track theSrcTrack, OSType theSrcName);
QTAtomContainer         QTUtils_CreateEffectDescription (OSType theEffectType, OSType theSourceName1, OSType theSourceName2, OSType theSourceName3);
ImageDescriptionHandle  QTUtils_MakeSampleDescription (OSType theEffectType, short theWidth, short theHeight);
short                   QTUtils_GetFrontmostTrackLayer (Movie theMovie, OSType theTrackType);

// QT String Functions
void				QTUtils_CopyCStringToPascal (const char *theSrc, Str255 theDst);
StringPtr			QTUtils_ConvertCToPascalString (char *theString);
char *				QTUtils_ConvertPascalToCString (StringPtr theString);

// QT Track Functions
Track				QTUtils_CreateTrack (Movie theMovie, Fixed theWidth, Fixed theHeight, short theVolume);
char *				QTUtils_GetTrackName (Track theTrack);
OSErr				QTUtils_SetTrackName (Track theTrack, char *theText);
OSErr				QTUtils_CreateNewMovieOnScrapFromTrack (Track srcTrack);

// User Data functions
OSErr				QTUtils_AddUserDataTextToMovie (Movie theMovie, char *theText, OSType theType);
char *				QTUtils_GetUserDataTextFromMovie (Movie theMovie, OSType theType);


// QT MovieController, Track and Media functions
Track				QTUtils_GetTrackReferenceByName (MovieController mc, char *trackName);
MediaHandler		QTUtils_GetTrackMediaReferenceByName (MovieController mc, char *trackName);
MediaHandler 		QTUtils_GetTrackMediaReferenceByIndex (MovieController mc, long trackIndex);
MediaHandler 		QTUtils_GetTrackMediaReferenceByType (Movie mv, long index, OSType trackType, long flags);

// Rev functions
MovieController 	QTUtils_GetRevPlayerMovieController (char *playerLongName);
char *				QTUtils_GetRevPlayerMovieName (char *playerLongName);

// Atom functions
QTAtom				QTUtils_GetTypeAndData(QTAtomContainer container, QTAtom curParent, QTAtomType atomType, long index, long *atomSize, Ptr *atomData);
Boolean				QTUtils_CheckActionAtom(QTAtomContainer container, QTAtom curParent, long action);

// Image Functions
void				QTUtils_GetPixMapFromMovie(Movie theMovie, short *movieHeight, short *movieWidth, TimeValue theTime, Boolean usePoster, Boolean maintainAspectRatio, Ptr *imageAddress, long *imageLength);
OSErr				QTUtils_SaveMoviePicToFile (Movie theMovie, short *movieHeight, short *movieWidth, TimeValue theTime, Boolean usePoster, Boolean maintainAspectRatio, FSSpec *saveToFile, OSType fileType, OSType fileCreator);

// Export Functions
OSErr				QTUtils_ExportPic (PicHandle thePic, OSType filetype, OSType filecreator, FSSpec *filespec);

#endif

