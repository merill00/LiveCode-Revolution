/*
 *  untitled.c
 *  QTExternal
 *
 *  Created by Trevor DeVore on Mon Dec 08 2003.
 *
 */

#include "ExtUtilities.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../XCmdGlue.h"
#include "QTUtilities.h"

//
// Sends a message to with variable to Revolution.  The variable will be handled
// for commas and quotes.
//
// Thanks to Tuviah Snyder
//
void DispatchRevolutionMessage(char *messagename, char *tmessage)
{
	int			retvalue = 0;
	char		mcmessage[1024];
   if (!messagename || !tmessage)
      return;

	SetGlobal("quicktimevariable",tmessage,&retvalue);
	snprintf(mcmessage, 1024, "global quicktimevariable;try;send \"%s quicktimevariable\" to current card of stack the topstack;catch errno;end try;put 0 into quicktimevariable",messagename);
   debugassert(strlen(mcmessage) >= 1023, "\pbuffer too short in DispatchRevolutionMessage")
	SendCardMessage(mcmessage, &retvalue);
}


//
// Sends a message to an object with a variable to Revolution.  The variable will be handled
// for commas and quotes.
//
void DispatchRevolutionMessageToObject(char *objectname, char *messagename, char *tmessage)
{
	int			retvalue = 0;
	char		mcmessage[1024];
   if (!objectname || !messagename || !tmessage)
      return;

	SetGlobal("quicktimevariable1",tmessage,&retvalue);
	// NOTE: added "in 0 seconds to get around QTVR hotspotenter bug which crashes OS X if the cursor
	//       is over a hotspot when the QTVR loads.
	//snprintf(mcmessage, 1024, "global quicktimevariable1;try;send \"%s quicktimevariable1\" to %s;catch errno;end try;put 0 into quicktimevariable1", messagename, objectname);
	snprintf(mcmessage, 1024, "global quicktimevariable1;try;send \"%s quicktimevariable1\" to %s in 0 seconds;catch errno;end try;put 0 into quicktimevariable1", messagename, objectname);
    debugassert(strlen(mcmessage) >= 1023, "\pbuffer too short in DispatchRevolutionMessageToObject")
	SendCardMessage(mcmessage, &retvalue);
}


//
// Sends a message to an object with a variable to Revolution.  The variable will be handled
// for commas and quotes.
//
void DispatchRevMsgToObjWith2Params(char *objectname, char *messagename, char *tmessage1, char *tmessage2)
{
	int			retvalue = 0;
	char		mcmessage[1024];
	if (!objectname || !messagename || !tmessage1 || !tmessage2)
      return;

	SetGlobal("quicktimevariable1",tmessage1,&retvalue);
	SetGlobal("quicktimevariable2",tmessage2,&retvalue);
	// NOTE: added "in 0 seconds to get around QTVR hotspotenter bug which crashes OS X if the cursor
	//       is over a hotspot when the QTVR loads.
	//snprintf(mcmessage, 1024, "global quicktimevariable1, quicktimevariable2;try;send \"%s quicktimevariable1, quicktimevariable2\" to %s;catch errno;end try;put 0 into quicktimevariable1;put 0 into quicktimevariable2", messagename, objectname);
	snprintf(mcmessage, 1024, "global quicktimevariable1, quicktimevariable2;try;send \"%s quicktimevariable1, quicktimevariable2\" to %s in 0 seconds;catch errno;end try;put 0 into quicktimevariable1;put 0 into quicktimevariable2", messagename, objectname);
	debugassert(strlen(mcmessage) >= 1023, "\pbuffer too short in DispatchRevolutionMessageToObject")
	SendCardMessage(mcmessage, &retvalue);
}


//
// Changes a revolution path to a native path
//
// Thanks to Tuviah Snyder
//
void ExtUtils_Path2Native(char *dptr)
{
    if (!dptr)
        return;
#if defined WIN32 || defined MACOS && !defined MACHO
#ifdef MACOS
    if (*dptr == '/')
        strcpy(dptr, dptr + 1);
#endif
    do {
        if (*dptr == '/')
#ifdef WIN32
            *dptr = '\\';
        else
            if (*dptr == '\\')
                *dptr = '/';
#else
        *dptr = ':';
        else
            if (*dptr == ':')
                *dptr = '/';
#endif
    } while (*++dptr);
#endif
}


//
// converts a string to lowercase
//
void ExtUtils_ToLowerCase(char *strptr)
{    
    do {
        *strptr = tolower(*strptr);
    } while (*++strptr);
    
}


//
// creates an FSSpec for mac QT files
//
// Thanks to Tuviah Snyder
//
OSErr ExtUtils_Path2FSSpec(const char *fname, FSSpec *fspec)
{//For QT movie only-
    OSErr err = noErr;
    char *nativepath = NULL;
    if (!fname || !fspec)
      return paramErr;
    nativepath = malloc (strlen(fname) + 1);
    if (!nativepath)
      return memFullErr;

    strcpy(nativepath, fname);
    ExtUtils_Path2Native(nativepath);
#ifdef WIN32
    err = NativePathNameToFSSpec(nativepath, fspec, 0);
    free (nativepath);
#else
#if defined MACHO
    char *f2 = strrchr(nativepath, '/');
    if (f2 != NULL && f2 != nativepath)
        *f2++ = '\0';
    FSRef ref;
    if ((errno = FSPathMakeRef((unsigned char *)nativepath, &ref, NULL)) == noErr) {
        if ((errno = FSGetCatalogInfo(&ref, kFSCatInfoNone,
                                      NULL, NULL, fspec, NULL)) == noErr) {
            CInfoPBRec cpb;
            memset(&cpb, 0, sizeof(CInfoPBRec));
            cpb.dirInfo.ioNamePtr = fspec->name;
            cpb.dirInfo.ioVRefNum = fspec->vRefNum;
            cpb.dirInfo.ioDrDirID = fspec->parID;
            if ((errno = PBGetCatInfoSync(&cpb)) == noErr) {
                Str255 pfilename;
                QTUtils_CopyCStringToPascal(f2, pfilename);
                debugassert(pfilename[0] >= 254, "\pbuffer too short in ExtUtils_Path2FSSpec")
                errno = FSMakeFSSpec(cpb.dirInfo.ioVRefNum, cpb.dirInfo.ioDrDirID,
                                     (unsigned char *)pfilename, fspec);
            }
        }
    }
#else
   {
   Str255 pfilename;
   QTUtils_CopyCStringToPascal(nativepath, pfilename);
   debugassert(pfilename[0] >= 254, "\pbuffer too short in ExtUtils_Path2FSSpec")
   FSMakeFSSpec(0, 0,pfilename,fspec);
   }
#endif
    free (nativepath);
#endif
    return err;
}