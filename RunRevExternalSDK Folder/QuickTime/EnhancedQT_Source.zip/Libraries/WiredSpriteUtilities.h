//////////
//
//	File:		WiredSpriteUtilities.h
//
//	Contains:	Utilities for creating wired sprite media.
//
//	Written by:	Sean Allen
//	Revised by:	Chris Flick and Tim Monroe
//
//	Copyright:	� 1998-2001 by Apple Computer, Inc., all rights reserved.
//
//	   <1>	 	03/02/01	rtm		cosmetic fixes to parallel changes in WiredSpriteUtilities.c
//	  
//
//////////

#ifndef _WIREDSPRITEUTILITIES_
#define _WIREDSPRITEUTILITIES_


//////////
//
// header files
//
//////////

//#ifndef __ENDIANUTILITIES__
//#include "EndianUtilities.h"
//#endif

#ifndef __ENDIAN__
#include <Endian.h>
#endif

#ifndef __MOVIES__
#include <Movies.h>
#endif


//////////
//
// constants
//
//////////

enum {
	kFirstParam			= 1,
	kSecondParam			= 2,
	kThirdParam			= 3,
	kFourthParam			= 4,
	kFifthParam			= 5,
	kSixthParam			= 6,
	kSeventhParam			= 7,
	kEighthParam			= 8,
	kNinthParam			= 9,
	kTenthParam			= 10
};


//////////
//
// wired sprite utilities
//
//////////

OSErr			WiredUtils_AddQTEventAtom (QTAtomContainer theContainer, QTAtom theActionAtoms, QTAtomID theQTEventType, QTAtom *theNewQTEventAtom);
OSErr			WiredUtils_AddActionAtom (QTAtomContainer theContainer, QTAtom theEventAtom, long theActionConstant, QTAtom *theNewActionAtom);
OSErr			WiredUtils_AddActionParameterAtom (QTAtomContainer theContainer, QTAtom theActionAtom, long theParameterIndex, long theParamDataSize, void *theParamData, QTAtom *theNewParamAtom);
OSErr			WiredUtils_AddActionParameterOptions (QTAtomContainer theContainer, QTAtom theActionAtom, QTAtomID theParamID, long theFlags, long theMinValueSize, void *theMinValue, long theMaxValueSize, void *theMaxValue);

// target-setting utilities
OSErr  			WiredUtils_AddMovieActionTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, QTAtom *theNewTargetAtom);
OSErr			WiredUtils_AddMovieNameActionTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, Str255 theMovieName, QTAtom *theNewTargetAtom);
OSErr			WiredUtils_AddMovieIDActionTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, long theMovieID, QTAtom *theNewTargetAtom);
OSErr			WiredUtils_AddTrackNameActionTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, Str255 theTrackName, QTAtom *theNewTargetAtom);
OSErr			WiredUtils_AddTrackIDActionTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, long theTrackID, QTAtom *theNewTargetAtom);
OSErr			WiredUtils_AddTrackTypeActionTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, OSType theTrackType, QTAtom *theNewTargetAtom);
OSErr			WiredUtils_AddTrackIndexActionTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, long theTrackIndex, QTAtom *theNewTargetAtom);
OSErr			WiredUtils_AddSpriteNameActionTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, Str255 theSpriteName, QTAtom *theNewTargetAtom);
OSErr			WiredUtils_AddSpriteIDActionTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, QTAtomID theSpriteID, QTAtom *theNewTargetAtom);
OSErr			WiredUtils_AddSpriteIndexActionTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, short theSpriteIndex, QTAtom *theNewTargetAtom);

// high-level utilities
OSErr			WiredUtils_AddQTEventAndActionAtoms (QTAtomContainer theContainer, QTAtom theAtom, long theEvent, long theAction, QTAtom *theActionAtom);
OSErr			WiredUtils_AddMovieTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, long theMovieTargetType, void *theMovieTarget);
OSErr			WiredUtils_AddTrackTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, long theTrackTargetType, void *theTrackTarget, long theTrackTypeIndex);
OSErr			WiredUtils_AddSpriteTargetAtom (QTAtomContainer theContainer, QTAtom theActionAtom, long theSpriteTargetType, void *theSpriteTarget);
OSErr			WiredUtils_AddTrackAndSpriteTargetAtoms (QTAtomContainer theContainer, QTAtom theActionAtom, long theTrackTargetType, void *theTrackTarget, long theTrackTypeIndex, long theSpriteTargetType, void *theSpriteTarget);

#endif	// _WIREDSPRITEUTILITIES_
