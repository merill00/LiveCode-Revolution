/*
 *  QTText.h
 *  QTExternal
 *
 *  Created by Trevor DeVore on Mon Dec 08 2003.
 *  Copyright (c) 2003 Blue Mango Multimedia. All rights reserved.
 *
 */

#ifndef _QTTEXT_
#define _QTTEXT_

#ifndef __MOVIES__
#include <Movies.h>
#endif

#include "QTUtilities.h"

#define kTextTrackHeight		20		// default height (in pixels) of the new text track
#define kHREFTrackName			"HREFTrack"
#define kNonHREFTrackName		"Text Track"

MediaHandler 		QTText_AddTextSample (Movie theMovie, Track theTrack, char *theText, TimeScale theTimeScale, TimeValue theStartTime, TimeValue theDuration);
OSErr 			QTText_SetTextTrackAsHREFTrack (Track theTrack, Boolean isHREFTrack);
Boolean 		QTText_IsHREFTrack (Track theTrack);


#endif

