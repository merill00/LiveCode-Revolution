/*
 *  QTText.c
 *  QTExternal
 *
 *  Created by Trevor DeVore on Mon Dec 08 2003.
 *  Copyright (c) 2003 Blue Mango Multimedia. All rights reserved.
 *
 */

#include "QTText.h"
#ifdef __MWERKS__
#include <string.h>
#endif // __MWERKS__

// Inserts a text sample into the given track
MediaHandler QTText_AddTextSample (Movie theMovie, Track theTrack, char *theText, TimeScale theTimeScale, TimeValue theStartTime, TimeValue theDuration)
{
    Media				myMedia = NULL;
    MediaHandler                    myHandler = NULL;
    Fixed				myWidth = 0;
    Fixed				myHeight = 0;
    Str255                          mySampleText;
    TextDescriptionHandle		mySampleDesc = NULL;
    Handle                          mySample = NULL;
    UInt16                          myLength;
    RGBColor                        myBGColor = {0xffff, 0xffff, 0xffff};
    OSErr				myErr = noErr;

    GetTrackDimensions(theTrack, &myWidth, &myHeight);

    myMedia = NewTrackMedia(theTrack, TextMediaType, theTimeScale, NULL, 0);
    if (myMedia == NULL)
        goto bail;

    myHandler = GetMediaHandler(myMedia);
    if (myHandler == NULL)
        goto bail;

    myErr = BeginMediaEdits(myMedia);
    if (myErr == noErr)
    {
        Rect			myBounds;
        TimeRecord		myTimeRec;

        myBounds.top = 0;
        myBounds.left = 0;
        myBounds.right = Fix2Long(myWidth);
        myBounds.bottom = Fix2Long(myHeight);

        // Add sample
        myTimeRec.value.lo = theDuration;
        myTimeRec.value.hi = 0;
        myTimeRec.scale = GetMovieTimeScale(theMovie);
        ConvertTimeScale(&myTimeRec, GetMediaTimeScale(myMedia));
        theDuration = myTimeRec.value.lo;

        QTUtils_CopyCStringToPascal(theText, mySampleText);

        // Use AddMediaSample
        // Note: You could also use TextMediaAddTextSample here as well
        mySampleDesc = (TextDescriptionHandle)NewHandleClear(sizeof(TextDescription));
        if (mySampleDesc == NULL)
            goto bail;

        (**mySampleDesc).descSize = sizeof(TextDescription);
        (**mySampleDesc).dataFormat = TextMediaType;
        (**mySampleDesc).displayFlags = dfClipToTextBox;
        (**mySampleDesc).textJustification = teCenter;
        (**mySampleDesc).defaultTextBox = myBounds;
        (**mySampleDesc).bgColor = myBGColor;

        myLength = EndianU16_NtoB (mySampleText[0]);

        // create text media sample: a 16-bit length word followed by the text
        myErr = PtrToHand(&myLength, &mySample, sizeof(myLength));
        if (myErr == noErr) {
            myErr = PtrAndHand((Ptr)(&mySampleText[1]), mySample, mySampleText[0]);
            if (myErr == noErr)
                AddMediaSample( myMedia,
                                mySample,
                                0,
                                GetHandleSize(mySample),
                                theDuration,
                                (SampleDescriptionHandle)mySampleDesc,
                                1,
                                0,
                                NULL);
            DisposeHandle(mySample);
        }

        if (myErr != noErr)
            goto bail;

        DisposeHandle((Handle)mySampleDesc);
    }

    myErr = EndMediaEdits(myMedia);
    if (myErr != noErr)
        goto bail;

    // insert the text media into the text track
    myErr = InsertMediaIntoTrack(theTrack, theStartTime, 0, GetMediaDuration(myMedia), fixed1);
    if (myErr != noErr)
        goto bail;

bail:
        return (myHandler);
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// Chapter track utilities.
//
// Use these functions to manipulate chapter tracks in a movie.
//
// A chapter track is a text track that has been associated with some other track (often a video or sound
// track) in such a way that the movie controller will build, display, and handle a pop-up menu of titles
// of various parts of the associated track. The pop-up menu appears (space permitting) in the controller
// bar. The various parts of the associated track are called the track's "chapters". When a user selects a
// chapter title in the pop-up menu, the movie controller jumps to the start time of the selected chapter.
//
// You create the association between a text track and some other track by creating a reference from that
// other track to the text track, where the reference is of type kTrackReferenceChapterList. Note that all
// the chapter titles must be contained in a single text track; you specify the starting time for chapters
// when you add the text to the text track by calling TextMediaAddTextSample. Note also that you need to
// create the chapter association only between the text track and one other track, not between the chapter
// track and all other tracks in the movie. (That "other" track must be enabled, but typically the chapter
// track is not enabled.)
//
// The pop-up menu will disappear from the controller bar if there isn't enough space to display the menu,
// the volume slider control, the step buttons, and the other controls.
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////



///////////////////////////////////////////////////////////////////////////////////////////////////////////
//
// HREF track utilities.
//
// Use these functions to manipulate HREF tracks in a movie.
//
// An HREF track is a text track that has a special name ("HREFTrack") and some of whose samples specify
// URLs that are loaded when the user clicks in the movie box when the text sample is active or when the
// text sample first loads.
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////
//
// QTText_SetTextTrackAsHREFTrack
// Set the specified track to be or not to be an HREF track.
//
//////////

OSErr QTText_SetTextTrackAsHREFTrack (Track theTrack, Boolean isHREFTrack)
{
    OSErr		myErr = noErr;

    myErr = QTUtils_SetTrackName(theTrack, isHREFTrack ? kHREFTrackName : kNonHREFTrackName);

    return(myErr);
}


//////////
//
// QTText_IsHREFTrack
// Is the specified track an HREF track?
//
// For the moment, we are content to count a track as an HREF track if its name is "HREFTrack";
// a more thorough test would be to look through the text samples for some actual URLs. This is
// left as an exercise for the reader.
//
//////////

Boolean QTText_IsHREFTrack (Track theTrack)
{
    Boolean		isHREFTrack = false;
    char 		*myTrackName = NULL;

    myTrackName = QTUtils_GetTrackName(theTrack);
    if (myTrackName != NULL)
        isHREFTrack = (strcmp(myTrackName, kHREFTrackName) == 0);

    free(myTrackName);
    return(isHREFTrack);
}