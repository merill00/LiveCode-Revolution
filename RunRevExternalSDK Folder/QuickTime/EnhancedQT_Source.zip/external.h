//////////
//
//	File:		external.h
//
//	Contains:	QT External functions for Revolution.
//
//	Written by:	Trevor DeVore
//				Incorporates code written by Tim Monroe.
//				Based on the MetaCard external sample code.
//
//	Copyright:	� 1997 by MetaCard Corporation, Inc., all rights reserved.
//
//	Change History (most recent first):
//
//	   <1>	 	11/17/03	rtm		first file; based on examples by Tim Monroe in MacTech October 2003
//	   
//////////

/********************************************/
/*    Copyright 1997 MetaCard Corporation   */
/*    This source code may be used as a     */
/*    template for building external        */
/*    processes for use with Rev or MC.     */
/*    All Other Rights Reserved             */
/********************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <signal.h>
#include <time.h>

#ifndef __MOVIES__
#include <Movies.h>
#endif

#include "XCmdGlue.h"

//////////
//
// constants
//
//////////

// constants used for XCMD_GetMovieFileLoopingInfo
enum {
    kNormalLooping              = 0,
    kPalindromeLooping          = 1,
    kNoLooping                  = 2
};

#if TARGET_OS_MAC
#ifndef PASCAL_RTN
#define PASCAL_RTN                      pascal
#endif
#endif
#if TARGET_OS_WIN32
#ifndef PASCAL_RTN
#define PASCAL_RTN

#undef snprintf
#define snprintf _snprintf

#endif
#endif

//TUV

//constants for length of numbers
#define U1L 8
#define I1L 8
#define U2L 8
#define I2L 8
#define U4L 16
#define I4L 16
#define I4L 16
#define R4L 64
#define R8L 384

enum
   {
   kMovieControllerNone		= FOUR_CHAR_CODE('none'),
   kMovieControllerMovie	= FOUR_CHAR_CODE('    ')
};

//////////
//
// global variables
//
//////////
extern Xternal Xtable[];
extern char Xname[];


//////////
//
// function prototypes
//
//////////

// General
extern void 		XCMD_QTInitialize (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_QTTerminate(char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_GetMCInfo (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);

// Editing functions
extern void 		XCMD_MCInitialize (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_MCUndo (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_MCCut (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_MCCopy (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_MCPaste (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_MCClear (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_SelectAll (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_SelectNone (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_SetSelection (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void			XCMD_AddTransition (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void			XCMD_AddFilter (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_MCAddMovieSegment (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_CopyTrackToScrap (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);

extern void 		XCMD_SetWindowModified (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_Save (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void			XCMD_CreateNewMovie (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_Export (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);

// Movie property functions
extern void 		XCMD_SetMovieAnnotation (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_GetMovieAnnotation (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_SetMovieFileLoopingInfo (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_GetMovieFileLoopingInfo (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_MakeMovieLoop (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void			XCMD_GetMovieControllerType (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void			XCMD_GetMovieDimensions (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void			XCMD_FlipMovie (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);

// track functions
extern void 		XCMD_SetTrackEnabled (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_GetTrackEnabled (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_DeleteTrack (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
//extern void 		XCMD_GetTrackNames (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_GetTrackName (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_GetTrackType (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);

// Intermovie communication functions
extern void 		XCMD_RegisterMovieControllers (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_ClearMovieControllers (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_GetMovieName (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);

// Text Tracks
extern void 		XCMD_RegisterTextSampleCallback (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_CreateHREFTrack (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void         XCMD_SetTrackAsChapterTrack (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);

// Wired sprite functions
extern void			XCMD_ExecuteSpriteEvent (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_GetSpriteVariableAsFloat (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_SetSpriteVariableToFloat (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_GetSpriteVariableAsString (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_SetSpriteVariableToString (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_SetQTList (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_GetQTList (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);

// Movie state functions
extern void 		XCMD_GetMovieLoadState (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_GetMaxLoadedTimeInMovie (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);

// QTVR functions
extern void 		XCMD_QTVRNudge (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_QTVRShowDefaultView (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_QTVRSetInteractionProperty (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void			XCMD_QTVRSetQuality (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void			XCMD_QTVRGetHotSpotName (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void			XCMD_QTVRGetHotSpotComment (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void			XCMD_QTVREnableHotSpot (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void			XCMD_QTVRSwing (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void			XCMD_QTVRSwingStop (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);

// Audio functions
extern void 		XCMD_GetTrackVolume (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_SetTrackVolume (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_GetMediaSoundBalance (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_SetMediaSoundBalance (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_GetMediaGetSoundBassAndTreble (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_SetMediaSetSoundBassAndTreble (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);

// Image Functions
extern void			XCMD_GetMovieSnapShot (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void			XCMD_SaveMovieSnapShotToFile (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);

// Controller functions
extern void 		XCMD_EnableVolumeControl (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void 		XCMD_EnableStepButtons (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);

extern void 		XCMD_Abort();

// missing prototypes that look like they should be around here somewhere
extern void       XCMD_GetQuickTimePreference (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
extern void       XCMD_AddTextTrack (char *args[], int nargs, char **retstring, Bool *pass, Bool *error);

//
// Internal QT functions
//

// QT Initialization Functions
static Bool 		IsQTVRMovie(Movie theMovie);
static Bool 		IsQTVRInstalled(void);
static Bool 		QTVR_Init();
static Bool 		QT_Init();
static Bool 		QT_Terminate();
static Bool 		QTVR_Terminate();

// intermovie comm
#define kMovieNamePrefix                "moviename="
#define kMovieIDPrefix                  "movieid="

// QT intermovie communication functions
static long 		QT_FindUserDataItemWithPrefix (UserData theUserData, OSType theType, char *thePrefix);
static char * 		QT_GetUserDataPrefixedValue (UserData theUserData, OSType theType, char *thePrefix);
void				   QT_FindExternalMovieTarget (MovieController theMC, QTGetExternalMoviePtr theEMRecPtr);
char *				QT_GetMovieTargetName (Movie theMovie, int movieArrayIndex);
long				   QT_GetMovieTargetID (Movie theMovie, Boolean *theMovieHasID);

// Callbacks
PASCAL_RTN void		QT_ApplicationNumberAndString (QTAtomContainer container, QTAtom curParent, long theRefCon);
PASCAL_RTN OSErr	   QT_TextMediaTextSampleCallback (Handle theText, Movie theMovie, short *displayFlag, long refcon);
PASCAL_RTN Boolean 	QT_MCActionFilterProcCallback (MovieController theMC, short theAction, void *theParams, long theRefCon);
PASCAL_RTN Boolean   QT_ExecuteOneAction(ResolvedQTEventSpec *theSpec, long theRefCon);

// QTVR Callbacks
PASCAL_RTN OSErr     QT_MouseOverHotspotProcCallback (QTVRInstance theQTVR, UInt32 theHotSpotID, UInt32 theFlags, SInt32 theRefCon);
PASCAL_RTN void      QT_HotSpotClickedIntercept (QTVRInstance theQTVR, QTVRInterceptPtr qtvrMsg, SInt32 theRefCon, Boolean *cancel);