//////////
//
//	File:		external.h
//
//	Contains:	QT External functions for Revolution.
//
//	Written by:	Trevor DeVore
//				Incorporates examples provided by Steve Israelson of TotallyHip Software.
//				Incorporates code written by Tim Monroe of Apple Computer.
//				Incorporates code from the Apple QuickTime examples from the developer site.
//				Based on the MetaCard external sample code.
//
//	Copyright:	� 1997 by MetaCard Corporation, Inc., all rights reserved.
//
//	Change History (most recent first):
//
//	   <1>	 	11/17/03	rtm		first file; based on examples by Tim Monroe in MacTech October 2003
//	   
//////////

/********************************************/
/*    Copyright 1997 MetaCard Corporation   */
/*    This source code may be used as a     */
/*    template for building external        */
/*    processes for use with Rev or MC.     */
/*    All Other Rights Reserved             */
/********************************************/

//////////
//
// header files
//
//////////

#ifdef WIN32 //Tuv
#include <stdlib.h>
#include <string.h>
#include <QTML.h>
#include <Endian.h>
#include <QuickTimeComponents.h>
#include <Movies.h>   //QT
#include <MediaHandlers.h>
#include <QuickTimeVR.h>
#include <QuickTimeVRFormat.h>
#include <Endian.h>
#include <QuickTimeComponents.h>
#include <Script.h>
#include <FixMath.h>
#include <MoviesFormat.h>
#include <Files.h>
#include <NumberFormatting.h>
#include <StringCompare.h>
#include <Gestalt.h>
#endif

#include "external.h"
#include "Libraries/WiredSpriteUtilities.h"
#include "Libraries/ExtUtilities.h"
#include "Libraries/QTText.h"
#include "Libraries/QTVRUtilities.h"
#include "Libraries/QTUtilities.h"

#if defined(__MWERKS__) && defined(_MSL_ANSI_PREFIX_MAC_H)
// we want to call MSL's __malloc_free_all() when the plugin is unloaded
#include <pool_alloc.h>
#endif // defined(__MWERKS__) && defined(_MSL_ANSI_PREFIX_MAC_H)

//////////
//
// global variables
//
//////////

char	Xname[] = "QuickTime Enhancements Revolution External v 0.6.0";     // identifies this external to the engine

/*
 * This global table has one entry per XCMD/XFCN.
 * The first entry is the name of the handler
 * The second entry is the type (XCOMMAND or XFUNCTION)
 * The third entry is a space for the atom (used by MetaCard)
 * The fourth entry is the name of the 'C' function to call
 * The fifth entry is a callback called if the user aborts
 * Note that the last entry in the table is a NULL entry
 * which is used to measure the size of the table.
 */

Xternal Xtable[] = {
    // General
    {"qtInitialize", XCOMMAND, 0, XCMD_QTInitialize, XCMD_Abort},
    {"qtTerminate", XCOMMAND, 0, XCMD_QTTerminate, XCMD_Abort},
    
    // Editing functions
    {"qtInitializeEditing", XCOMMAND, 0, XCMD_MCInitialize, XCMD_Abort},
    {"qtUndo", XCOMMAND, 0, XCMD_MCUndo, XCMD_Abort},
    {"qtCut", XCOMMAND, 0, XCMD_MCCut, XCMD_Abort},
    {"qtCopy", XCOMMAND, 0, XCMD_MCCopy, XCMD_Abort},
    {"qtPaste", XCOMMAND, 0, XCMD_MCPaste, XCMD_Abort},
    {"qtClear", XCOMMAND, 0, XCMD_MCClear, XCMD_Abort},
    {"qtSelectAll", XCOMMAND, 0, XCMD_SelectAll, XCMD_Abort},
    {"qtSelectNone", XCOMMAND, 0, XCMD_SelectNone, XCMD_Abort},
    {"qtSetSelection", XCOMMAND, 0, XCMD_SetSelection, XCMD_Abort},
    {"qtAddTransition", XCOMMAND, 0, XCMD_AddTransition, XCMD_Abort},
    {"qtAddFilter", XCOMMAND, 0, XCMD_AddFilter, XCMD_Abort},
    {"qtAddMovieSegment", XCOMMAND, 0, XCMD_MCAddMovieSegment, XCMD_Abort},
    {"qtCopyTrackToScrap", XCOMMAND, 0, XCMD_CopyTrackToScrap, XCMD_Abort},
    {"qtSave", XCOMMAND, 0, XCMD_Save, XCMD_Abort},
    {"qtCreateNewMovie", XCOMMAND, 0, XCMD_CreateNewMovie, XCMD_Abort},
    {"qtExport", XCOMMAND, 0, XCMD_Export, XCMD_Abort},
    {"qtSetWindowModified", XCOMMAND, 0, XCMD_SetWindowModified, XCMD_Abort},

    // Movie Property functions
    {"qtGetMovieAnnotation", XFUNCTION, 0, XCMD_GetMovieAnnotation, XCMD_Abort},
    {"qtSetMovieAnnotation", XCOMMAND, 0, XCMD_SetMovieAnnotation, XCMD_Abort},
    {"qtSetMovieLoopingInfo", XCOMMAND, 0, XCMD_SetMovieFileLoopingInfo, XCMD_Abort},
    {"qtGetMovieLoopingInfo", XFUNCTION, 0, XCMD_GetMovieFileLoopingInfo, XCMD_Abort},
    {"qtMakeMovieLoop", XCOMMAND, 0, XCMD_MakeMovieLoop, XCMD_Abort},
    {"qtGetMovieName", XFUNCTION, 0, XCMD_GetMovieName, XCMD_Abort},
	{"qtGetMovieControllerType", XFUNCTION, 0, XCMD_GetMovieControllerType, XCMD_Abort},
	{"qtGetMovieDimensions", XFUNCTION, 0, XCMD_GetMovieDimensions, XCMD_Abort},
	{"qtFlipMovie", XCOMMAND, 0, XCMD_FlipMovie, XCMD_Abort},
    
    // player enhancement functions
    {"qtRegisterMovieControllers", XCOMMAND, 0, XCMD_RegisterMovieControllers, XCMD_Abort},
    {"qtClearMovieControllers", XCOMMAND, 0, XCMD_ClearMovieControllers, XCMD_Abort},
    
    // Wired Sprite functions
    {"qtExecuteSpriteEvent", XCOMMAND, 0, XCMD_ExecuteSpriteEvent, XCMD_Abort},
    {"qtGetSpriteVariable", XFUNCTION, 0, XCMD_GetSpriteVariableAsString, XCMD_Abort},
    {"qtSetSpriteVariable", XCOMMAND, 0, XCMD_SetSpriteVariableToString, XCMD_Abort},
    {"qtGetSpriteVariableAsFloat", XFUNCTION, 0, XCMD_GetSpriteVariableAsFloat, XCMD_Abort},
    {"qtSetSpriteVariableToFloat", XCOMMAND, 0, XCMD_SetSpriteVariableToFloat, XCMD_Abort},
    {"qtGetSpriteVariableAsString", XFUNCTION, 0, XCMD_GetSpriteVariableAsString, XCMD_Abort},
    {"qtSetSpriteVariableToString", XCOMMAND, 0, XCMD_SetSpriteVariableToString, XCMD_Abort},
    {"qtSetQTList", XCOMMAND, 0, XCMD_SetQTList, XCMD_Abort},
    {"qtGetQTList", XFUNCTION, 0, XCMD_GetQTList, XCMD_Abort},
    
    // Movie state functions
    {"qtGetMovieLoadState", XFUNCTION, 0, XCMD_GetMovieLoadState, XCMD_Abort},
    {"qtGetMaxLoadedTimeInMovie", XFUNCTION, 0, XCMD_GetMaxLoadedTimeInMovie, XCMD_Abort},
    
    // QTVR functions
    {"qtQTVRNudge", XCOMMAND, 0, XCMD_QTVRNudge, XCMD_Abort},
    {"qtQTVRShowDefaultView", XCOMMAND, 0, XCMD_QTVRShowDefaultView, XCMD_Abort},
    {"qtQTVRSetInteractionProperty", XCOMMAND, 0, XCMD_QTVRSetInteractionProperty, XCMD_Abort},
    {"qtQTVRSetQuality", XCOMMAND, 0, XCMD_QTVRSetQuality, XCMD_Abort},
    {"qtQTVRGetHotSpotName", XFUNCTION, 0, XCMD_QTVRGetHotSpotName, XCMD_Abort},
    {"qtQTVRGetHotSpotComment", XFUNCTION, 0, XCMD_QTVRGetHotSpotComment, XCMD_Abort},
    {"qtQTVREnableHotSpot", XCOMMAND, 0, XCMD_QTVREnableHotSpot, XCMD_Abort},
	{"qtQTVRSwing", XCOMMAND, 0, XCMD_QTVRSwing, XCMD_Abort},
	{"qtQTVRSwingStop", XCOMMAND, 0, XCMD_QTVRSwingStop, XCMD_Abort},
    
    // Audio track functions
    {"qtGetTrackVolume", XFUNCTION, 0, XCMD_GetTrackVolume, XCMD_Abort},
    {"qtSetTrackVolume", XCOMMAND, 0, XCMD_SetTrackVolume, XCMD_Abort},
    {"qtGetTrackBalance", XFUNCTION, 0, XCMD_GetMediaSoundBalance, XCMD_Abort},
    {"qtSetTrackBalance", XCOMMAND, 0, XCMD_SetMediaSoundBalance, XCMD_Abort},
    {"qtGetTrackBassAndTreble", XFUNCTION, 0, XCMD_GetMediaGetSoundBassAndTreble, XCMD_Abort},
    {"qtSetTrackBassAndTreble", XCOMMAND, 0, XCMD_SetMediaSetSoundBassAndTreble, XCMD_Abort},
	
	// Image Functions
	{"qtGetMovieSnapShot", XCOMMAND, 0, XCMD_GetMovieSnapShot, XCMD_Abort},
	{"qtSaveMovieSnapShotToFile", XCOMMAND, 0, XCMD_SaveMovieSnapShotToFile, XCMD_Abort},
    
    // Controller functions
    {"qtEnableVolumeControl", XCOMMAND, 0, XCMD_EnableVolumeControl, XCMD_Abort},
    {"qtEnableStepButtons", XCOMMAND, 0, XCMD_EnableStepButtons, XCMD_Abort},
    {"qtGetMovieControllerInfo", XFUNCTION, 0, XCMD_GetMCInfo, XCMD_Abort},
    
    // Track functions
    {"qtGetTrackEnabled", XFUNCTION, 0, XCMD_GetTrackEnabled, XCMD_Abort},
    {"qtSetTrackEnabled", XCOMMAND, 0, XCMD_SetTrackEnabled, XCMD_Abort},
    {"qtDeleteTrack", XCOMMAND, 0, XCMD_DeleteTrack, XCMD_Abort},
	//{"qtGetTrackNames", XFUNCTION, 0, XCMD_GetTrackNames, XCMD_Abort},
	{"qtGetTrackName", XFUNCTION, 0, XCMD_GetTrackName, XCMD_Abort},
	{"qtGetTrackType", XFUNCTION, 0, XCMD_GetTrackType, XCMD_Abort},
	

    // Text Track functions
    {"qtCreateHREFTrack", XCOMMAND, 0, XCMD_CreateHREFTrack, XCMD_Abort},
    {"qtSetTrackAsChapterTrack", XCOMMAND, 0, XCMD_SetTrackAsChapterTrack, XCMD_Abort},
    {"qtRegisterTextSampleCallback", XCOMMAND, 0, XCMD_RegisterTextSampleCallback, XCMD_Abort},

    // QT Preference functions
    //{"qtGetPreference", XFUNCTION, 0, XCMD_GetQuickTimePreference, XCMD_Abort},
    
    {"", XNONE, 0, NULL, NULL}
};

// this needs to be changed so that the array memory is dynamically assigned
enum
   {
   kMaxMovieControllers = 10,
   kMaxPlayerNameSize = 256,
   kMaxMovieNameSize = 256,
   kMaxCallbackCommandSize = 50,
   kMaxCallbackTargetSize = 256
   };
static MovieController movieControllerArray[kMaxMovieControllers] = { 0 };
static char playerNameArray[kMaxMovieControllers][kMaxPlayerNameSize] = { 0 };
static char movieNameArray[kMaxMovieControllers][kMaxMovieNameSize] = { 0 };
static int totalMovieControllers = 0;
static char textCallbackCommand[kMaxCallbackCommandSize] = { 0 };
static char textCallbackTarget[kMaxCallbackTargetSize] = { 0 };


#ifdef WIN32
#undef DebugStr
#define DebugStr myDebugStr
void myDebugStr(ConstStr255Param       debuggerMsg)
{

}
#endif

//NEED to call initializeQTML for Windows and initialize QTVR as well
static Bool QT_Init()
{
  static Bool QTinited = False;

  if (!QTinited)
#ifdef WIN32
    if (InitializeQTML(0L) == noErr && EnterMovies() == noErr)
      QTinited = True;
#elif defined MACOS
  {
    long response;
    if (Gestalt(gestaltQuickTimeVersion, &response) == noErr
	&& EnterMovies() == noErr)
	 QTinited = True;
  }
#endif 
  return QTinited;
}


static Bool QTVR_Init()
{
    static Bool QTVRinited = False;

    if (!QTVRinited)
#ifdef WIN32
    // if (InitializeQTVR() != noErr)
    if (InitializeQTVR() == noErr)
        QTVRinited = True;
#elif defined MACOS
    if (IsQTVRInstalled())
        QTVRinited = True;
#endif    
    return QTVRinited;
}


static Bool QT_Terminate()
{
    static Bool QTterminated = False;

    if (!QTterminated)
#ifdef WIN32
    {
        ExitMovies();
        TerminateQTML();
        QTterminated = True;
    }
#elif defined MACOS
    {
        ExitMovies();
        QTterminated = True;
    }
#endif
    return QTterminated;
}


static Bool QTVR_Terminate()
{
    static Bool QTVRterminated = False;

#ifdef WIN32
    if (!QTVRterminated)
        if (TerminateQTVR() == noErr)
            QTVRterminated = True;
#endif
    return QTVRterminated;
}


//QT utilty function which don't really fit into MCPlayer class.
static Bool IsQTVRInstalled(void)
{
  Bool IsQTVRInstalled = False;
  OSErr myErr;
  long myAttrs;

  myErr = Gestalt(gestaltQTVRMgrAttr, &myAttrs);

  if (myErr == noErr)
    if ((1 << gestaltQTVRMgrPresent) == (myAttrs & (1 << gestaltQTVRMgrPresent)))
        IsQTVRInstalled = True;

  return IsQTVRInstalled;
}


static Bool IsQTVRMovie(Movie theMovie) 
{
  Bool IsQTVR = False;
  OSType evaltype,targettype =  kQTVRUnknownType;
  UserData myUserData;

  if (theMovie == NULL)
    return False;

  myUserData = GetMovieUserData(theMovie);

  if (myUserData != NULL) {
    GetUserDataItem(myUserData, &targettype, sizeof(targettype),
		    kUserDataMovieControllerType, 0);
    evaltype = EndianU32_BtoN(targettype);
    if (evaltype == kQTVRQTVRType || evaltype == kQTVROldPanoType
	|| evaltype == kQTVROldObjectType)
      IsQTVR = true;
  }

  return IsQTVR;
}


// Takes a variable number of arguments and registers each movie controller id with the external
// This is used for looping through when looking for movies to communicate with.
// qtRegisterMovieControllers (MovieController, ...)
void XCMD_RegisterMovieControllers (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController 		mc = NULL;
    Movie					mv = NULL;
    Track					myQTVRTrack = NULL;
    QTVRInstance			myQTVRInstance= NULL;
    ComponentResult 		result = noErr;
    char *					retstr = NULL;
    int						x = 0;
    
    *pass = false;
    *error = false;

    if (nargs > 0) {
        totalMovieControllers = 0;
        
        for (x = 0; x < nargs; ++x)
		//for (x = 0; x < 10; ++x)
        {
			movieControllerArray[x] = 0;
			snprintf(playerNameArray[x], kMaxPlayerNameSize, "%s", "");
			snprintf(movieNameArray[x], kMaxMovieNameSize, "%s", "");
		
			mc = QTUtils_GetRevPlayerMovieController (args[x]);
			if (mc != NULL && (long)mc > 0)
			{
				mv = MCGetMovie(mc);
				
				if (mv != NULL) {
					// remove current filter
					MCSetActionFilterWithRefCon(mc, NULL, 0);
					// add new mc filter
					// Pass in the index of this controller as the refcon so each time an action is called we know which one to target.
					result = MCSetActionFilterWithRefCon(mc, NewMCActionFilterWithRefConUPP(QT_MCActionFilterProcCallback), (long)x);

					// If QTVR then add new callbacks
					if (IsQTVRMovie(mv)) {
						myQTVRTrack = QTVRGetQTVRTrack (mv, 1);
						if (myQTVRTrack != NULL)
						{
							result = QTVRGetQTVRInstance (&myQTVRInstance, myQTVRTrack, mc);
							
							if (myQTVRInstance != NULL) {
								result = QTVRSetMouseOverHotSpotProc(myQTVRInstance, NULL, 0, 0);
								result = QTVRInstallInterceptProc (myQTVRInstance, kQTVRTriggerHotSpotSelector, NULL, 0, 0);
								
								result = QTVRSetMouseOverHotSpotProc (myQTVRInstance, NewQTVRMouseOverHotSpotUPP(QT_MouseOverHotspotProcCallback), (long)x, 0);
								result = QTVRInstallInterceptProc (myQTVRInstance, kQTVRTriggerHotSpotSelector, NewQTVRInterceptUPP(QT_HotSpotClickedIntercept), (long)x, 0);
							}
						}
					}
					
					movieControllerArray[x] = mc;
					snprintf(playerNameArray[x], kMaxPlayerNameSize, "%s", args[x]);
					snprintf(movieNameArray[x], kMaxMovieNameSize, "%s", QTUtils_GetRevPlayerMovieName (args[x]));
					
					totalMovieControllers++;
					debugassert(totalMovieControllers >= kMaxMovieControllers, "\ptoo many movie controllers in XCMD_RegisterMovieControllers")
				}
			}
			else
			{
				retstr = (char *)malloc(25);
				snprintf(retstr, 25, "%s", "Invalid movie controller");
			}
        }
        
        retstr = calloc(1, 2);
        if (retstr != NULL)
            retstr[0] = (result == noErr) ? '0': '1';
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}


// Clears all registered movie controllers
// qtClearMovieControllers ()
void XCMD_ClearMovieControllers (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
#ifdef __MWERKS__
#pragma unused (args, nargs)
#endif // __MWERKS__

    MovieController		mc = NULL;
    Movie				mv = NULL;
    Track				myQTVRTrack = NULL;
    QTVRInstance		myQTVRInstance = NULL;
    ComponentResult		result = noErr;
    int					x= 0;
    char *				retstr = NULL;
    
    *pass = false;
    *error = false;
    
    for (x = 0; x < totalMovieControllers; ++x)
    {
        mc = movieControllerArray[x];
		if (mc != NULL) {
			mv = MCGetMovie(mc);
				if (mv != NULL) {
				 
				result = MCSetActionFilterWithRefCon(mc, NULL, 0);
				
				if (result == noErr) {
					// If QTVR then remove callbacks
					if (IsQTVRMovie(mv)) {
						myQTVRTrack = QTVRGetQTVRTrack (mv, 1);
						if (myQTVRTrack != NULL)
						{
							result = QTVRGetQTVRInstance (&myQTVRInstance, myQTVRTrack, mc);
				
							result = QTVRSetMouseOverHotSpotProc(myQTVRInstance, NULL, 0, 0);
							result = QTVRInstallInterceptProc (myQTVRInstance, kQTVRTriggerHotSpotSelector, NULL, 0, 0);
						}
					}
				}

				movieControllerArray[x] = NULL;
				snprintf(playerNameArray[x], kMaxPlayerNameSize, "%s", "");
				snprintf(movieNameArray[x], kMaxMovieNameSize, "%s", "");
			}
		}
    }
    
    totalMovieControllers = 0;
    
    retstr = calloc(1, 2);
    if (retstr != NULL)
        retstr[0] = (result == noErr) ? '0': '1';
    
    *retstring = retstr;
}


//TUV init QT and QTML
void XCMD_QTInitialize(char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
#ifdef __MWERKS__
#pragma unused (args, nargs)
#endif // __MWERKS__

    Bool result = QT_Init();
    char *retstr = calloc(1, 2);
	*pass = false;

    *error = false;
    if (result)
        QTVR_Init();

    if (retstr != NULL)
        retstr[0] = (result == True) ? '0': '1';

    *retstring = retstr;
}


//
// shutdown QT on Windows
//
void XCMD_QTTerminate(char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
#ifdef __MWERKS__
#pragma unused (args, nargs)
#endif // __MWERKS__

    Bool result = QT_Terminate();
    char *retstr = calloc(1, 2);
    *pass = false;

    *error = false;
    if (result)
        QTVR_Terminate();

#if defined(__MWERKS__) && defined(_MSL_ANSI_PREFIX_MAC_H)
   // this call releases the pools that MSL has allocated for small malloc() calls.
   // No further stdlib memory calls should be made after this!
   __malloc_free_all();
#endif // defined(__MWERKS__) && defined(_MSL_ANSI_PREFIX_MAC_H)

    if (retstr != NULL)
        retstr[0] = (result == True) ? '0': '1';

    *retstring = retstr;
}


// Registers a handler in the Rev app which will be called every time a text sample is loaded in
// the QT movie.  The text is passed a parameter.
// qtRegisterTextSampleCallback (MovieController, TargetTrackIdentifier, Command, Target (long id))
//
// If you need to start unregistering this callback for some reason you would use
// void DisposeTextMediaUPP (TextMediaUPP    userUPP );
void XCMD_RegisterTextSampleCallback (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController			mc = NULL;
    MediaHandler			mh = NULL;
    long					trackIndex = 0;
    ComponentResult			result = noErr;
    char *					retstr = NULL;

    *pass = false;
    *error = false;

    if (nargs == 4) {
        mc = (MovieController)atol(args[0]);
        trackIndex = atol(args[1]);

        if (mc != NULL && (long)mc > 0 )
        {
            // If no track name or index was given then set index to 1
            if (trackIndex == 0 && strlen(args[1]) < 1)
                trackIndex = 1;

            // args[1] is a number search by track index, otherwise by name
            if (trackIndex > 0) 
                mh = QTUtils_GetTrackMediaReferenceByIndex(mc, trackIndex);
            else
                mh = QTUtils_GetTrackMediaReferenceByName (mc, args[1]);

            if (mh != NULL)
            {
                // remove current callback
                //TextMediaSetTextProc(mh, NULL, NULL);

                // add new callback
                // No RefCon currently
                result = TextMediaSetTextProc(mh, NewTextMediaUPP(QT_TextMediaTextSampleCallback), 0);
                snprintf(textCallbackCommand, kMaxCallbackCommandSize, "%s", args[2]);
                snprintf(textCallbackTarget, kMaxCallbackTargetSize, "%s", args[3]);

                retstr = calloc(1, 2);
                if (retstr != NULL)
                    retstr[0] = (result == noErr) ? '0': '1';
            }
            else
            {
                retstr = (char *)malloc(22);
                snprintf(retstr, 22, "%s", "Invalid media handler");
            }
        }
        else
        {
            retstr = (char *)malloc(25);
            snprintf(retstr, 25, "%s", "Invalid movie controller");
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }

    *retstring = retstr;
}



//////////
//
// Wired Sprites
//
// Functions for working with QT Wired Sprites
//////////


// qtExecuteSpriteEvent controllerID, SpriteTrackName, SpriteIndex, EventType
// Change spriteID to sprite name once you get this working
void XCMD_ExecuteSpriteEvent (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    MediaHandler mh = NULL;
    Track st = NULL;    // sprite track
    struct QTEventRecord event;
    QTAtomID spriteID = 0L;
    QTAtomContainer myActions = NULL;
    QTAtom myActionAtom = 0;
    ResolvedQTEventSpec myEventSpec;
    struct Point myPoint;
    long eventID = 0;
    ComponentResult result = noErr;
    char *retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 4)
    {
        mc = (MovieController)atol(args[0]);
        spriteID = (long)atol(args[2]);
        
        if (mc != NULL && (long)mc > 0 && spriteID > 0)
        {
            ExtUtils_ToLowerCase(args[3]);
            
            // Determine which event to trigger
            if (strcmp(args[3], "mouseup") == 0) {    
                eventID = kQTEventMouseClickEnd;
            } else if (strcmp(args[3], "mousedown") == 0) {    
                eventID = kQTEventMouseClick;
            } else if (strcmp(args[3], "mouseclick") == 0) {    
                eventID = kQTEventMouseClickEndTriggerButton;
            } else if (strcmp(args[3], "mouseenter") == 0) {    
                eventID = kQTEventMouseEnter;
            } else if (strcmp(args[3], "mouseexit") == 0) {    
                eventID = kQTEventMouseExit;
            } else if (strcmp(args[3], "mousemoved") == 0) {    
                eventID = kQTEventMouseMoved;
            } else {
                // User wants to execute a custom event
                eventID = (long)atol(args[3]);
            }
            
            // Get media reference to sprite track
            st = QTUtils_GetTrackReferenceByName (mc, args[1]);
            mh = QTUtils_GetTrackMediaReferenceByName (mc, args[1]);
            if (st != NULL && mh != NULL)
            {                
                // Create point struct for event.where property
                myPoint.v = 0;
                myPoint.h = 0;
                
                // Create event struct
                event.version = 1L;
                event.eventType = eventID;
                event.where = myPoint;
                event.flags = 0L;
                                
                // Get action for sprite
                result = SpriteMediaGetSpriteActionsForQTEvent(mh, &event, spriteID, &myActions, &myActionAtom);
                if (result == noErr)
                {                    
                    // fill in a ResolvedQTEventSpec structure
                    myEventSpec.actionAtom.container = myActions;
                    myEventSpec.actionAtom.atom = myActionAtom;
                    myEventSpec.targetTrack = st;
                    myEventSpec.targetRefCon = spriteID;
                    
                    result = MCDoAction(mc, mcActionExecuteAllActionsForQTEvent, (void *)&myEventSpec);
                    if (result == noErr)
                    {
                        retstr = (char *)calloc(1,2);
                        retstr[0] = '0';
                    }
                    else
                    {
                        retstr = (char *)malloc(36);
                        snprintf(retstr, 36, "%s", "Unable to perform action on sprite");
                    }
                }
                else
                {
                    retstr = (char *)malloc(32);
                    snprintf(retstr, 32, "%s", "Couldn't get actions for sprite");
                }
            }
            else
            {
                retstr = (char *)malloc(36);
                snprintf(retstr, 36, "%s", "Unable to find Sprite Media Handler");
            }
        }
        else
        {
            retstr = (char *)malloc(38);
            snprintf(retstr, 38, "%s", "Invalid movie controller or sprite id");
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}


// assigns the movies QTList
// qtSetMovieQTList(MovieController, targetIdentifier, xmlstring)
void XCMD_SetQTList (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;

    QTAtomSpec 		myAtomSpecPtr;
    QTAtomContainer 	theContainer = NULL;
    QTAtom 		myFirstAtom = 0;
    QTAtom		myActionAtom = 0;
    QTAtom  		myTargetAtom = 0;

    long		theEvent = 0;
    long		targetIndex = 0;
    long		theStartIndex = 1;
    char *		theTargetParentPath = "";
    
    ComponentResult 	result = noErr;
    char *		retstr = NULL;

    *pass = false;
    *error = false;
    if (nargs == 3)
    {
        mc = (MovieController)atol(args[0]);
        targetIndex = atol(args[1]);

        if (mc != NULL && (long)mc > 0)
        {
            // Create a new container
            QTNewAtomContainer(&theContainer);

            //kActionListPasteFromXML       = 13315, /* (C string xml, C string targetParentPath, long startIndex) */

            // Create actionAtom
            result = WiredUtils_AddQTEventAndActionAtoms(theContainer, myFirstAtom, theEvent, kActionListPasteFromXML, &myActionAtom);
            //if (result != noErr)
                //goto bail;

            // Add actionAtom target
            if (targetIndex > 0) {
                // Target Track QTList by index
                result = WiredUtils_AddTrackTargetAtom (theContainer, myActionAtom, kTargetTrackIndex, &targetIndex, 0L);
            } else if (targetIndex == 0) {
                // Target movie QTList
                result = WiredUtils_AddMovieActionTargetAtom (theContainer, myActionAtom, &myTargetAtom);
            } else {
                // Target Track QTList by name
                result = WiredUtils_AddTrackTargetAtom (theContainer, myActionAtom, kTargetTrackName, args[1], 0L);
            }

            if (result != noErr) {
                retstr = (char *)malloc(21);
                snprintf(retstr, 21, "%s", "Error setting target");
                goto bail;
            }

            // Add actionAtom parameters
            if(WiredUtils_AddActionParameterAtom (theContainer, myActionAtom, kFirstParam, strlen(args[2]), args[2], NULL) != noErr) {
                retstr = (char *)malloc(21);
                snprintf(retstr, 21, "%s", "Error adding param 1");
                goto bail;
            }
            if (WiredUtils_AddActionParameterAtom (theContainer, myActionAtom, kSecondParam, sizeof(theTargetParentPath), theTargetParentPath, NULL) != noErr) {
                retstr = (char *)malloc(21);
                snprintf(retstr, 21, "%s", "Error adding param 2");
                goto bail;
            }
            theStartIndex = EndianU32_NtoB(theStartIndex);
            if (WiredUtils_AddActionParameterAtom (theContainer, myActionAtom, kThirdParam, sizeof(theStartIndex), &theStartIndex, NULL) != noErr) {
                retstr = (char *)malloc(21);
                snprintf(retstr, 21, "%s", "Error adding param 3");
                goto bail;
            }
            
            // create ResolvedQTEventSpec structure
            myAtomSpecPtr.container = theContainer;
            myAtomSpecPtr.atom = myFirstAtom;
            
            MCDoAction(mc, mcActionPerformActionList, (void *)&myAtomSpecPtr);

            QTDisposeAtomContainer(theContainer);
                
            if (result == noErr)
            {
                retstr = (char *)calloc(1,2);
                retstr[0] = '0';
            }
            else
            {
                //retstr = (char *)malloc(21);
                retstr = (char *)malloc(100);
                snprintf(retstr, 100, "%s: %hd", "Unable to set QTList", (short)result);
            }
        }
        else
        {
            retstr = (char *)malloc(25);
            snprintf(retstr, 25, "%s", "Invalid movie controller");
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }

bail:
    *retstring = retstr;
}


// returns the movie/track qtlist
// qtGetMovieQTList(MovieController, targetIdentifier)
void XCMD_GetQTList (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController 	mc = NULL;
    Movie		mv = NULL;

    long		targetIndex = 0;
    QTAtomContainer 	theContainer = NULL;
    QTAtom 		currentQTList = 0;
    long 		dataSize;
    Ptr 		atomData;

    ComponentResult 	result = noErr;
    char *		retstr = NULL;

    *pass = false;
    *error = false;
    if (nargs == 2)
    {
        mc = (MovieController)atol(args[0]);
        targetIndex = atol(args[1]);

        if (mc != NULL && (long)mc > 0)
        {
            mv = MCGetMovie(mc);
            
            // Create a new container
            QTNewAtomContainer(&theContainer);

            // NOTE: This currently always targets the movie.  Haven't found out how to get a track
            // QTList yet.  I didn't see a similar function to GetMoviePropertyAtom for a track.

            GetMoviePropertyAtom (mv, &theContainer);
            if (theContainer) {
                currentQTList = QTFindChildByID(theContainer, kParentAtomIsContainer, 'xml ', 1, NULL);
                if (currentQTList > 0) {
                    result = QTGetAtomDataPtr(theContainer, currentQTList, &dataSize, &atomData);
                    retstr = (char *)malloc(dataSize + 1);
                    snprintf(retstr, dataSize + 1, "%s", (char *)atomData);
                } else {
                    retstr = (char *)malloc(100);
                    snprintf(retstr, 100, "%s: %hd", "Unable to find QTList", (short)result); 
                }
                QTDisposeAtomContainer(theContainer); 
            }

            if (result != noErr)
            {
                //retstr = (char *)malloc(21);
                retstr = (char *)malloc(100);
                snprintf(retstr, 100, "%s: %hd", "Unable to get QTList", (short)result);
            }
        }
        else
        {
            retstr = (char *)malloc(25);
            snprintf(retstr, 25, "%s", "Invalid movie controller");
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }

    *retstring = retstr;

//bail:
    //*retstring = retstr;
}



// getSpriteVariableAsFloat(controllerID, trackName, address)
void XCMD_GetSpriteVariableAsFloat (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    MediaHandler mh = NULL;
    QTAtomID variableID = 0L;
    float floatValue = 0;
    ComponentResult result = noErr;
    //char *mTrackName = "Movie Variables";
    char *retstr = NULL;
    
    // initialize the movie controller as desired
    *pass = false;
    *error = false;
    if (nargs == 3) {
        mc = (MovieController)atol(args[0]);
        variableID = (float)atof(args[2]);
        
        if (mc != NULL && (long)mc > 0) {
            mh = QTUtils_GetTrackMediaReferenceByName (mc, args[1]);
            if (mh != NULL)
            {
                result= SpriteMediaGetActionVariable(mh, variableID, &floatValue);
                // errrr, it could be a lot more digits than that, I think ... alex
                //retstr = (char *)malloc(sizeof(float) + 1);
                retstr = (char *)malloc(32);
                snprintf(retstr, 32, "%f", floatValue);   
            }
            else
            {
                retstr = (char *)malloc(100);
                snprintf(retstr, 100, "%s", "Unable to find Sprite Media Handler");
            }
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}


// getSpriteVariableAsString(controllerID, trackName, variableAddress)
void XCMD_GetSpriteVariableAsString (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
   {
   MovieController mc = NULL;
   MediaHandler mh = NULL;
   QTAtomID variableID = 0L;
   Handle theStringVar = NULL;
   long length = 0;
   const long fixedLen = 2048;
   //char myCString[2049];
   char *retstr = NULL;

   // initialize the movie controller as desired
   *pass = false;
   *error = false;
   if (nargs == 3)
      {
      debugassert(args[0] == NULL, "\pbad args[0] in XCMD_GetSpriteVariableAsString")
      mc = (MovieController)atol(args[0]);
      
      debugassert(args[2] == NULL, "\pbad args[2] in XCMD_GetSpriteVariableAsString")
      variableID = (long)atol(args[2]);

      if (mc != NULL && (long)mc > 0)
         {
         mh = QTUtils_GetTrackMediaReferenceByName (mc, args[1]);
         if (mh != NULL)
            {
            OSErr getErr = SpriteMediaGetActionVariableAsString(mh, variableID, &theStringVar);
            if ((getErr == noErr) && (NULL != theStringVar))
               {
               length = GetHandleSize(theStringVar);
               if (length > fixedLen - 1)
                  length = fixedLen - 1;

               retstr = (char *)calloc(1, length + 1);
               snprintf(retstr, length + 1, *theStringVar);
               DisposeHandle(theStringVar);
               }
            else
               {
               retstr = (char *)malloc(29);
               snprintf(retstr, 29, "%s", "Unable to retrieve variable");
               }
            }
         else
            {
            retstr = (char *)malloc(35);
            snprintf(retstr, 35, "%s", "Unable to retrieve track reference");
            }
         }
      else
         {
         retstr = (char *)malloc(24);
         snprintf(retstr, 24, "%s", "Invalid Movie Controller");
         }
      }
   else
      {
      retstr = (char *)malloc(28);
      snprintf(retstr, 28, "%s", "Invalid number of arguments");
      }

   *retstring = retstr;
   }


// setSpriteVariableToFloat(controllerID, trackName, variableAddress, value)
void XCMD_SetSpriteVariableToFloat (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    MediaHandler mh = NULL;
    QTAtomID variableID = 0L;
    float variableValue = 0;
    ComponentResult result = noErr;
    char *retstr = NULL;
    
    // initialize the movie controller as desired
    *pass = false;
    *error = false;
    if (nargs == 4) {
        mc = (MovieController)atol(args[0]);
        variableID = (float)atof(args[2]);
        variableValue = (float)atof(args[3]);
        
        if (mc != NULL && (long)mc > 0) {
            mh = QTUtils_GetTrackMediaReferenceByName (mc, args[1]);
            if (mh != NULL)
            {
                result = SpriteMediaSetActionVariable(mh, variableID, &variableValue);  
            }
        }
        
        retstr = calloc(1, 2);
        if (retstr != NULL)
            retstr[0] = (result == noErr) ? '0': '1';
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}


// setSpriteVariableToString(controllerID, trackName, variableAddress, value)
void XCMD_SetSpriteVariableToString (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    MediaHandler mh = NULL;
    QTAtomID variableID = 0L;
    ComponentResult result = noErr;
    char *retstr = NULL;
    
    // initialize the movie controller as desired
    *pass = false;
    *error = false;
    if (nargs == 4) {
        mc = (MovieController)atol(args[0]);
        variableID = (float)atof(args[2]);
        
        if (mc != NULL && (long)mc > 0) {
            mh = QTUtils_GetTrackMediaReferenceByName (mc, args[1]);
            if (mh != NULL)
            {
                result = SpriteMediaSetActionVariableToString(mh, variableID, args[3]);
            }
        }
        
        retstr = calloc(1, 2);
        if (retstr != NULL)
            retstr[0] = (result == noErr) ? '0': '1';
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}


//////////
//
// Movie Load State
//
// Functions for getting movie load state
//////////


// getMovieLoadState (mc)
// Returns:
// kMovieLoadStateError              -1
// kMovieLoadStateLoading            1000
// kMovieLoadStatePlayable           10000
// kMovieLoadStatePlayThroughOK      20000
// kMovieLoadStateComplete           100000
// This function lets your code perform relative comparisons against movie loading 
// milestones to determine if certain operations make sense. Its return values are 
// ordered so that they conform to this rule:
// kMovieLoadStateError 
// < kMovieLoadStateLoading 
// < kMovieLoadStatePlayable 
// < kMovieLoadStateComplete

void XCMD_GetMovieLoadState (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    Movie mv = NULL;
    long movieState = 0L;
    char *retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 1) {
        mc = (MovieController)atol(args[0]);
    
        if (mc != NULL && (long)mc > 0) {
            mv = MCGetMovie(mc);
            movieState = GetMovieLoadState(mv);
        }
        
        retstr = (char *) malloc(R4L);
        snprintf(retstr, R4L, "%ld", movieState);
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}


// getMaxLoadedTimeInMovie (mc)
// Returns:
// amount of movie downloaded in movie's time coordinate system
void XCMD_GetMaxLoadedTimeInMovie (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    Movie mv = NULL;
    TimeValue time = 0;
    ComponentResult result = noErr;
    char *retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 1) {
        mc = (MovieController)atol(args[0]);
        
        if (mc != NULL && (long)mc > 0) {
            mv = MCGetMovie(mc);
            result = GetMaxLoadedTimeInMovie(mv, &time);
        }

        //TUV MEMORY ERROR!!!!!!!!!!!!!! long is 4 bytes = 4 characters on some systems. Need to allocate at least
        //16 characters        
        retstr = (char *) malloc(U4L);
        snprintf(retstr, U4L, "%ld", time);
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}


//////////
//
// QTVR
//
// Functions for working with QTVR
//////////


// qtQTVRNudge (MovieController, direction)
// Nudges QTVR in direction specified
void XCMD_QTVRNudge (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController         mc = NULL;
    Movie                   mv = NULL;
    Track                   qtvrTrack = NULL;
    QTVRInstance            qtvrInstance = NULL;
    ComponentResult         result = noErr;
    char *                  retstr = NULL;
    UInt32                  direction = 0;
    
    *pass = false;
    *error = false;
    if (nargs == 2)
    {
        mc = (MovieController)atol(args[0]);
        
        if (mc != NULL && (long)mc > 0 && QTVR_Init())
        {
			mv = MCGetMovie(mc);
            qtvrTrack = QTVRGetQTVRTrack (mv, 1);
            if (qtvrTrack != NULL)
            {
                QTVRGetQTVRInstance(&qtvrInstance, qtvrTrack, mc);
                if (qtvrInstance != NULL)
                {
                    ExtUtils_ToLowerCase(args[1]);
                    
                    // Determine which event to trigger
                    if (strcmp(args[1], "right") == 0) {    
                        direction = kQTVRRight;
                    } else if (strcmp(args[1], "upright") == 0) {    
                        direction = kQTVRUpRight;
                    } else if (strcmp(args[1], "up") == 0) {    
                        direction = kQTVRUp;
                    } else if (strcmp(args[1], "upleft") == 0) {    
                        direction = kQTVRUpLeft;
                    } else if (strcmp(args[1], "left") == 0) {    
                        direction = kQTVRLeft;
                    } else if (strcmp(args[1], "downleft") == 0) {    
                        direction = kQTVRDownLeft;
                    } else if (strcmp(args[1], "down") == 0) {    
                        direction = kQTVRDown;
                    } else {
                        direction = kQTVRDownRight;
                    }

                    result = QTVRNudge(qtvrInstance, direction);
                    result = QTVRUpdate(qtvrInstance, kQTVRCurrentMode);
                    
                    if (result == noErr){
                        retstr = (char *)malloc(2);
                        retstr[0] = '0';
                    }
                    else{
                        retstr = (char *)malloc(18);
                        snprintf(retstr, 18, "%s", "Nudge didn't work");
                    }
                }
                else
                {
                    retstr = (char *)malloc(29);
                    snprintf(retstr, 29, "%s", "Unable to find QTVR Instance");
                }
            }
            else
            {
                retstr = (char *)malloc(26);
                snprintf(retstr, 26, "%s", "Unable to find QTVR Track");
            }
        }
        else
        {
            retstr = (char *)malloc(25);
            snprintf(retstr, 25, "%s", "Invalid movie controller");
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}


// qtQTVRSetInteractionProperty MovieController, property, value
// Sets properties for a VR
void XCMD_QTVRSetInteractionProperty (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController 	mc = NULL;
    Movie 		mv = NULL;
    Track 		qtvrTrack = NULL;
    QTVRInstance 	qtvrInstance = NULL;
    ComponentResult 	result = noErr;
    char *		retstr = NULL;
    UInt32		theProperty = 0;
    UInt32 		theValue = 0;
    float		theValueFloat = 0.0;

    *pass = false;
    *error = false;
    if (nargs == 3)
    {
        mc = (MovieController)atol(args[0]);

        if (mc != NULL && (long)mc > 0 && QTVR_Init())
        {
			mv = MCGetMovie(mc);
            qtvrTrack = QTVRGetQTVRTrack (mv, 1);
            if (qtvrTrack != NULL)
            {
                QTVRGetQTVRInstance(&qtvrInstance, qtvrTrack, mc);
                if (qtvrInstance != NULL)
                {
                    ExtUtils_ToLowerCase(args[1]);
                    
                    // Determine which property to set
                    if (strcmp(args[1], "mousemotionscale") == 0) {
                        theProperty = kQTVRInteractionMouseMotionScale;
                        theValueFloat = atof(args[2]);
                        result = QTVRSetInteractionProperty (qtvrInstance, theProperty, &theValueFloat);
                    }
                    else {                    
                        if (strcmp(args[1], "pantiltspeed") == 0) {
                            theProperty = kQTVRInteractionPanTiltSpeed;
                            theValue = atol(args[2]);
                            if (theValue < 1) theValue = 1;
                            if (theValue > 10) theValue = 10;
                        }
                        else if (strcmp(args[1], "mouseclickhysteresis") == 0) {
                            theProperty = kQTVRInteractionMouseClickHysteresis;
                            theValue = atol(args[2]);
                        }
                        else if (strcmp(args[1], "mouseclicktimeout") == 0) {
                            theProperty = kQTVRInteractionMouseClickTimeout;
                            theValue = atol(args[2]);
                        }
                        else if (strcmp(args[1], "zoomspeed") == 0) {
                            theProperty = kQTVRInteractionZoomSpeed;
                            theValue = atol(args[2]);
                            if (theValue < 1) theValue = 1;
                            if (theValue > 10) theValue = 10;
                        }
                        else if (strcmp(args[1], "translateonmousedown") == 0) {
                            theProperty = kQTVRInteractionTranslateOnMouseDown;
                            ExtUtils_ToLowerCase(args[2]);
                            if (strcmp(args[2], "true") == 0 || strcmp(args[3], "1") == 0)
                                theValue = 1;
                            else
                                theValue = 0;
                        }
                        else {
                            ExtUtils_ToLowerCase(args[2]);
                            theProperty = kQTVRInteractionNudgeMode;
                            if (strcmp(args[2], "nudgerotate") == 0) {
                                theValue = kQTVRNudgeRotate;
                            } else if (strcmp(args[2], "nudgetranslate") == 0) {
                                theValue = kQTVRNudgeTranslate;
                            } else {
                                theValue = kQTVRNudgeSameAsMouse;
                            }
                        }
                        
                        result = QTVRSetInteractionProperty (qtvrInstance, theProperty, (void *)theValue);
                    }

                    if (result == noErr){
                        retstr = (char *)calloc(1,2);
                        retstr[0] = '0';
                    }
                    else{
                        retstr = (char *)malloc(23);
                        snprintf(retstr, 23, "%s", "Unable to set property");
                    }
                }
                else
                {
                    retstr = (char *)malloc(29);
                    snprintf(retstr, 29, "%s", "Unable to find QTVR Instance");
                }
            }
            else
            {
                retstr = (char *)malloc(26);
                snprintf(retstr, 26, "%s", "Unable to find QTVR Track");
            }
        }
        else
        {
            retstr = (char *)malloc(25);
            snprintf(retstr, 25, "%s", "Invalid movie controller");
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }

    *retstring = retstr;
}


// qtQTVRSetQuality MovieController, ImagingMode, PropertyValue
// Sets imaging quality for a QTVR
//
// ImagingMode = static | motion | all
// PropertyValue = min | low | normal | high | max
void XCMD_QTVRSetQuality (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController 	mc = NULL;
    Movie 		mv = NULL;
    Track 		qtvrTrack = NULL;
    QTVRInstance 	qtvrInstance = NULL;
    ComponentResult 	result = noErr;
    char *		retstr = NULL;
    QTVRImagingMode     theMode = 0;
    UInt32 		theQuality = 0;

    *pass = false;
    *error = false;
    if (nargs == 3)
    {
        mc = (MovieController)atol(args[0]);

        if (mc != NULL && (long)mc > 0 && QTVR_Init())
        {
			mv = MCGetMovie(mc);
            qtvrTrack = QTVRGetQTVRTrack (mv, 1);
            if (qtvrTrack != NULL)
            {
                QTVRGetQTVRInstance(&qtvrInstance, qtvrTrack, mc);
                if (qtvrInstance != NULL)
                {
                    ExtUtils_ToLowerCase(args[1]);
                    ExtUtils_ToLowerCase(args[2]);
                    
                    // Determine which mode                   
                    if (strcmp(args[1], "static") == 0)
                        theMode = kQTVRStatic;
                    else if (strcmp(args[1], "motion") == 0)
                        theMode = kQTVRMotion;
                    else
                        theMode = kQTVRAllModes;
                        
                    // Determine quality
                    if (strcmp(args[2], "min") == 0)
                        theQuality = codecMinQuality;
                    else if (strcmp(args[2], "low") == 0)
                        theQuality = codecLowQuality;
                    else if (strcmp(args[2], "normal") == 0)
                        theQuality = codecNormalQuality;
                    else if (strcmp(args[2], "high") == 0)
                        theQuality = codecHighQuality;
                    else
                        theQuality = codecMaxQuality;
                    
                    result = QTVRSetImagingProperty (qtvrInstance, theMode, kQTVRImagingQuality, theQuality);

                    retstr = (char *)calloc(1,2);
                    if (result == noErr) 
                        retstr[0] = '0';
                    else
                        retstr[0] = '1';
                }
                else
                {
                    retstr = (char *)malloc(29);
                    snprintf(retstr, 29, "%s", "Unable to find QTVR Instance");
                }
            }
            else
            {
                retstr = (char *)malloc(26);
                snprintf(retstr, 26, "%s", "Unable to find QTVR Track");
            }
        }
        else
        {
            retstr = (char *)malloc(25);
            snprintf(retstr, 25, "%s", "Invalid movie controller");
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }

    *retstring = retstr;
}


// qtQTVRGetHotSpotName MovieController, hotSpotID
void XCMD_QTVRGetHotSpotName (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController 	mc = NULL;
    Movie 		mv = NULL;
    Track 		qtvrTrack = NULL;
    QTVRInstance 	qtvrInstance = NULL;
    UInt32              hotSpotID = 0;
    ComponentResult 	result = noErr;
    char *		retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 2)
    {
        mc = (MovieController)atol(args[0]);
        hotSpotID = (UInt32)atol(args[1]);
        
        if (mc != NULL && (long)mc > 0 && QTVR_Init())
        {
			mv = MCGetMovie(mc);
            qtvrTrack = QTVRGetQTVRTrack (mv, 1);
            if (qtvrTrack != NULL) {
                result = QTVRGetQTVRInstance(&qtvrInstance, qtvrTrack, mc);
                
                if (qtvrInstance != NULL) {
                    retstr = QTVRUtils_GetHotSpotName (qtvrInstance, QTVRGetCurrentNodeID(qtvrInstance), hotSpotID);
                }
                else {
                    retstr = (char *)malloc(29);
                    snprintf(retstr, 29, "%s", "Unable to find QTVR Instance");
                }
            }
            else {
                retstr = (char *)malloc(26);
                snprintf(retstr, 26, "%s", "Unable to find QTVR Track");
            }
        }
        else {
            retstr = (char *)malloc(25);
            snprintf(retstr, 25, "%s", "Invalid movie controller");
        }
    }
    else {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}


// qtQTVRGetHotSpotComment MovieController, hotSpotID
void XCMD_QTVRGetHotSpotComment (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController 	mc = NULL;
    Movie				mv = NULL;
    Track				qtvrTrack = NULL;
    QTVRInstance		qtvrInstance = NULL;
    UInt32              hotSpotID = 0;
    ComponentResult 	result = noErr;
    char *				retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 2)
    {
        mc = (MovieController)atol(args[0]);
        hotSpotID = (UInt32)atol(args[1]);
        
        if (mc != NULL && (long)mc > 0 && QTVR_Init())
        {
			mv = MCGetMovie(mc);
            qtvrTrack = QTVRGetQTVRTrack (mv, 1);
            if (qtvrTrack != NULL) {
                result = QTVRGetQTVRInstance(&qtvrInstance, qtvrTrack, mc);
                
                if (qtvrInstance != NULL) {
                    retstr = QTVRUtils_GetHotSpotComment (qtvrInstance, QTVRGetCurrentNodeID(qtvrInstance), hotSpotID);
                }
                else {
                    retstr = (char *)malloc(29);
                    snprintf(retstr, 29, "%s", "Unable to find QTVR Instance");
                }
            }
            else {
                retstr = (char *)malloc(26);
                snprintf(retstr, 26, "%s", "Unable to find QTVR Track");
            }
        }
        else {
            retstr = (char *)malloc(25);
            snprintf(retstr, 25, "%s", "Invalid movie controller");
        }
    }
    else {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}



// qtQTVREnableHotSpot MovieController, hotSpotType, hotSpotTypeValue, trueOrFalse
// hotSpotType can be "id", "type", "all"
// hotSpotTypeValue:
//    id= hotSpotID
//    type= "link", "url", "undefined"
void XCMD_QTVREnableHotSpot (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController 	mc = NULL;
    Movie				mv = NULL;
    Track				qtvrTrack = NULL;
    QTVRInstance		qtvrInstance = NULL;
    UInt32              enableFlag;
    UInt32              hotSpotValue = 0;
    Boolean             enable = false;
    ComponentResult 	result = noErr;
    char *				retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 4)
    {
        mc = (MovieController)atol(args[0]);
        
        if (mc != NULL && (long)mc > 0 && QTVR_Init())
        {
			mv = MCGetMovie(mc);
            qtvrTrack = QTVRGetQTVRTrack (mv, 1);
            if (qtvrTrack != NULL) {
                result = QTVRGetQTVRInstance(&qtvrInstance, qtvrTrack, mc);
                
                if (qtvrInstance != NULL) {
                    ExtUtils_ToLowerCase(args[1]);
                    ExtUtils_ToLowerCase(args[3]);
                    
                    // Get enabled
                    if (strcmp(args[3], "true") == 0)
                        enable = true;
                        
                    // Determine type
                    if (strcmp(args[1], "id") == 0) {
                        enableFlag = kQTVRHotSpotID;
                        hotSpotValue = (UInt32)atol(args[2]);
                    } else if (strcmp(args[1], "type") == 0) {
                        enableFlag = kQTVRHotSpotType;
                        
                        ExtUtils_ToLowerCase(args[2]);
                        
                        if (strcmp(args[2], "link") == 0) {
                            hotSpotValue = kQTVRHotSpotLinkType;
                        } else if (strcmp(args[2], "url") == 0) {
                            hotSpotValue = kQTVRHotSpotURLType;
                        } else {
                            hotSpotValue = kQTVRHotSpotUndefinedType;
                        }
                    } else {
                        enableFlag = kQTVRAllHotSpots;
                    }
                    
                    result = QTVREnableHotSpot (qtvrInstance, enableFlag, hotSpotValue, enable);
                    
                    if (result == noErr) {
                        retstr = (char *)calloc(1,2);
                        retstr[0] = '0';
                    }
                    else {
                        retstr = (char *)malloc(26);
                        snprintf(retstr, 26, "%s", "Error setting hotspot state");
                    }
                }
                else {
                    retstr = (char *)malloc(29);
                    snprintf(retstr, 29, "%s", "Unable to find QTVR Instance");
                }
            }
            else {
                retstr = (char *)malloc(26);
                snprintf(retstr, 26, "%s", "Unable to find QTVR Track");
            }
        }
        else {
            retstr = (char *)malloc(25);
            snprintf(retstr, 25, "%s", "Invalid movie controller");
        }
    }
    else {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}


// qtQTVRShowDefaultView (MovieController)
void XCMD_QTVRShowDefaultView (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    Movie mv = NULL;
    Track qtvrTrack = NULL;
    QTVRInstance qtvrInstance = NULL;
    ComponentResult result = noErr;
    char *retstr = NULL;

    *pass = false;
    *error = false;
    if (nargs == 2)
    {
        mc = (MovieController)atol(args[0]);

        if (mc != NULL && (long)mc > 0 && QTVR_Init())
        {
			mv = MCGetMovie(mc);
            qtvrTrack = QTVRGetQTVRTrack (mv, 1);
            if (qtvrTrack != NULL)
            {
                QTVRGetQTVRInstance(&qtvrInstance, qtvrTrack, mc);
                if (qtvrInstance != NULL)
                {
                    
                    result = QTVRShowDefaultView(qtvrInstance);

                    if (result == noErr){
                        retstr = (char *)calloc(1, 2);
                        retstr[0] = '0';
                    }
                    else{
                        retstr = (char *)malloc(26);
                        snprintf(retstr, 26, "%s", "Unable to set default view");
                    }
                }
                else
                {
                    retstr = (char *)malloc(29);
                    snprintf(retstr, 29, "%s", "Unable to find QTVR Instance");
                }
            }
            else
            {
                retstr = (char *)malloc(26);
                snprintf(retstr, 26, "%s", "Unable to find QTVR Track");
            }
        }
        else
        {
            retstr = (char *)malloc(25);
            snprintf(retstr, 25, "%s", "Invalid movie controller");
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }

    *retstring = retstr;
}


// qtQTVRSwing MovieController, pan, tilt, fov, speed, direction
void XCMD_QTVRSwing (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController 	mc = NULL;
    Movie				mv = NULL;
    Track				qtvrTrack = NULL;
    QTVRInstance		qtvrInstance = NULL;
    float				pan = 0;
	float				tilt = 0;
	float				fov = 0;
	SInt32				speed = 1;
	UInt32				direction = 0;
    ComponentResult 	result = noErr;
    char *				retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 6)
    {
        mc = (MovieController)atol(args[0]);
		pan = (float)atof(args[1]);
		tilt = (float)atof(args[2]);
		fov = (float)atof(args[3]);
		speed = (long)atol(args[4]);
		ExtUtils_ToLowerCase(args[5]);
		
		// Determine which event to trigger
		if (strcmp(args[5], "right") == 0)
			direction = kQTVRRight;
		else if (strcmp(args[5], "left") == 0)
			direction = kQTVRLeft;
		else
			direction = -1;

        if (mc != NULL && (long)mc > 0 && QTVR_Init())
        {
			mv = MCGetMovie(mc);
            qtvrTrack = QTVRGetQTVRTrack (mv, 1);
            if (qtvrTrack != NULL) {
                result = QTVRGetQTVRInstance(&qtvrInstance, qtvrTrack, mc);
                
                if (qtvrInstance != NULL) {
					
					QTVRSetTransitionProperty(qtvrInstance, kQTVRTransitionSwing, kQTVRTransitionSpeed, speed);
					// kQTVRRight, kQTVRUpLeft
					QTVRSetTransitionProperty(qtvrInstance, kQTVRTransitionSwing, kQTVRTransitionDirection, direction);
					QTVREnableTransition(qtvrInstance, kQTVRTransitionSwing, true);
					
					QTVRUpdate (qtvrInstance, kQTVRCurrentMode);
					
					// set target view in this order - fov, tilt and the pan
					QTVRSetFieldOfView(qtvrInstance, fov);
					QTVRSetTiltAngle(qtvrInstance, tilt);
					QTVRSetPanAngle(qtvrInstance, pan);
					
					QTVRUpdate (qtvrInstance, kQTVRCurrentMode);
					
                    retstr = (char *)calloc(1, 2);
                    retstr[0] = '0';
                }
                else {
                    retstr = (char *)malloc(29);
                    snprintf(retstr, 29, "%s", "Unable to find QTVR Instance");
                }
            }
            else {
                retstr = (char *)malloc(26);
                snprintf(retstr, 26, "%s", "Unable to find QTVR Track");
            }
        }
        else {
            retstr = (char *)malloc(25);
            snprintf(retstr, 25, "%s", "Invalid movie controller");
        }
    }
    else {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}


// qtQTVRSwingStop MovieController
void XCMD_QTVRSwingStop (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController 	mc = NULL;
    Movie				mv = NULL;
    Track				qtvrTrack = NULL;
    QTVRInstance		qtvrInstance = NULL;
    ComponentResult 	result = noErr;
    char *				retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 1)
    {
        mc = (MovieController)atol(args[0]);

        if (mc != NULL && (long)mc > 0 && QTVR_Init())
        {
			mv = MCGetMovie(mc);
            qtvrTrack = QTVRGetQTVRTrack (mv, 1);
            if (qtvrTrack != NULL) {
                result = QTVRGetQTVRInstance(&qtvrInstance, qtvrTrack, mc);
                
                if (qtvrInstance != NULL) {
					QTVREnableTransition(qtvrInstance, kQTVRTransitionSwing, false);
					QTVRUpdate (qtvrInstance, kQTVRCurrentMode);
					
                    retstr = (char *)calloc(1, 2);
                    retstr[0] = '0';
                }
                else {
                    retstr = (char *)malloc(29);
                    snprintf(retstr, 29, "%s", "Unable to find QTVR Instance");
                }
            }
            else {
                retstr = (char *)malloc(26);
                snprintf(retstr, 26, "%s", "Unable to find QTVR Track");
            }
        }
        else {
            retstr = (char *)malloc(25);
            snprintf(retstr, 25, "%s", "Invalid movie controller");
        }
    }
    else {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}


//////////
//
// Sound Track
//
// Functions for working with sound tracks in a QT movie
//////////


// qtGetTrackVolume (MovieController, TrackName|TrackIndex)
void XCMD_GetTrackVolume (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    Movie mv = NULL;
    Track tr = NULL;
    long trackIndex = 0;
    short volume = 0;
    char *retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 2)
    {
        mc = (MovieController)atol(args[0]);
        trackIndex = atol(args[1]);
        
        if (mc != NULL && (long)mc > 0)
        {
            // If no track name or index was given then set index to 1
            if (trackIndex == 0 && strlen(args[1]) < 1)
                trackIndex = 1;
            
            // args[1] is a number search by track index, otherwise by name
            if (trackIndex > 0) {
                mv = MCGetMovie(mc);
                tr = GetMovieIndTrackType (mv, trackIndex, AudioMediaCharacteristic, movieTrackCharacteristic | movieTrackEnabledOnly);
            } else 
                tr = QTUtils_GetTrackReferenceByName (mc, args[1]);
            
            if (tr != NULL)
            {
                volume = GetTrackVolume(tr);
                // hmmmm, it could have more digits than that maybe ...alex
                //retstr = (char *)malloc(sizeof(short) + 1);
                retstr = (char *)malloc(32);
                snprintf(retstr, 32, "%hi", volume);   
            }
            else
            {
                retstr = (char *)malloc(35);
                snprintf(retstr, 35, "%s", "Unable to find Audio Media Handler");
            }
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}


// qtSetTrackVolume (MovieController, TrackName|TrackIndex, Value)
void XCMD_SetTrackVolume (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    Movie mv = NULL;
    Track tr = NULL;
    long trackIndex = 0;
    short volume = 0;
    char *retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 3)
    {
        mc = (MovieController)atol(args[0]);
        trackIndex = atol(args[1]);
        volume = (short)atoi(args[2]);
        
        if (volume > 256) 
            volume = 256;
        if (volume < -256)
            volume = -256;
        
        if (mc != NULL && (long)mc > 0)
        {
            // If no track name or index was given then set index to 1
            if (trackIndex == 0 && strlen(args[1]) < 1)
                trackIndex = 1;
            
            // args[1] is a number search by track index, otherwise by name
            if (trackIndex > 0) {
                mv = MCGetMovie(mc);
                tr = GetMovieIndTrackType (mv, trackIndex, AudioMediaCharacteristic, movieTrackCharacteristic | movieTrackEnabledOnly);
            } else 
                tr = QTUtils_GetTrackReferenceByName (mc, args[1]);
            
            if (tr != NULL)
            {
                SetTrackVolume(tr, volume);  
            }
            else
            {
                retstr = (char *)malloc(35);
                snprintf(retstr, 35, "%s", "Unable to find Audio Media Handler");
            }
        }
        
        if (retstr == NULL) {
            retstr = calloc(1, 2);
            if (retstr != NULL)
                retstr[0] = '0';
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }

    *retstring = retstr;
}


// qtGetTrackBalance (MovieController, TrackName|TrackIndex)
void XCMD_GetMediaSoundBalance (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    Movie mv = NULL;
    MediaHandler mh = NULL;
    long trackIndex = 0;
    short balance = 0;
    ComponentResult result = noErr;
    char *retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 2)
    {
        mc = (MovieController)atol(args[0]);
        trackIndex = atol(args[1]);
        
        if (mc != NULL && (long)mc > 0)
        {
            // If no track name or index was given then set index to 1
            if (trackIndex == 0 && strlen(args[1]) < 1)
                trackIndex = 1;
            
            // args[1] is a number search by track index, otherwise by name
            if (trackIndex > 0) {
                mv = MCGetMovie(mc);
                mh = QTUtils_GetTrackMediaReferenceByType (mv, trackIndex, AudioMediaCharacteristic, movieTrackCharacteristic | movieTrackEnabledOnly);
            } else 
                mh = QTUtils_GetTrackMediaReferenceByName (mc, args[1]);
            
            if (mh != NULL)
            {
                result= MediaGetSoundBalance(mh, &balance);
                // how many digits can it have? ...alex
                //retstr = (char *)malloc(sizeof(short) + 1);
                retstr = (char *)malloc(32);
                snprintf(retstr, 32, "%hi", balance);   
            }
            else
            {
                retstr = (char *)malloc(35);
                snprintf(retstr, 35, "%s", "Unable to find Audio Media Handler");
            }
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}


// qtSetTrackBalance (controllerID, TrackName|TrackIndex, Value)
// Values range from 127 (right channel only) to -128 (left channel only)
void XCMD_SetMediaSoundBalance (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    Movie mv = NULL;
    MediaHandler mh = NULL;
    long trackIndex = 0;
    short balance = 0;
    ComponentResult result = noErr;
    char *retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 3)
    {
        mc = (MovieController)atol(args[0]);
        trackIndex = atol(args[1]);
        balance = (short)atoi(args[2]);
        
        if (balance > 127) 
            balance = 127;
        if (balance < -128)
            balance = -128;
        
        if (mc != NULL && (long)mc > 0)
        {
            // If no track name or index was given then set index to 1
            if (trackIndex == 0 && strlen(args[1]) < 1)
                trackIndex = 1;
            
            // args[1] is a number search by track index, otherwise by name
            if (trackIndex > 0) {
                mv = MCGetMovie(mc);
                mh = QTUtils_GetTrackMediaReferenceByType (mv, trackIndex, AudioMediaCharacteristic, movieTrackCharacteristic | movieTrackEnabledOnly);
            } else 
                mh = QTUtils_GetTrackMediaReferenceByName (mc, args[1]);
            
            if (mh != NULL)
            {
                result= MediaSetSoundBalance(mh, balance);
            }
            else
            {
                retstr = (char *)malloc(100);
                snprintf(retstr, 100, "%s", "Unable to find Audio Media Handler");
            }
        }
        
        if (retstr == NULL) {
            retstr = calloc(1, 2);
            if (retstr != NULL)
                retstr[0] = (result == noErr) ? '0': '1';
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}


// getTrackSoundBassAndTreble (MovieController, TrackName|TrackIndex)
void XCMD_GetMediaGetSoundBassAndTreble (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    Movie mv = NULL;
    MediaHandler mh = NULL;
    long trackIndex = 0;
    short bass = 0;
    short treble = 0;
    ComponentResult result = noErr;
    char *retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 2)
    {
        mc = (MovieController)atol(args[0]);
        trackIndex = atol(args[1]);
        
        if (mc != NULL && (long)mc > 0)
        {
            // If no track name or index was given then set index to 1
            if (trackIndex == 0 && strlen(args[1]) < 1)
                trackIndex = 1;
            
            // args[1] is a number search by track index, otherwise by name
            if (trackIndex > 0) {
                mv = MCGetMovie(mc);
                mh = QTUtils_GetTrackMediaReferenceByType (mv, trackIndex, AudioMediaCharacteristic, movieTrackCharacteristic | movieTrackEnabledOnly);
            } else 
                mh = QTUtils_GetTrackMediaReferenceByName (mc, args[1]);
            
            if (mh != NULL)
            {
                result= MediaGetSoundBassAndTreble(mh, &bass, &treble);
                // how many digits can it have? ...alex
                //retstr = (char *)malloc(sizeof(short) + 1);
                retstr = (char *)malloc(32);
                snprintf(retstr, 32, "%hi,%hi", bass, treble);   
            }
            else
            {
                retstr = (char *)malloc(100);
                snprintf(retstr, 100, "%s", "Unable to find Audio Media Handler");
            }
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}


// setTrackBassAndTreble (controllerID, TrackName|TrackIndex, Bass, Treble)
// Values for Bass and Treble can be between -256 and 256
void XCMD_SetMediaSetSoundBassAndTreble (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    Movie mv = NULL;
    MediaHandler mh = NULL;
    long trackIndex = 0;
    short bass = 0;
    short treble= 0;
    ComponentResult result = noErr;
    char *retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 4)
    {
        mc = (MovieController)atol(args[0]);
        trackIndex = atol(args[1]);
        bass = (short)atoi(args[2]);
        treble = (short)atoi(args[3]);
        
        if (bass > 256)
            bass = 256;
        else if (bass < -256)
            bass = -256;
        if (treble > 256)
            treble = 256;
        else if (treble < -256)
            treble = -256;
        
        if (mc != NULL && (long)mc > 0)
        {
            // If no track name or index was given then set index to 1
            if (trackIndex == 0 && strlen(args[1]) < 1)
                trackIndex = 1;
            
            // args[1] is a number search by track index, otherwise by name
            if (trackIndex > 0) {
                mv = MCGetMovie(mc);
                mh = QTUtils_GetTrackMediaReferenceByType (mv, trackIndex, AudioMediaCharacteristic, movieTrackCharacteristic | movieTrackEnabledOnly);
            } else 
                mh = QTUtils_GetTrackMediaReferenceByName (mc, args[1]);
            
            if (mh != NULL)
            {
                result= MediaSetSoundBassAndTreble(mh, bass, treble);
            }
            else
            {
                retstr = (char *)malloc(100);
                snprintf(retstr, 100, "%s", "Unable to find Audio Media Handler");
            }
        }
        
        if (retstr == NULL) {
            retstr = calloc(1, 2);
            if (retstr != NULL)
                retstr[0] = (result == noErr) ? '0': '1';
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}

//////////
//
// Controller Properties
//
// Functions for changing the controller in Revolution
//////////


// qtEnableVolumeControl (MovieController, true|false)
void XCMD_EnableVolumeControl (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    long myControllerFlags;
    ComponentResult result = noErr;
    char *retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 2)
    {
        mc = (MovieController)atol(args[0]);
        if (mc != NULL && (long)mc > 0)
        {
            // get the current explicit flags and set the explicit flag for the specified button
            myControllerFlags = mcFlagQTVRExplicitFlagSet;
            MCDoAction(mc, mcActionGetFlags, &myControllerFlags);
            MCDoAction(mc, mcActionSetFlags, (void *)((myControllerFlags | mcFlagSuppressSpeakerButton) | mcFlagQTVRExplicitFlagSet));
            
            ExtUtils_ToLowerCase(args[1]);
            
            if (strcmp(args[1], "true") == 0) {
                // get the current control flags and clear the suppress flag for the specified button
                myControllerFlags = 0;
                MCDoAction(mc, mcActionGetFlags, &myControllerFlags);
                MCDoAction(mc, mcActionSetFlags, (void *)(myControllerFlags & ~mcFlagSuppressSpeakerButton & ~mcFlagQTVRExplicitFlagSet));
            } else {                
                // get the current control flags and set the suppress flag for the specified button
                myControllerFlags = 0;
                MCDoAction(mc, mcActionGetFlags, &myControllerFlags);
                MCDoAction(mc, mcActionSetFlags, (void *)((myControllerFlags | mcFlagSuppressSpeakerButton) & ~mcFlagQTVRExplicitFlagSet));
            }
        }
        
        if (retstr == NULL) {
            retstr = calloc(1, 2);
            if (retstr != NULL)
                retstr[0] = (result == noErr) ? '0': '1';
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}


// qtEnableStepButtons (MovieController, true|false)
void XCMD_EnableStepButtons (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    long myControllerFlags;
    ComponentResult result = noErr;
    char *retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 2)
    {
        mc = (MovieController)atol(args[0]);
        if (mc != NULL && (long)mc > 0)
        {
            // get the current explicit flags and set the explicit flag for the specified button
            myControllerFlags = mcFlagQTVRExplicitFlagSet;
            MCDoAction(mc, mcActionGetFlags, &myControllerFlags);
            MCDoAction(mc, mcActionSetFlags, (void *)((myControllerFlags | mcFlagSuppressStepButtons) | mcFlagQTVRExplicitFlagSet));
            
            ExtUtils_ToLowerCase(args[1]);
            
            if (strcmp(args[1], "true") == 0) {
                // get the current control flags and clear the suppress flag for the specified button
                myControllerFlags = 0;
                MCDoAction(mc, mcActionGetFlags, &myControllerFlags);
                MCDoAction(mc, mcActionSetFlags, (void *)(myControllerFlags & ~mcFlagSuppressStepButtons & ~mcFlagQTVRExplicitFlagSet));
            } else {                
                // get the current control flags and set the suppress flag for the specified button
                myControllerFlags = 0;
                MCDoAction(mc, mcActionGetFlags, &myControllerFlags);
                MCDoAction(mc, mcActionSetFlags, (void *)((myControllerFlags | mcFlagSuppressStepButtons) & ~mcFlagQTVRExplicitFlagSet));
            }
        }
        
        if (retstr == NULL) {
            retstr = calloc(1, 2);
            if (retstr != NULL)
                retstr[0] = (result == noErr) ? '0': '1';
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}


//////////
//
// Track Functions
//
//////////
// qtGetTrackEnabled (MovieController, TrackName|TrackIndex)
void XCMD_GetTrackEnabled (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    Movie mv = NULL;
    Track tr = NULL;
    long trackIndex = 0;
    Boolean enabled = false;
    char *retstr = NULL;

    *pass = false;
    *error = false;
    if (nargs == 2)
    {
        mc = (MovieController)atol(args[0]);
        trackIndex = atol(args[1]);
    
        if (mc != NULL && (long)mc > 0)
        {
            // If no track name or index was given then set index to 1
            if (trackIndex == 0 && strlen(args[1]) < 1)
                trackIndex = 1;

            // args[1] is a number search by track index, otherwise by name
            if (trackIndex > 0) {
                mv = MCGetMovie(mc);
                tr = GetMovieTrack (mv, trackIndex);
            } else
                tr = QTUtils_GetTrackReferenceByName (mc, args[1]);

            if (tr != NULL)
            {
                enabled = GetTrackEnabled(tr);
            }
            else
            {
                retstr = (char *)malloc(35);
                snprintf(retstr, 35, "%s", "Unable to find Track Handler");
            }
        }

        if (retstr == NULL) {
            // think we only need 0 or 1 here? ...alex
            //retstr = malloc(sizeof(Boolean) + 1);
            //snprintf(retstr, "%i", enabled);
            retstr = calloc(1, 2);
            retstr[0] = enabled ? '1' : '0';
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }

    *retstring = retstr;
}


// qtSetTrackEnabled (MovieController, TrackName|TrackIndex, Value)
void XCMD_SetTrackEnabled (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    Movie mv = NULL;
    Track tr = NULL;
    long trackIndex = 0;
    Boolean enabled = false;
    char *retstr = NULL;

    *pass = false;
    *error = false;
    if (nargs == 3)
	{
        mc = (MovieController)atol(args[0]);
        trackIndex = atol(args[1]);

        if (mc != NULL && (long)mc > 0)
        {
            // If no track name or index was given then set index to 1
            if (trackIndex == 0 && strlen(args[1]) < 1)
                trackIndex = 1;

            // args[1] is a number search by track index, otherwise by name
            if (trackIndex > 0) {
                mv = MCGetMovie(mc);
                tr = GetMovieTrack (mv, trackIndex);
            } else
                tr = QTUtils_GetTrackReferenceByName (mc, args[1]);

            if (tr != NULL)
            {
                ExtUtils_ToLowerCase(args[2]);
                // This neeeds to be made case insensitive
                if (strcmp (args[2], "true") == 0 || strcmp (args[2], "1") == 0) {
                    enabled = true;
                }
                SetTrackEnabled(tr, enabled);
            }
            else
            {
                retstr = (char *)malloc(35);
                snprintf(retstr, 35, "%s", "Unable to find Track Handler");
            }
        }

        if (retstr == NULL) {
            retstr = calloc(1, 2);
            if (retstr != NULL)
                retstr[0] = '0';
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }

    *retstring = retstr;
}


// qtDeleteTrack (MovieController, TrackName|TrackIndex)
void XCMD_DeleteTrack (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    Movie mv = NULL;
    Track tr = NULL;
    long trackIndex = 0;
    char *retstr = NULL;

    *pass = false;
    *error = false;
    if (nargs == 2)
    {
        mc = (MovieController)atol(args[0]);
        trackIndex = atol(args[1]);

        if (mc != NULL && (long)mc > 0)
        {
            // If no track name or index was given then set index to 1
            if (trackIndex == 0 && strlen(args[1]) < 1)
                trackIndex = 1;

            // args[1] is a number search by track index, otherwise by name
            if (trackIndex > 0) {
                mv = MCGetMovie(mc);
                tr = GetMovieTrack (mv, trackIndex);
            } else
                tr = QTUtils_GetTrackReferenceByName (mc, args[1]);

            if (tr != NULL)
            {
                DisposeMovieTrack(tr);
            }
            else
            {
                retstr = (char *)malloc(35);
                snprintf(retstr, 35, "%s", "Unable to find Track Handler");
            }
        }

        if (retstr == NULL) {
            retstr = calloc(1, 2);
            if (retstr != NULL)
                retstr[0] = '0';
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }

    *retstring = retstr;
}


// qtGetTrackName (MovieController, TrackIndex)
void XCMD_GetTrackName (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
	MovieController		mc = NULL;
    Movie				mv = NULL;
	Track				tr = NULL;
	long				trackIndex = 0;
	OSErr				myErr = noErr;
	char				*retstr = NULL;
	
	*pass = false;
    *error = false;
    if (nargs == 2) {
        mc = (MovieController)atol(args[0]);
        trackIndex = atol(args[1]);
 
        if (mc != NULL && (long)mc > 0) {
			// If no track index was given then set index to 1
			if (trackIndex == 0)
				trackIndex = 1;
				
			mv = MCGetMovie(mc);
			tr = GetMovieIndTrack (mv, trackIndex);

            if (tr != NULL) {
				// a track's name (if it has one) is stored in the track's user data
				UserData myUserData = GetTrackUserData(tr);
				if (myUserData != NULL) {
					Handle			myHandle = NewHandle(0);

					// get the user data item of type kUserDataName;
					// the handle we pass to GetUserData is resized to contain the track name
					myErr = GetUserData (myUserData, myHandle, kUserDataName, 1);
					if (myErr == noErr) {
						long		myLength = GetHandleSize(myHandle);

						if (myLength > 0) {
							retstr = (char *)malloc(myLength + 1);
							snprintf(retstr, myLength + 1, *myHandle);
						}
					} else {
						retstr = calloc(1, 1);
						if (retstr != NULL)
							retstr[0] = '\0';
					}

					DisposeHandle(myHandle);
				}
			} else {
                retstr = (char *)malloc(35);
                snprintf(retstr, 35, "%s", "Unable to find Track Handler");
            }
        }

        if (retstr == NULL) {
            retstr = calloc(1, 2);
            if (retstr != NULL)
                retstr[0] = '0';
        }
    } else {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }

    *retstring = retstr;
}

// qtGetTrackNames (MovieController)
//void XCMD_GetTrackNames (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
//{
	/*
    MovieController			mc = NULL;
    Movie					mv = NULL;
	UserData				myUserData = NULL;
	int						x = 0;
	long					totalTracks = 0;
	char *					myString = NULL;
	long					myLength = 0;
    char *					retstr = NULL;
	OSErr					myErr = noErr;

    *pass = false;
    *error = false;
    if (nargs == 2) {
        mc = (MovieController)atol(args[0]);
		
        if (mc != NULL && (long)mc > 0) {
			// Loop through all tracks and get name
			mv = MCGetMovie(mc);
			totalTracks = GetMovieTrackCount(mv);
			
			myString = malloc(1);
			
			for (x = 1; x <= totalTracks; ++x) {
				Track curTrack = GetMovieIndTrack(mv, x);
				myUserData = GetTrackUserData(curTrack);
				if (myUserData != NULL) {
					Handle		myHandle = NewHandle(0);
					
					// get the user data item of type kUserDataName;
					// the handle we pass to GetUserData is resized to contain the track name
					myErr = GetUserData(myUserData, myHandle, kUserDataName, 1);
					if (myErr == noErr) {
						myLength = myLength + GetHandleSize(myHandle);
						
						if (myLength > 0) {
							myString = realloc(myLength);
							if (myString != NULL) {
								memcpy(myString, *myHandle, myLength);
							}
						}
					}
				}
			}
			
			myString = realloc(myLength + 1);
			myString[myLength + 1] = '\0';
			
				
				char name[256];
				Handle h = NewHandle(0);
				UserData ud = GetTrackUserData(curTrack);

				if (GetUserData(ud, h, kUserDataName, 1) == noErr)
				{
					long nameLength = GetHandleSize(h);
					if (nameLength > 255)
						nameLength = 255;
					BlockMoveData(*h, name, nameLength);
					name[nameLength] = 0;
				}
				else
					name[0] = 0;
				DisposeHandle(h);

				if (strcmp(name, trackName) == 0)
					return curTrack;
			}
		
		
            // If no track name or index was given then set index to 1
            if (trackIndex == 0 && strlen(args[1]) < 1)
                trackIndex = 1;

            // args[1] is a number search by track index, otherwise by name
            if (trackIndex > 0) {
                mv = MCGetMovie(mc);
                tr = GetMovieTrack (mv, trackIndex);
            } else
                tr = QTUtils_GetTrackReferenceByName (mc, args[1]);

            if (tr != NULL)
            {
                DisposeMovieTrack(tr);
            }
            else
            {
                retstr = (char *)malloc(35);
                snprintf(retstr, 35, "%s", "Unable to find Track Handler");
            }
        }

        if (retstr == NULL) {
            retstr = calloc(1, 2);
            if (retstr != NULL)
                retstr[0] = '0';
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }

    *retstring = retstr;
	*/
//}


// 	qtGetTrackType (MovieController, TrackIndex)
void XCMD_GetTrackType (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
	MovieController		mc = NULL;
    Movie				mv = NULL;
	Track				tr = NULL;
	Media				mh = NULL;
	long				trackIndex = 0;
	char *				retstr = NULL;
	
	*pass = false;
    *error = false;
    if (nargs == 2) {
        mc = (MovieController)atol(args[0]);
        trackIndex = atol(args[1]);
 
        if (mc != NULL && (long)mc > 0) {
            // If no track index was given then set index to 1
            if (trackIndex == 0)
                trackIndex = 1;

			mv = MCGetMovie(mc);
			tr = GetMovieIndTrack (mv, trackIndex);

            if (tr != NULL) {
				mh = GetTrackMedia(tr);
				if (mh != NULL) {					
					MediaHandler theMediaHandler = GetMediaHandler(mh);
					Str255 name;
					MediaGetName(theMediaHandler, name, 0, nil);
					
					retstr = QTUtils_ConvertPascalToCString(name);
				} else {
					retstr = (char *)malloc(35);
					snprintf(retstr, 35, "%s", "Unable to find Media Handler");
				}
			} else {
                retstr = (char *)malloc(35);
                snprintf(retstr, 35, "%s", "Unable to find Track Handler");
            }
        }

        if (retstr == NULL) {
            retstr = calloc(1, 2);
            if (retstr != NULL)
                retstr[0] = '0';
        }
    } else {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }

    *retstring = retstr;
}


//////////
//
// QT Preferences Settings
//
// Functions for working with QT Preferences
//////////

// This isn't working right now.  result is always an error.
void XCMD_GetQuickTimePreference (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
#ifdef __MWERKS__
#pragma unused (args, nargs, pass, error)
#endif // __MWERKS__

    OSErr result;
    QTAtomContainer prefs = NULL;
    QTAtom prefsAtom;
    long dataSize;
    Ptr atomData;
    ConnectionSpeedPrefsRecord prefrec = { 0 };
    char *retstr = NULL;

    result = GetQuickTimePreference(ConnectionSpeedPrefsType, &prefs);
    if ((result == noErr) && (NULL != prefs))
    {
        prefsAtom = QTFindChildByID(prefs, kParentAtomIsContainer, ConnectionSpeedPrefsType, 1, NULL);
        if (!prefsAtom)
        {
            // set the default settting to 28.8pkbs
            prefrec.connectionSpeed = kDataRate288ModemRate;
        } else
        {
            result = QTGetAtomDataPtr(prefs, prefsAtom, &dataSize, &atomData);
            if (dataSize != sizeof(ConnectionSpeedPrefsRecord))
            {
                // the prefs record wasn't the right size
                // so it must be corrupt -- set to the default
                prefrec.connectionSpeed = kDataRate288ModemRate;
            } else {
                // everything was fine -- read the connection speed
                prefrec = *(ConnectionSpeedPrefsRecord *)atomData;
            }
        }
        QTDisposeAtomContainer(prefs);

        retstr = (char *)malloc(R4L + 1);
        snprintf(retstr, R4L + 1, "%li", prefrec.connectionSpeed);
    }
    else
    {
        retstr = (char *)malloc(1024);
        snprintf(retstr, 1024, "%s%hi", "Unable to get QuickTime Preference", result);
    }

    *retstring = retstr;
}


//////////
//
// movie property
//
//////////

// qtAddMovieAnnotation (MovieController, AnnotationType, Annotation)
void XCMD_SetMovieAnnotation (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    Movie mv = NULL;
    long annotationType = 0;
    ComponentResult result = paramErr;
    char *retstr = NULL;

    *pass = false;
    *error = false;
    if (nargs == 3) {
        mc = (MovieController)atol(args[0]);
        
        if (mc != NULL && (long)mc > 0) {
            mv = MCGetMovie(mc);
            
            ExtUtils_ToLowerCase(args[1]);

            // Check for what the user wants to modify
            if (strcmp(args[1], "album") == 0)
                annotationType = kUserDataTextAlbum;
            else if (strcmp(args[1], "artist") == 0)
                annotationType = kUserDataTextArtist;
            else if (strcmp(args[1], "author") == 0)
                annotationType = kUserDataTextAuthor;
            else if (strcmp(args[1], "chapter") == 0)
                annotationType = kUserDataTextChapter;
            else if (strcmp(args[1], "comment") == 0)
                annotationType = kUserDataTextComment;
            else if (strcmp(args[1], "composer") == 0)
                annotationType = kUserDataTextComposer;
            else if (strcmp(args[1], "copyright") == 0)
                annotationType = kUserDataTextCopyright;
            else if (strcmp(args[1], "creationdate") == 0)
                annotationType = kUserDataTextCreationDate;
            else if (strcmp(args[1], "description") == 0)
                annotationType = kUserDataTextDescription;
            else if (strcmp(args[1], "director") == 0)
                annotationType = kUserDataTextDirector;
            else if (strcmp(args[1], "disclaimer") == 0)
                annotationType = kUserDataTextDisclaimer;
            else if (strcmp(args[1], "encodedby") == 0)
                annotationType = kUserDataTextEncodedBy;
            else if (strcmp(args[1], "fullname") == 0)
                annotationType = kUserDataTextFullName;
            else if (strcmp(args[1], "genre") == 0)
                annotationType = kUserDataTextGenre;
            else if (strcmp(args[1], "hostcomputer") == 0)
                annotationType = kUserDataTextHostComputer;
            else if (strcmp(args[1], "information") == 0)
                annotationType = kUserDataTextInformation;
            else if (strcmp(args[1], "keywords") == 0)
                annotationType = kUserDataTextKeywords;
            else if (strcmp(args[1], "make") == 0)
                annotationType = kUserDataTextMake;
            else if (strcmp(args[1], "model") == 0)
                annotationType = kUserDataTextModel;
            else if (strcmp(args[1], "originalartist") == 0)
                annotationType = kUserDataTextOriginalArtist;
            else if (strcmp(args[1], "originalformat") == 0)
                annotationType = kUserDataTextOriginalFormat;
            else if (strcmp(args[1], "originalsource") == 0)
                annotationType = kUserDataTextOriginalSource;
            else if (strcmp(args[1], "performers") == 0)
                annotationType = kUserDataTextPerformers;
            else if (strcmp(args[1], "producer") == 0)
                annotationType = kUserDataTextProducer;
            else if (strcmp(args[1], "product") == 0)
                annotationType = kUserDataTextProduct;
            else if (strcmp(args[1], "software") == 0)
                annotationType = kUserDataTextSoftware;
            else if (strcmp(args[1], "specialplaybackrequirements") == 0)
                annotationType = kUserDataTextSpecialPlaybackRequirements;
            else if (strcmp(args[1], "track") == 0)
                annotationType = kUserDataTextTrack;
            else if (strcmp(args[1], "warning") == 0)
                annotationType = kUserDataTextWarning;
            else if (strcmp(args[1], "writer") == 0)
                annotationType = kUserDataTextWriter;
            else if (strcmp(args[1], "urllink") == 0)
                annotationType = kUserDataTextURLLink;
            else if (strcmp(args[1], "editdate1") == 0)
                annotationType = kUserDataTextEditDate1;

            if (annotationType != 0) 
                result = QTUtils_AddUserDataTextToMovie(mv, args[2], annotationType);

            retstr = calloc(1, 2);
            if (retstr != NULL)
                retstr[0] = (result == noErr) ? '0': '1';
        }
        else
        {
            retstr = (char *)malloc(24);
            snprintf(retstr, 24, "%s", "Invalid movie controller");
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}


// qtGetMovieAnnotation (MovieController, AnnotationType)
void XCMD_GetMovieAnnotation (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController			mc = NULL;
    Movie					mv = NULL;
    long					annotationType = 0;
    char *					retstr = NULL;

    *pass = false;
    *error = false;
    if (nargs == 2) {
        mc = (MovieController)atol(args[0]);

        if (mc != NULL && (long)mc > 0) {
            mv = MCGetMovie(mc);
            
            ExtUtils_ToLowerCase(args[1]);

            // Check for what the user wants to modify
            // Check for what the user wants to modify
            if (strcmp(args[1], "album") == 0)
                annotationType = kUserDataTextAlbum;
            else if (strcmp(args[1], "artist") == 0)
                annotationType = kUserDataTextArtist;
            else if (strcmp(args[1], "author") == 0)
                annotationType = kUserDataTextAuthor;
            else if (strcmp(args[1], "chapter") == 0)
                annotationType = kUserDataTextChapter;
            else if (strcmp(args[1], "comment") == 0)
                annotationType = kUserDataTextComment;
            else if (strcmp(args[1], "composer") == 0)
                annotationType = kUserDataTextComposer;
            else if (strcmp(args[1], "copyright") == 0)
                annotationType = kUserDataTextCopyright;
            else if (strcmp(args[1], "creationdate") == 0)
                annotationType = kUserDataTextCreationDate;
            else if (strcmp(args[1], "description") == 0)
                annotationType = kUserDataTextDescription;
            else if (strcmp(args[1], "director") == 0)
                annotationType = kUserDataTextDirector;
            else if (strcmp(args[1], "disclaimer") == 0)
                annotationType = kUserDataTextDisclaimer;
            else if (strcmp(args[1], "encodedby") == 0)
                annotationType = kUserDataTextEncodedBy;
            else if (strcmp(args[1], "fullname") == 0)
                annotationType = kUserDataTextFullName;
            else if (strcmp(args[1], "genre") == 0)
                annotationType = kUserDataTextGenre;
            else if (strcmp(args[1], "hostcomputer") == 0)
                annotationType = kUserDataTextHostComputer;
            else if (strcmp(args[1], "information") == 0)
                annotationType = kUserDataTextInformation;
            else if (strcmp(args[1], "keywords") == 0)
                annotationType = kUserDataTextKeywords;
            else if (strcmp(args[1], "make") == 0)
                annotationType = kUserDataTextMake;
            else if (strcmp(args[1], "model") == 0)
                annotationType = kUserDataTextModel;
            else if (strcmp(args[1], "originalartist") == 0)
                annotationType = kUserDataTextOriginalArtist;
            else if (strcmp(args[1], "originalformat") == 0)
                annotationType = kUserDataTextOriginalFormat;
            else if (strcmp(args[1], "originalsource") == 0)
                annotationType = kUserDataTextOriginalSource;
            else if (strcmp(args[1], "performers") == 0)
                annotationType = kUserDataTextPerformers;
            else if (strcmp(args[1], "producer") == 0)
                annotationType = kUserDataTextProducer;
            else if (strcmp(args[1], "product") == 0)
                annotationType = kUserDataTextProduct;
            else if (strcmp(args[1], "software") == 0)
                annotationType = kUserDataTextSoftware;
            else if (strcmp(args[1], "specialplaybackrequirements") == 0)
                annotationType = kUserDataTextSpecialPlaybackRequirements;
            else if (strcmp(args[1], "track") == 0)
                annotationType = kUserDataTextTrack;
            else if (strcmp(args[1], "warning") == 0)
                annotationType = kUserDataTextWarning;
            else if (strcmp(args[1], "writer") == 0)
                annotationType = kUserDataTextWriter;
            else if (strcmp(args[1], "urllink") == 0)
                annotationType = kUserDataTextURLLink;
            else if (strcmp(args[1], "editdate1") == 0)
                annotationType = kUserDataTextEditDate1;
			else if (strcmp(args[1], "controllertype") == 0)
				annotationType = kUserDataMovieControllerType;
				
            retstr = QTUtils_GetUserDataTextFromMovie(mv, annotationType);
        }
        else
        {
            retstr = (char *)malloc(24);
            snprintf(retstr, 24, "%s", "Invalid movie controller");
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }

    *retstring = retstr;
}


// qtGetMovieControllerType (MovieController)
void XCMD_GetMovieControllerType (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController			mc = NULL;
    Movie					mv = NULL;
	UserData				myUserData = NULL;
	long					myType;
    char *					retstr = NULL;

    *pass = false;
    *error = false;
    if (nargs == 1) {
        mc = (MovieController)atol(args[0]);

        if (mc != NULL && (long)mc > 0) {
            mv = MCGetMovie(mc);
			
			myUserData = GetMovieUserData(mv);
			if (myUserData != NULL)
			{
				GetUserDataItem(myUserData, &myType, sizeof(myType), kQTControllerType, 0);
				myType = EndianU32_NtoB(myType);
				
				if ((myType == kQTVRQTVRType) || (myType == kQTVRPanoramaType) || (myType == kQTVROldPanoType)) {
					retstr = (char *)malloc(9);
					snprintf(retstr, 9, "%s", "panorama");
				} else if ((myType == kQTVRObjectType) || (myType == kQTVROldObjectType)) {
					retstr = (char *)malloc(7);
					snprintf(retstr, 7, "%s", "object");
				} else if (myType == kMovieControllerNone) { // type 'none'
					retstr = (char *)malloc(5);
					snprintf(retstr, 5, "%s", "none");
				} else {
					retstr = (char *)malloc(6);
					snprintf(retstr, 6, "%s", "movie");
				}
			}
		}
        else
        {
            retstr = (char *)malloc(24);
            snprintf(retstr, 24, "%s", "Invalid movie controller");
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }

    *retstring = retstr;
}


// Stores looping info in movie
// qtSetMovieFileLoopingInfo(MovieController, LoopType)
// loop type normal, palindrome, none
void XCMD_SetMovieFileLoopingInfo (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController     mc = NULL;
    Movie               myMovie = NULL;
    UserData            myUserData = NULL;
    long                myLoopInfo;
    short               myCount = 0;
    OSErr               myErr = paramErr;
    char *		retstr = NULL;
        *pass = false;
        *error = false;
        if (nargs == 2)
        {
            mc = (MovieController)atol(args[0]);
            if (mc != NULL && (long)mc > 0)
            {
                myMovie = MCGetMovie(mc);
                myUserData = GetMovieUserData(myMovie);
                
                ExtUtils_ToLowerCase(args[1]);
                
                if (strcmp(args[1], "normal") == 0)
                    myLoopInfo = kNormalLooping;
                else if (strcmp(args[1], "palindrome") == 0)
                    myLoopInfo = kPalindromeLooping;
                else
                    myLoopInfo = kNoLooping;
                
                // we only want one data item of type 'LOOP'
                // so delete any
                myCount = CountUserDataType (myUserData, FOUR_CHAR_CODE('LOOP'));
                while (myCount--)
                    RemoveUserData(myUserData, FOUR_CHAR_CODE('LOOP'), 1);
                
                // make sure we're writing big-endian data
                myLoopInfo = EndianU32_NtoB(myLoopInfo);
                switch (myLoopInfo) {
                    case kNormalLooping:
                    case kPalindromeLooping:
                        myErr = SetUserDataItem(myUserData, &myLoopInfo, sizeof(long), FOUR_CHAR_CODE('LOOP'), 0);
                        break;
                    case kNoLooping:
                    default:
                        myErr = noErr;
                        break;
                }
                
                retstr = calloc(1, 2);
                if (retstr != NULL)
                    retstr[0] = (myErr == noErr) ? '0': '1';
            }
            else
            {
                retstr = (char *)malloc(25);
                snprintf(retstr, 25, "%s", "Invalid movie controller");
            }
        }
        else
        {
            retstr = (char *)malloc(28);
            snprintf(retstr, 28, "%s", "Invalid number of arguments");
        }
            *retstring = retstr;
}

// Gets looping info in movie
// qtGetMovieFileLoopingInfo(MovieController)
// returns normal, palindrome, none
void XCMD_GetMovieFileLoopingInfo (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController     mc = NULL;
    Movie               myMovie = NULL;
    UserData            myUserData = NULL;
    long                myLoopInfo;
    OSErr               myErr = paramErr;
    char *		retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 1)
    {
        mc = (MovieController)atol(args[0]);
                if (mc != NULL && (long)mc > 0)
                {
                    myMovie = MCGetMovie(mc);
                    myUserData = GetMovieUserData(myMovie);
                    if (myUserData != NULL) {
                        myErr = GetUserDataItem(myUserData, &myLoopInfo, sizeof(myLoopInfo), FOUR_CHAR_CODE('LOOP'),0);
                        if (myErr == noErr)
                            myLoopInfo = EndianS32_BtoN(myLoopInfo);
                    }
                                if (myLoopInfo == kNormalLooping) {
                                    retstr = malloc(7);
                                    snprintf(retstr, 7, "%s", "normal");
                                } else if (myLoopInfo == kPalindromeLooping) {
                                    retstr = malloc(11);
                                    snprintf(retstr, 11, "%s", "palindrome");
                                } else {
                                    retstr = malloc(5);
                                    snprintf(retstr, 5, "%s", "none");
                                }
                }
                else
                {
                    retstr = (char *)malloc(25);
                    snprintf(retstr, 25, "%s", "Invalid movie controller");
                }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}

// qtMakeMovieLoop(MovieController, isPalindrome)
// isPalindrome is "true" or "1"
void XCMD_MakeMovieLoop (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController     mc = NULL;
    Movie               myMovie = NULL;
    TimeBase            myTimeBase = NULL;
    long                myFlags = 0L;
    Boolean             isPalindrome = false;
    OSErr               myErr = paramErr;
    char *		retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 2)
    {
        mc = (MovieController)atol(args[0]);
        if (mc != NULL && (long)mc > 0) {
            myMovie = MCGetMovie(mc);
            myErr = noErr;
            
            // set the movie's play hints to enhance looping performance
            SetMoviePlayHints(myMovie, hintsLoop, hintsLoop);
            
            // set the looping flag of the movie's time base
            myTimeBase = GetMovieTimeBase(myMovie);
            myFlags = GetTimeBaseFlags(myTimeBase);
            myFlags |= loopTimeBase;
            
            ExtUtils_ToLowerCase(args[1]);
            
            // set or clear the palindrome flag, depending on the specified setting
            if (strcmp(args[1], "true") == 0 || strcmp(args[1], "1") == 0)
                isPalindrome = true;
            if (isPalindrome)
                myFlags |= palindromeLoopTimeBase;
            else
                myFlags &= ~palindromeLoopTimeBase;
            
            SetTimeBaseFlags(myTimeBase, myFlags);
            retstr = calloc(1, 2);
            if (retstr != NULL)
                retstr[0] = (myErr == noErr) ? '0': '1';
        }
        else
        {
            retstr = (char *)malloc(25);
            snprintf(retstr, 25, "%s", "Invalid movie controller");
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
}


//////////
//
// editing functions
//
// These functions return the string "1" if the edit fails and "0" otherwise.
//	arg[0] is the movie controller
//
//////////
void XCMD_MCInitialize (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    ComponentResult result = noErr;
    //Rect rect;
    char *retstr = NULL;

    // initialize the movie controller as desired
    *pass = false;
    *error = false;
    if (nargs == 1) {
        mc = (MovieController)atol(args[0]);
        if (mc != NULL && (long)mc > 0 && QTVR_Init()) {
            // enable editing
            result = MCEnableEditing(mc, true);
            // enable keyboard event handling
            MCDoAction(mc, mcActionSetKeysEnabled, (void *)True);
            // disable drag support
            MCDoAction(mc, mcActionSetDragEnabled, (void *)False);
            // set grow rectangle
            // [TO BE PROVIDED]
        }
    }
    
    retstr = calloc(1, 2);
    if (retstr != NULL)
        retstr[0] = (result == noErr) ? '0': '1';
    *retstring = retstr;
}


void XCMD_MCUndo (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    ComponentResult result = noErr;
    char *retstr = NULL;

    *pass = false;
    *error = false;
    if (nargs == 1) {
        mc = (MovieController)atol(args[0]);

        if (mc != NULL && (long)mc > 0)
            result = MCUndo(mc);
        else
#ifdef __MWERKS__
            DebugStr("\pGOT A NULL MOVIECONTROLLER!");
#else
            DebugStr("GOT A NULL MOVIECONTROLLER!");
#endif // __MWERKS__
    }
    
    retstr = calloc(1, 2);
    if (retstr != NULL)
        retstr[0] = (result == noErr) ? '0': '1';
        
    *retstring = retstr;
}


void XCMD_MCCut (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    ComponentResult result = noErr;
    Movie editmovie = NULL;
    char *retstr = NULL;

    *pass = false;
    *error = false;
    if (nargs == 1) {
        mc = (MovieController)atol(args[0]);

        if (mc != NULL && (long)mc > 0) {
            editmovie = MCCut(mc);
            result = (editmovie != NULL) ? result: invalidMovie;
        } else
#ifdef __MWERKS__
            DebugStr("\pGOT A NULL MOVIECONTROLLER!");
#else
            DebugStr("GOT A NULL MOVIECONTROLLER!");
#endif // __MWERKS__
    }
    
    // place the cut movie segment onto the scrap
    if (editmovie != NULL) {
        PutMovieOnScrap(editmovie, 0L);
        DisposeMovie(editmovie);
    }

    retstr = calloc(1, 2);
    if (retstr != NULL)
        retstr[0] = (result == noErr) ? '0': '1';

    *retstring = retstr;
}


void XCMD_MCCopy (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    ComponentResult result = noErr;
    Movie editmovie = NULL;
    char *retstr = NULL;

    *pass = false;
    *error = false;
    if (nargs == 1) {
        mc = (MovieController)atol(args[0]);

        if (mc != NULL && (long)mc > 0) {
            editmovie = MCCopy(mc);
            result = (editmovie != NULL) ? result: invalidMovie;
        } else
#ifdef __MWERKS__
            DebugStr("\pGOT A NULL MOVIECONTROLLER!");
#else
            DebugStr("GOT A NULL MOVIECONTROLLER!");
#endif // __MWERKS__
    }
    
    // place the copied movie segment onto the scrap
    if (editmovie != NULL) {
        PutMovieOnScrap(editmovie, 0L);
        DisposeMovie(editmovie);
    }

    retstr = calloc(1, 2);
    if (retstr != NULL)
        retstr[0] = (result == noErr) ? '0': '1';
            
    *retstring = retstr;
}


void XCMD_MCPaste (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    ComponentResult result = noErr;
    char *retstr = NULL;

    *pass = false;
    *error = false;
    if (nargs == 1) {
        mc = (MovieController)atol(args[0]);

        if (mc != NULL && (long)mc > 0)
            result = MCPaste(mc, NULL);
        else
#ifdef __MWERKS__
            DebugStr("\pGOT A NULL MOVIECONTROLLER!");
#else
            DebugStr("GOT A NULL MOVIECONTROLLER!");
#endif // __MWERKS__
    }
    
    retstr = calloc(1, 2);
    if (retstr != NULL)
        retstr[0] = (result == noErr) ? '0': '1';
            
    *retstring = retstr;
}


void XCMD_MCClear (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    ComponentResult result = noErr;
    char *retstr = NULL;

    *pass = false;
    *error = false;
    if (nargs == 1) {
        mc = (MovieController)atol(args[0]);

        if (mc != NULL && (long)mc > 0)
            result = MCClear(mc);
        else
#ifdef __MWERKS__
            DebugStr("\pGOT A NULL MOVIECONTROLLER!");
#else
            DebugStr("GOT A NULL MOVIECONTROLLER!");
#endif // __MWERKS__
    }
    
    retstr = calloc(1, 2);
    if (retstr != NULL)
        retstr[0] = (result == noErr) ? '0': '1';
            
    *retstring = retstr;
}


void XCMD_SelectAll (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    Movie mv = NULL;
    ComponentResult result = noErr;
    TimeRecord tr;
    char *retstr = NULL;

    *pass = false;
    *error = false;
    if (nargs == 1) {
        mc = (MovieController)atol(args[0]);

        if (mc != NULL && (long)mc > 0) {
            mv = MCGetMovie(mc);
            if (mv) {
                tr.value.hi = 0;
                tr.value.lo = 0;
                tr.base = 0;
                tr.scale = GetMovieTimeScale(mv);	
                result = MCDoAction(mc, mcActionSetSelectionBegin, &tr);
                
                tr.value.hi = 0;
                tr.value.lo = GetMovieDuration(mv);	
                tr.base = 0;
                tr.scale = GetMovieTimeScale(mv);	
                result = MCDoAction(mc, mcActionSetSelectionDuration, &tr);
            }
        }
        else
#ifdef __MWERKS__
            DebugStr("\pGOT A NULL MOVIECONTROLLER!");
#else
            DebugStr("GOT A NULL MOVIECONTROLLER!");
#endif // __MWERKS__
    }
    
    retstr = calloc(1, 2);
    if (retstr != NULL)
        retstr[0] = (result == noErr) ? '0': '1';
            
    *retstring = retstr;
}


void XCMD_SelectNone (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    Movie mv = NULL;
    ComponentResult result = noErr;
    TimeRecord tr;
    char *retstr = NULL;

    *pass = false;
    *error = false;
    if (nargs == 1) {
        mc = (MovieController)atol(args[0]);

        if (mc != NULL && (long)mc > 0) {
            mv = MCGetMovie(mc);
            if (mv) {
                tr.value.hi = 0;
                tr.value.lo = 0;	
                tr.base = 0;
                tr.scale = GetMovieTimeScale(mv);	
                result = MCDoAction(mc, mcActionSetSelectionDuration, &tr);
            }
        }
        else
#ifdef __MWERKS__
            DebugStr("\pGOT A NULL MOVIECONTROLLER!");
#else
            DebugStr("GOT A NULL MOVIECONTROLLER!");
#endif // __MWERKS__
    }
    
    retstr = calloc(1, 2);
    if (retstr != NULL)
        retstr[0] = (result == noErr) ? '0': '1';
            
    *retstring = retstr;
}


// qtSetSelection(MovieController, StartTime, EndTime)
// StartTime and EndTime are in the movies timescale
void XCMD_SetSelection (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController     mc = NULL;
    Movie               mv = NULL;
    TimeValue           myStartTime = 0;
    TimeValue           myEndtime = 0;
    ComponentResult     result = noErr;
    TimeRecord          tr;
    char                *retstr = NULL;
    *pass = false;
    *error = false;
    if (nargs == 3) {
        mc = (MovieController)atol(args[0]);
        if (mc != NULL && (long)mc > 0) {
            mv = MCGetMovie(mc);
            if (mv) {
                myStartTime = atol(args[1]);
                myEndtime = atol(args[2]);

                tr.value.hi = 0;
                tr.value.lo = myStartTime;
                tr.base = 0;
                tr.scale = GetMovieTimeScale(mv);

                result = MCDoAction(mc, mcActionSetSelectionBegin, &tr);

                tr.value.hi = 0;
                tr.value.lo = myEndtime;
                tr.base = 0;
                tr.scale = GetMovieTimeScale(mv);

                result = MCDoAction(mc, mcActionSetSelectionDuration, &tr);
                retstr = calloc(1, 2);
                if (retstr != NULL)
                    retstr[0] = (result == noErr) ? '0': '1';
            }
            else
            {
                retstr = (char *)malloc(14);
                snprintf(retstr, 14, "%s", "Invalid movie");
            }
        }
        else
        {
            retstr = (char *)malloc(25);
            snprintf(retstr, 25, "%s", "Invalid movie controller");
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
        *retstring = retstr;
}


// qtAddTransition(MovieController, EffectType, StartTime, Duration)
// StartTime and EndTime are in the movies timescale
void XCMD_AddTransition (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController     mc = NULL;
    Movie               mv = NULL;
    TimeValue           myStartTime = 0;
    TimeValue           myDuration = 0;
    OSType              myEffect = NULL;
    long                numSources = 0L;
    OSErr               myErr = noErr;
    char *              retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 4) {
        mc = (MovieController)atol(args[0]);
        if (mc != NULL && (long)mc > 0) {
            mv = MCGetMovie(mc);
            if (mv) {
                myStartTime = atol(args[2]);
                myDuration = atol(args[3]);
                
                ExtUtils_ToLowerCase(args[1]);
                
                // Determine transition type
                if (strcmp("alphacompositor", args[1]) == 0) {
                    myEffect = kAlphaCompositorTransitionType;
                    numSources = 2;
                } else if (strcmp("channelcomposite", args[1]) == 0) {
                    myEffect = kChannelCompositeEffectType;
                    numSources = 2;
                } else if (strcmp("chromakey", args[1]) == 0) {
                    myEffect = kChromaKeyTransitionType;
                    numSources = 2;
                } else if (strcmp("implode", args[1]) == 0) {
                    myEffect = kImplodeTransitionType;
                    numSources = 2;
                } else if (strcmp("explode", args[1]) == 0) {
                    myEffect = kExplodeTransitionType;
                    numSources = 2;
                } else if (strcmp("gradient", args[1]) == 0) {
                    myEffect = kGradientTransitionType;
                    numSources = 2;
                } else if (strcmp("push", args[1]) == 0) {
                    myEffect = kPushTransitionType;
                    numSources = 2;
                } else if (strcmp("slide", args[1]) == 0) {
                    myEffect = kSlideTransitionType;
                    numSources = 2;
                } else if (strcmp("wipe", args[1]) == 0) {
                    myEffect = kWipeTransitionType;
                    numSources = 2;
                } else if (strcmp("iris", args[1]) == 0) {
                    myEffect = kIrisTransitionType;
                    numSources = 2;
                } else if (strcmp("radial", args[1]) == 0) {
                    myEffect = kRadialTransitionType;
                    numSources = 2;
                } else if (strcmp("matrix", args[1]) == 0) {
                    myEffect = kMatrixTransitionType;
                    numSources = 2;
                } else if (strcmp("zoom", args[1]) == 0) {
                    myEffect = kZoomTransitionType;
                    numSources = 2;
                } else {
                    myEffect = kCrossFadeTransitionType;
                    numSources = 2;
                }
                
                myErr = QTUtils_AddEffectToMovieSegment (mv, myEffect, numSources, myStartTime, myDuration);
                
                retstr = calloc(1, 2);
                if (retstr != NULL)
                    retstr[0] = (myErr == noErr) ? '0': '1';
            }
            else
            {
                retstr = (char *)malloc(14);
                snprintf(retstr, 14, "%s", "Invalid movie");
            }
        }
        else
        {
            retstr = (char *)malloc(25);
            snprintf(retstr, 25, "%s", "Invalid movie controller");
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    *retstring = retstr;
}


// qtAddFilter (MovieController, EffectType, StartTime, EndTime)
// StartTime and EndTime are in the movies timescale
void XCMD_AddFilter (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController     mc = NULL;
    Movie               mv = NULL;
    TimeValue           myStartTime = 0;
    TimeValue           myDuration = 0;
    OSType              myEffect = NULL;
    long                numSources = 0L;
    OSErr               myErr = noErr;
    char *              retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 4) {
        mc = (MovieController)atol(args[0]);
        if (mc != NULL && (long)mc > 0) {
            mv = MCGetMovie(mc);
            if (mv) {
                myStartTime = atol(args[2]);
                myDuration = atol(args[3]);
                
                numSources = 1;
                
                ExtUtils_ToLowerCase(args[1]);
                
                // Determine effect type
                if (strcmp("blur", args[1]) == 0) {
                    myEffect = kBlurImageFilterType;
                } else if (strcmp("sharpen", args[1]) == 0) {
                    myEffect = kSharpenImageFilterType;
                } else if (strcmp("edgedetect", args[1]) == 0) {
                    myEffect = kEdgeDetectImageFilterType;
                } else if (strcmp("emboss", args[1]) == 0) {
                    myEffect = kEmbossImageFilterType;
                } else if (strcmp("convolve", args[1]) == 0) {
                    myEffect = kConvolveImageFilterType;
                } else if (strcmp("alphagain", args[1]) == 0) {
                    myEffect = kAlphaGainImageFilterType;
                } else if (strcmp("rgbcolorbalance", args[1]) == 0) {
                    myEffect = kRGBColorBalanceImageFilterType;
                } else if (strcmp("hslcolorbalance", args[1]) == 0) {
                    myEffect = kHSLColorBalanceImageFilterType;
                } else if (strcmp("colorsync", args[1]) == 0) {
                    myEffect = kColorSyncImageFilterType;
                } else if (strcmp("filmnoise", args[1]) == 0) {
                    myEffect = kFilmNoiseImageFilterType;
                } else if (strcmp("solarize", args[1]) == 0) {
                    myEffect = kSolarizeImageFilterType;
                } else if (strcmp("colortint", args[1]) == 0) {
                    myEffect = kColorTintImageFilterType;
                } else if (strcmp("lensflare", args[1]) == 0) {
                    myEffect = kLensFlareImageFilterType;
                } else {
                    myEffect = kBrightnessContrastImageFilterType;
                }
                
                myErr = QTUtils_AddEffectToMovieSegment (mv, myEffect, numSources, myStartTime, myDuration);
                
                retstr = calloc(1, 2);
                if (retstr != NULL)
                    retstr[0] = (myErr == noErr) ? '0': '1';
            }
            else
            {
                retstr = (char *)malloc(14);
                snprintf(retstr, 14, "%s", "Invalid movie");
            }
        }
        else
        {
            retstr = (char *)malloc(25);
            snprintf(retstr, 25, "%s", "Invalid movie controller");
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    *retstring = retstr;
}


// qtAddMovieSegment (mc, Boolean scaled)
void XCMD_MCAddMovieSegment (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    Movie editMovie = NULL;
    Boolean scaled = false;
    ComponentResult result = noErr;
    char *retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 2) {
        mc = (MovieController)atol(args[0]);

        if (mc != NULL && (long)mc > 0) {
            editMovie = NewMovieFromScrap(0L);
            result = (editMovie != NULL) ? result: invalidMovie;
            
            // this should be case insensitive
            ExtUtils_ToLowerCase(args[1]);
            if (strcmp(args[1], "true") == 0 || strcmp(args[1], "1") == 0)
                    scaled = true;
                    
            result = MCAddMovieSegment(mc, editMovie, scaled);
        } else {
            //DebugStr("\pGOT A NULL MOVIECONTROLLER!");
        }
    }
    
    retstr = calloc(1, 2);
    if (retstr != NULL)
        retstr[0] = (result == noErr) ? '0': '1';
            
    *retstring = retstr;
}


// qtCopyTrackToScrap (MovieController, TrackIdentifier)
void XCMD_CopyTrackToScrap (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController 	mc = NULL;
    Movie 		mv = NULL;
    Track		tr = NULL;
    long		trackIndex = 0;
    OSErr	 	myErr = noErr;
    char *		retstr = NULL;

    *pass = false;
    *error = false;
    if (nargs == 2) {
        mc = (MovieController)atol(args[0]);
        trackIndex = atol(args[1]);

        if (mc != NULL && (long)mc > 0) {
            // If no track name or index was given then set index to 1
            if (trackIndex == 0 && strlen(args[1]) < 1)
                trackIndex = 1;

            // args[1] is a number search by track index, otherwise by name
            if (trackIndex > 0) {
                mv = MCGetMovie(mc);
                if (mv == NULL) {
                    retstr = (char *)malloc(14);
                    snprintf(retstr, 14, "%s", "Invalid movie");
                    goto bail;
                }
                else {
                    tr =  GetMovieTrack(mv, trackIndex);
                }
            }
            else {
                tr = QTUtils_GetTrackReferenceByName (mc, args[1]);
            }

            if (tr == NULL) {
                retstr = (char *)malloc(14);
                snprintf(retstr, 14, "%s", "Invalid track");
                goto bail;
            }

            myErr = QTUtils_CreateNewMovieOnScrapFromTrack(tr);
            
            retstr = calloc(1, 2);
            retstr[0] = (myErr == noErr) ? '0': '1';
        }
        else
        {
            retstr = (char *)malloc(25);
            snprintf(retstr, 25, "%s", "Invalid movie controller");
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }        

    *retstring = retstr;

bail:
        *retstring = retstr;
}



//////////
//
// menu status function
//
// This function returns the string "1" if the item of the specified index should be enabled and "0" otherwise.
//	arg[0] is the movie controller
//	arg[1] is the editing description
//
//////////
void XCMD_GetMCInfo (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController mc = NULL;
    ComponentResult result = noErr;
    long mcInfo = 0L;
    //short index = 0;
    char *retstr = NULL;

    *pass = false;
    *error = false;
    retstr = malloc(2);			// either "0" or "1", plus the terminating null byte

    if (nargs == 2) {
        mc = (MovieController)atol(args[0]);
        //index = (short)atoi(args[1]);
        if (mc != NULL && (long)mc > 0) {
            result = MCGetControllerInfo(mc, &mcInfo);

            ExtUtils_ToLowerCase(args[1]);
            
            if (strcmp ("undo", args[1]) == 0)
                retstr[0] = mcInfo & mcInfoUndoAvailable ? '1': '0';
            else if (strcmp ("cut", args[1]) == 0)
                retstr[0] = mcInfo & mcInfoCutAvailable ? '1': '0';
            else if (strcmp ("copy", args[1]) == 0)
                retstr[0] = mcInfo & mcInfoCopyAvailable ? '1': '0';
            else if (strcmp ("paste", args[1]) == 0)
                retstr[0] = mcInfo & mcInfoPasteAvailable ? '1': '0';
            else if (strcmp ("clear", args[1]) == 0)
                retstr[0] = mcInfo & mcInfoClearAvailable ? '1': '0';
            else if (strcmp ("selectall", args[1]) == 0 || strcmp ("selectnone", args[1]) == 0)
                retstr[0] = mcInfo & mcInfoEditingEnabled ? '1': '0';
            else if (strcmp ("isplaying", args[1]) == 0)
                retstr[0] = mcInfo & mcInfoIsPlaying ? '1': '0';
            else
                retstr[0] = '0';
        }
    
    }	
    
    // tack on the terminating null byte
    retstr[1] = 0;
    *retstring = retstr;
}

//////////
//
// window status function
//
// This function returns the string "1" if the modification fails and "0" otherwise.
//	arg[0] is the window pointer
//	arg[1] is the desired window state ("1" for modified, "0" if clean)
//
//////////
void XCMD_SetWindowModified (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    WindowPtr wID = NULL;
    Boolean state;
    OSErr result = noErr;
    char *retstr = NULL;

    *pass = false;
    *error = false;
    if (nargs == 2) {
        wID = (WindowPtr)atol(args[0]);
        state = (Boolean)atoi(args[1]);

#ifdef MACOS //TUV no such call in Windows
        if (wID != NULL)
            {
#ifdef __MWERKS__ && TARGET_RT_MAC_CFM
            // SetWindowModified is only available in Window Manager 2.0 -- Mac OS 8.5 and forward
            // We may possibly want to weak link WindowsLib.
            if ((Ptr)SetWindowModified == (Ptr)kUnresolvedCFragSymbolAddress)
               result = unimpErr;
            else
#endif // __MWERKS__ && TARGET_RT_MAC_CFM
            result = SetWindowModified(wID, state);
            }
        else
#ifdef __MWERKS__
            DebugStr("\pGOT A NULL MOVIE WINDOW!");
#else
            DebugStr("GOT A NULL MOVIE WINDOW!");
#endif // __MWERKS__

#endif
    }
    
    retstr = calloc(1, 2);
    if (retstr != NULL)
        retstr[0] = (result == noErr) ? '0': '1';
    *retstring = retstr;
}


//////////
//
// Saves a movie to the provided path
//
// qtSave (MovieController, Path, Flatten, SaveDisable)
// flatten is a boolean value
//////////
void XCMD_Save (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController         mc = NULL;
    Movie                   myMovie = NULL;
    UserData                theUserData = NULL;
    long                    nsavData;
    Handle                  ourNSAVdataH = NULL;
    Boolean                 makeSelfContained = true;
    Boolean                 saveDisable = false;
    OSErr                   myErr = noErr;
    short                   nResID = movieInDataForkResID;
    short                   refNum = -1;
    Movie                   newMovie = NULL;
    char                    *retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 4) {
        mc = (MovieController)atol(args[0]);
        ExtUtils_ToLowerCase(args[2]);
        ExtUtils_ToLowerCase(args[3]);
        
        if (strcmp("false", args[2]) == 0 || strcmp("0", args[2]) == 0) 
            makeSelfContained = false;
        if (strcmp("true", args[3]) == 0 || strcmp("1", args[3]) == 0) 
            saveDisable = true;
        
        if (mc != NULL && (long)mc > 0) {
            myMovie = MCGetMovie(mc);
            
            if (myMovie != NULL) {
                FSSpec savefspec;
                ExtUtils_Path2FSSpec(args[1], &savefspec);
                // Do we need to do this?  It seems the OS overwrites.
                // Delete any existing file
                //result = DeleteMovieFile(&savefspec);
                //if (result != noErr)
                    //goto bail;
                
                if (saveDisable == true) {
                    // Get user data
                    theUserData = GetMovieUserData(myMovie);
                    
                    // Specify the actual data for this user item
                    nsavData = 1; // no save or edits allowed
                    PtrToHand(&nsavData, &ourNSAVdataH, 4);
                    
                    // Add the no save item to the user data list
                    AddUserData (theUserData, ourNSAVdataH, FOUR_CHAR_CODE('nsav'));
                }
                
                if (makeSelfContained == true)
                {                    
                    newMovie = FlattenMovieData(myMovie,
                                                flattenAddMovieToDataFork | flattenForceMovieResourceBeforeMovieData | flattenCompressMovieResource,
                                                &savefspec,
                                                FOUR_CHAR_CODE('TVOD'),
                                                smSystemScript,
                                                createMovieFileDeleteCurFile | createMovieFileDontCreateResFile);
                    myErr = GetMoviesError();
                    
                    if ((newMovie == NULL) || (myErr != noErr))
                        goto bail;
                    
                    // FlattenMovieData creates a new movie file and returns the movie to us; since we want
                    // to let Revolution open the new file, we'll dump the movie returned by FlattenMovieData
                    DisposeMovie(newMovie);
                    
                    // also, on MacOS, FlattenMovieData *always* creates a resource fork, even if we told it
                    // not to do so (didn't we say "createMovieFileDontCreateResFile"?); so we'll explicitly
                    // delete the resource fork now....
#if TARGET_OS_MAC
                    myErr = FSpOpenRF(&savefspec, fsRdWrPerm, &refNum);
                    if (myErr == noErr) {
                        SetEOF(refNum, 0L);
                        FSClose(refNum);
                    }
#endif
                } else {
                    // Movie is not to be flattened                    
                    myErr = CreateMovieFile (&savefspec,
                                     FOUR_CHAR_CODE('TVOD'),
                                     smSystemScript,
                                     createMovieFileDontCreateMovie,         
                                     &refNum,  // send &refNum to get a handle to movie that is created
                                     NULL);
                    AddMovieResource(myMovie, refNum, &nResID, NULL);
                }
                
                retstr = calloc(1, 2);
                if (retstr != NULL)
                    retstr[0] = (myErr == noErr) ? '0': '1';
            }
            else
            {
                retstr = (char *)malloc(13);
                snprintf(retstr, 13, "%s", "Invalid movie");
            }
        }
        else
        {
            retstr = (char *)malloc(25);
            snprintf(retstr, 25, "%s", "Invalid movie controller");
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    // Dispose of handler if it exists
    if (ourNSAVdataH != NULL) {
        // Remove no save user data from revolution movie
        // assumes there is only one user data entry of type nsav
        RemoveUserData (theUserData, FOUR_CHAR_CODE('nsav'), 1);
        DisposeHandle(ourNSAVdataH);
    }

    *retstring = retstr;
    
bail:
    if (ourNSAVdataH != NULL) {
        // Remove no save user data from revolution movie
        // assumes there is only one user data entry of type nsav
        RemoveUserData (theUserData, FOUR_CHAR_CODE('nsav'), 1);
        DisposeHandle(ourNSAVdataH);
    }
    
    retstr = calloc(1, 2);
    if (retstr != NULL)
        retstr[0] = (myErr == noErr) ? '0': '1';
    *retstring = retstr;
}


//////////
//
// Creates an empty movie at the provided path
//
// qtNewMovie (Path)
//////////
void XCMD_CreateNewMovie (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
	//MovieController 		myMC = NULL;
    Movie                   myMovie = NULL;
    Movie                   newMovie = NULL;
	//Rect					rect;
    OSErr                   myErr = noErr;
    short                   refNum = -1;
    char                    *retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 1) {
        FSSpec savefspec;
        ExtUtils_Path2FSSpec(args[0], &savefspec);
        // Do we need to do this?  It seems the OS overwrites.
        // Delete any existing file
        //result = DeleteMovieFile(&savefspec);
        //if (result != noErr)
        //goto bail;
        
        myMovie = NewMovie(0L);
		/*if (myMovie != NULL) {
			rect.left = 0;
			rect.right = 100;
			rect.top = 0;
			rect.bottom = 16;
			myMC = NewMovieController(myMovie, &rect, 0);
			retstr = malloc(100);
			snprintf(retstr, "%lu", myMC);
		}*/
        newMovie = FlattenMovieData(myMovie,
                                    flattenAddMovieToDataFork | flattenForceMovieResourceBeforeMovieData | flattenCompressMovieResource,
                                    &savefspec,
                                    FOUR_CHAR_CODE('TVOD'),
                                    smSystemScript,
                                    createMovieFileDeleteCurFile | createMovieFileDontCreateResFile);
        myErr = GetMoviesError();
        
        if ((newMovie == NULL) || (myErr != noErr))
            goto bail;
		
        
        // FlattenMovieData creates a new movie file and returns the movie to us; since we want
        // to let Revolution open the new file, we'll dump the movie returned by FlattenMovieData
        DisposeMovie(newMovie);
		
        // also, on MacOS, FlattenMovieData *always* creates a resource fork, even if we told it
        // not to do so (didn't we say "createMovieFileDontCreateResFile"?); so we'll explicitly
        // delete the resource fork now....
#if TARGET_OS_MAC
        myErr = FSpOpenRF(&savefspec, fsRdWrPerm, &refNum);
        if (myErr == noErr) {
            SetEOF(refNum, 0L);
            FSClose(refNum);
        }
#endif
        
        DisposeMovie(myMovie);
		
        
        retstr = calloc(1, 2);
        if (retstr != NULL)
            retstr[0] = (myErr == noErr) ? '0': '1';
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
    
bail:
    retstr = calloc(1, 2);
    if (retstr != NULL)
        retstr[0] = (myErr == noErr) ? '0': '1';
    *retstring = retstr;
}


//////////
//
// Lets a user export the current movie contents.  Uses QuickTime export dialog.
//
// qtExport (MovieController)
//
//////////
void XCMD_Export (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController         mc = NULL;
    Movie                   myMovie = NULL;
    OSErr                   myErr = noErr;
    char                    *retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 1) {
        mc = (MovieController)atol(args[0]);
        
        if (mc != NULL && (long)mc > 0) {
            myMovie = MCGetMovie(mc);
            
            if (myMovie != NULL) {
                //FSSpec savefspec;
                //path2FSSpec(args[1], &savefspec);
                
                // use the default progress procedure, if any
                SetMovieProgressProc(myMovie, (MovieProgressUPP)-1L, 0);
                
                myErr = ConvertMovieToFile (myMovie,
                                            NULL,
                                            0, //&savefspec,
                                            0, // kQTFileTypePNG,
                                            0, // FOUR_CHAR_CODE('TVOD')
                                            smSystemScript,
                                            NULL,
                                            showUserSettingsDialog |
                                            movieToFileOnlyExport, // | movieFileSpecValid,
                                            0);
                
                retstr = calloc(1, 2);
                if (retstr != NULL)
                    retstr[0] = (myErr == noErr) ? '0': '1';
            }
            else
            {
                retstr = (char *)malloc(13);
                snprintf(retstr, 13, "%s", "Invalid movie");
            }
        }
        else
        {
            retstr = (char *)malloc(25);
            snprintf(retstr, 25, "%s", "Invalid movie controller");
        }
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
    
    *retstring = retstr;
    
//bail:
  //      retstr = calloc(1, 2);
    //if (retstr != NULL)
      //  retstr[0] = (myErr == noErr) ? '0': '1';
    //*retstring = retstr;
}


//
// Text Tracks
//


//
// qtAddTextTrack (MovieController, TrackName, Height, Width) - returns track index
//
// qtAddTextTrackSample (MovieController, TrackIdentifier, Text, StartTime, Duration)
//
void XCMD_AddTextTrack (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController 		mc = NULL;
    Movie 			myMovie = NULL;
    Track 			myTrack = NULL;
    MediaHandler		myHandler = NULL;
    TimeValue 			startTime = atol(args[2]);
    TimeValue			trackDuration = atol(args[3]);
    TimeScale			myTimeScale = 600;	// All samples default to 600
    char			*retstr = NULL;
    OSErr			myErr = noErr;
    
    *pass = false;
    *error = false;
    if (nargs == 4) {
        mc = (MovieController)atol(args[0]);
        if (mc != NULL && (long)mc > 0)
        {
            myMovie = MCGetMovie(mc);
            myTrack = QTUtils_CreateTrack (myMovie, FixRatio(200,1), FixRatio(kTextTrackHeight,1), kNoVolume);
            myHandler = QTText_AddTextSample (myMovie, myTrack, args[1], myTimeScale, startTime, trackDuration);
            myErr = QTText_SetTextTrackAsHREFTrack (myTrack, true);
            SetTrackEnabled(myTrack, false);
            
            if (retstr == NULL) {
                retstr = calloc(1, 2);
                if (retstr != NULL)
                    retstr[0] = (myHandler != NULL) ? '0': '1';
            }
        }
        else
        {
            retstr = (char *)malloc(28);
            snprintf(retstr, 28, "%s", "Invalid number of arguments");
        }
    }
    
    *retstring = retstr;
}


//
// qtCreateHREFTrack (MovieController, href url, starttime, duration)
// URLs look like A<URL> T<frame>
// starttime is a long in movie timescale
// duration is a long in movie timescale
//
void XCMD_CreateHREFTrack (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController 		mc = NULL;
    Movie 			myMovie = NULL;
    Track 			myTrack = NULL;
    MediaHandler		myHandler = NULL;
    TimeValue 			startTime = atol(args[2]);
    TimeValue			trackDuration = atol(args[3]);
    TimeScale			myTimeScale = 600;	// All samples default to 600
    char			*retstr = NULL;
    OSErr			myErr = noErr;

    *pass = false;
    *error = false;
    if (nargs == 4) {
        mc = (MovieController)atol(args[0]);
        if (mc != NULL && (long)mc > 0)
        {
            myMovie = MCGetMovie(mc);
            myTrack = QTUtils_CreateTrack (myMovie, FixRatio(200,1), FixRatio(kTextTrackHeight,1), kNoVolume);
            myHandler = QTText_AddTextSample (myMovie, myTrack, args[1], myTimeScale, startTime, trackDuration);
            myErr = QTText_SetTextTrackAsHREFTrack (myTrack, true);
            SetTrackEnabled(myTrack, false);

            if (retstr == NULL) {
                retstr = calloc(1, 2);
                if (retstr != NULL)
                    retstr[0] = (myHandler != NULL) ? '0': '1';
            }
        }
        else
        {
            retstr = (char *)malloc(28);
            snprintf(retstr, 28, "%s", "Invalid number of arguments");
        }
    }

    *retstring = retstr;
}


//
// qtCreateChapterTrack (MovieController, ChapterTrackIdentifier, ParentTrackIdentifier, Boolean)
//
// Creates a chapter track linked to the Track specified by ParentTrackIdentifier.
// Use qtAddChapterTrackSample() to add chapter entries.
//
void XCMD_SetTrackAsChapterTrack (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController 		mc = NULL;
    Movie 			mv = NULL;
    Track 			chapterTrack = NULL;
    Track                       parentTrack = NULL;
    Boolean                     setAsChapter = true;
    long                        chapterTrackIndex = 0;
    long                        parentTrackIndex = 0;
    OSErr                       myErr = noErr;
    char			*retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 4) {
        mc = (MovieController)atol(args[0]);
        chapterTrackIndex = atol(args[1]);
        parentTrackIndex = atol(args[2]);
        
        if (mc != NULL && (long)mc > 0)
        {
            mv = MCGetMovie(mc); 
            
            // If no track name or index was given then set index to 1
            if (chapterTrackIndex == 0 && strlen(args[1]) < 1)
                chapterTrackIndex = 1;
            if (parentTrackIndex == 0 && strlen(args[2]) < 1)
                parentTrackIndex = 1;
            
            ExtUtils_ToLowerCase(args[3]);
            
            if (strcmp(args[3], "false") == 0 || strcmp(args[3], "0") == 0)
                setAsChapter = false;
            
            // args[1] is a number search by track index, otherwise by name
            if (chapterTrackIndex > 0) 
                chapterTrack = GetMovieTrack(mv, chapterTrackIndex);
            else
                chapterTrack = QTUtils_GetTrackReferenceByName(mc, args[1]);
            // args[2] is a number search by track index, otherwise by name
            if (parentTrackIndex > 0) 
                parentTrack = GetMovieTrack(mv, parentTrackIndex);
            else
                parentTrack = QTUtils_GetTrackReferenceByName(mc, args[2]);
            
            if (setAsChapter == true)
                myErr = AddTrackReference(parentTrack, chapterTrack, kTrackReferenceChapterList, NULL);
            else
                myErr = DeleteTrackReference(parentTrack, kTrackReferenceChapterList, 1);
            
            if (retstr == NULL) {
                retstr = calloc(1, 2);
                if (retstr != NULL)
                    retstr[0] = (myErr != NULL) ? '0': '1';
            }
        }
        else
        {
            retstr = (char *)malloc(28);
            snprintf(retstr, 28, "%s", "Invalid number of arguments");
        }
    }
    
    *retstring = retstr;
}


//////////
// Image Functions
//////////

// qtGetMoviePicture ("imageVar", moviePath, height, width, Time, Poster, maintainAspectRatio)
// To get image data pass the name of a variable to put the data into in quotes.  To save to a path provide
// a path to save the file to.
void XCMD_GetMovieSnapShot (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    Movie				mv = NULL;
	TimeValue			theTime = 0;
	FSSpec				movieFSSpec;
	short				refnum = 0;
	int					retvalue = 0;
	Bool				usePoster = False;
	Bool				maintainAspectRatio = False;
	short				movieHeight = 0;
	short				movieWidth = 0;
	Ptr					imageAddress;
	long				imageLength;
	Rect				movieRect;
	
	MCstring			rdata;
	
	OSErr				result = noErr;
    char *				retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 7)
    {
		ExtUtils_Path2FSSpec(args[1], &movieFSSpec);
		movieHeight = atoi(args[2]);
		movieWidth = atoi(args[3]);
		theTime = (TimeValue)atol(args[4]);
		ExtUtils_ToLowerCase(args[5]);
		if (strcmp(args[5], "true") == 0 || strcmp(args[5], "1") == 0)
			usePoster = True;
		ExtUtils_ToLowerCase(args[6]);
		if (strcmp(args[6], "true") == 0 || strcmp(args[6], "1") == 0)
			maintainAspectRatio = True;
        
		result = OpenMovieFile(&movieFSSpec, &refnum, fsRdPerm);
			
		NewMovieFromFile(&mv, refnum, NULL, NULL, newMovieActive, NULL);
		
		if (mv != NULL)
		{
			GetMovieBox(mv, &movieRect);
			QTUtils_GetPixMapFromMovie (mv, &movieHeight, &movieWidth, theTime, usePoster, maintainAspectRatio, &imageAddress, &imageLength);
			if (imageLength > 0) {
				rdata.sptr = imageAddress;
				rdata.length = imageLength;
				
				// Set passed variable to imageData location of new image
				SetVariableEx(args[0], "", &rdata, &retvalue);
				
				// Return four items, orig height/width, new height/width
				retstr = malloc (36);
				snprintf (retstr, 36, "%d,%d,%d,%d", movieRect.right - movieRect.left, movieRect.bottom - movieRect.top, movieWidth, movieHeight);
			} else {
				retstr = (char *)malloc(8);
				snprintf(retstr, 8, "%s", "Failure");
			}
		
			CloseMovieFile(refnum);
			DisposeMovie(mv);
		}
		else
		{
			retstr = (char *)malloc(30);
			snprintf(retstr, 30, "%s", "Unable to get movie from file");
			
		}
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
	
	*retstring = retstr;
}


// qtSaveMovieSnapShotToFile movieInputPath, movieOutputPath, imageWidth, imageHeight, Time, Poster, MainTainAspectRatio, ExportFormat
// To get image data pass the name of a variable to put the data into in quotes.  To save to a path provide
// a path to save the file to.
//
// Export formats: gif, png, jpeg, photoshop, pict, tiff
void XCMD_SaveMovieSnapShotToFile (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    Movie				mv = NULL;
	TimeValue			theTime = 0;
	FSSpec				movieInputFSSpec;
	FSSpec				movieOutputFSSpec;
	short				refnum = 0;
	Bool				usePoster = False;
	Bool				maintainAspectRatio = False;
	short				movieHeight = 0;
	short				movieWidth = 0;
	Rect				movieRect;

	OSType				fileType;
	OSType				fileCreator = 0;
		
	OSErr				result = noErr;
    char *				retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 8)
    {
		ExtUtils_Path2FSSpec(args[0], &movieInputFSSpec);
		ExtUtils_Path2FSSpec(args[1], &movieOutputFSSpec);
		movieWidth = atoi(args[2]);
		movieHeight = atoi(args[3]);
		theTime = (TimeValue)atol(args[4]);
		ExtUtils_ToLowerCase(args[5]);
		if (strcmp(args[5], "true") == 0 || strcmp(args[5], "1") == 0)
			usePoster = True;
		ExtUtils_ToLowerCase(args[6]);
		if (strcmp(args[6], "true") == 0 || strcmp(args[6], "1") == 0)
			maintainAspectRatio = True;
		
		// Determine export format
		ExtUtils_ToLowerCase(args[7]);
		
		if (strcmp(args[7], "tiff") == 0) {
			fileType = kQTFileTypeTIFF;
		} else if (strcmp(args[7], "bmp") == 0) {
			fileType = kQTFileTypeBMP;
		} else if (strcmp(args[7], "png") == 0) {
			fileType = kQTFileTypePNG;
		} else if (strcmp(args[7], "gif") == 0) {
			fileType = kQTFileTypeGIF;
		} else if (strcmp(args[7], "pict") == 0) {
			fileType = kQTFileTypePicture;
		} else if (strcmp(args[7], "photoshop") == 0) {
			fileType = kQTFileTypePhotoShop;
		} else {
			fileType = kQTFileTypeJPEG;
		}
        
		result = OpenMovieFile(&movieInputFSSpec, &refnum, fsRdPerm);
			
		NewMovieFromFile(&mv, refnum, NULL, NULL, newMovieActive, NULL);
		
		if (mv != NULL)
		{
			GetMovieBox(mv, &movieRect);
			result = QTUtils_SaveMoviePicToFile (mv, &movieHeight, &movieWidth, theTime, usePoster, maintainAspectRatio, &movieOutputFSSpec, fileType, fileCreator);

			if (result == noErr) {
				// Return four items, orig height/width, new height/width
				// Right now each number can be 5 digits plus 3 commas.  Memmory should probably be 
				// dynamically allocated for this
				retstr = malloc (23);
				snprintf (retstr, 23, "%d,%d,%d,%d", movieRect.right - movieRect.left, movieRect.bottom - movieRect.top, movieWidth, movieHeight);
			} else {
				retstr = (char *)malloc(8);
				snprintf(retstr, 8, "%s", "Failure");
			}
		
			CloseMovieFile(refnum);
			DisposeMovie(mv);
		}
		else
		{
			retstr = (char *)malloc(30);
			snprintf(retstr, 30, "%s", "Unable to get movie from file");
			
		}
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
	
	*retstring = retstr;
}


// qtGetMovieDimensions
// Returns the width and height of the movie specified by the provided filename
//
void XCMD_GetMovieDimensions (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    Movie				mv = NULL;
	FSSpec				movieFSSpec;
	short				refnum = 0;
	Rect				movieRect;
		
    char *				retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 1)
    {
		ExtUtils_Path2FSSpec(args[0], &movieFSSpec);
        
		// Create movie instance from given filepath
		OpenMovieFile(&movieFSSpec, &refnum, fsRdPerm);
		NewMovieFromFile(&mv, refnum, NULL, NULL, newMovieActive, NULL);
		
		if (mv != NULL)
		{
			// Get and return movie dimensions
			GetMovieBox(mv, &movieRect);

			// Return four items, orig height/width, new height/width
			// Currently returns a width/height up to 5 digits each plus comma.
			// This should be dynamically assigned
			retstr = malloc (11);
			snprintf (retstr, 11, "%d,%d", movieRect.right - movieRect.left, movieRect.bottom - movieRect.top);
							
			CloseMovieFile(refnum);
			DisposeMovie(mv);
		}
		else
		{
			retstr = (char *)malloc(30);
			snprintf(retstr, 30, "%s", "Unable to get movie from file");
			
		}
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
	
	*retstring = retstr;
}


// qtFlipMovie
// Flips a movie matrix horizontally, vertically or restore
//
void XCMD_FlipMovie (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
    MovieController		mc = NULL;
	Movie				mv = NULL;
	short				flip = 0;
	MatrixRecord		movieMatrix;
	Rect				movieRect;
	ComponentResult		result = noErr;
		
    char *				retstr = NULL;
    
    *pass = false;
    *error = false;
    if (nargs == 2)
    {
		mc = (MovieController)atol(args[0]);
        ExtUtils_ToLowerCase(args[1]);
		
        if (mc != NULL && (long)mc > 0)
        {
			mv = MCGetMovie(mc);
			
			if (mv != NULL)
			{
				// Determine which event to trigger
				if (strcmp(args[1], "horizontal") == 0) {    
					flip = 1;
				} else if (strcmp(args[1], "vertical") == 0) {
					flip = 2;
				}
							
				// Get and return movie dimensions
				GetMovieMatrix(mv, &movieMatrix);
				MCGetControllerBoundsRect(mc, &movieRect);
				
				if (flip == 1) {
					// flip horizontal (around y axis)
					// negative x factor
					TranslateMatrix (&movieMatrix, Long2Fix(-movieRect.right), 0);
					ScaleMatrix (&movieMatrix, Long2Fix(-1), fixed1, movieRect.right - ((movieRect.right - movieRect.left) / 2), 
						movieRect.top + ((movieRect.bottom - movieRect.top) / 2));
					TranslateMatrix (&movieMatrix, Long2Fix(movieRect.left), 0);
					SetMovieMatrix(mv, &movieMatrix);
				} else if (flip == 2) {
					// flip vertical (around x axis)
					// negative y factor
					// For some reason we have to subtract the height of the controller whether it is visible or not. Tested Rev 2.2
					TranslateMatrix (&movieMatrix, 0, Long2Fix(-(movieRect.bottom - 16)));
					ScaleMatrix (&movieMatrix, fixed1, Long2Fix(-1), movieRect.right - ((movieRect.right - movieRect.left) / 2), 
						movieRect.top + ((movieRect.bottom - movieRect.top) / 2));
					TranslateMatrix (&movieMatrix, 0, Long2Fix(movieRect.top));
					SetMovieMatrix(mv, &movieMatrix);
				}
				
				if (retstr == NULL) {
					retstr = calloc(1, 2);
					if (retstr != NULL)
						retstr[0] = (result == noErr) ? '0': '1';
				}
			}
			else
			{
				retstr = (char *)malloc(30);
				snprintf(retstr, 30, "%s", "Unable to get movie from file");
				
			}
		} else {
			retstr = (char *)malloc(25);
            snprintf(retstr, 25, "%s", "Invalid movie controller");
		}
    }
    else
    {
        retstr = (char *)malloc(28);
        snprintf(retstr, 28, "%s", "Invalid number of arguments");
    }
	
	*retstring = retstr;
}


//////////
//
// abort function
//
//////////

void XCMD_Abort()
{
#ifdef __MWERKS__
    DebugStr("\pQuickTime Revolution External abort");
#else
    DebugStr("QuickTime Revolution External abort");
#endif // __MWERKS__
}


/********************
 * Internal QT Specific functions
 *
 * Used for sending messages to Revolution, etc.
 *
 ********************/


///////////////////
//
// Intermovie communication code
//
///////////////////


// testing that getting movie name works correctly
void XCMD_GetMovieName (char *args[], int nargs, char **retstring, Bool *pass, Bool *error)
{
#ifdef __MWERKS__
#pragma unused (nargs)
#endif // __MWERKS__
    MovieController mc = NULL;
    Movie myMovie = NULL;
    
    *pass = false;
    *error = false;
    mc = (MovieController)atol(args[0]);
    myMovie = MCGetMovie(mc);
    if (myMovie != NULL) {
        char		*myName = NULL;
        
        // get the target name of the current movie
        myName = QT_GetMovieTargetName(myMovie, -1);
        
        *retstring = malloc(strlen(myName) + 1);
        snprintf(*retstring, strlen(myName) + 1, "%s", myName);
        
        free(myName);
    }   
}


//////////
//
// Intercepts message whenever a text sample is loaded into a registered track
//
//////////
PASCAL_RTN OSErr QT_TextMediaTextSampleCallback (Handle theText, Movie theMovie, short *displayFlag, long refcon)
{
#ifdef __MWERKS__
#pragma unused (theMovie, displayFlag, refcon)
#endif // __MWERKS__

    char *				myTextPtr = NULL;
    short				myTextSize;
	short				fixedLen = 2048;
	char				sampleText[2049];
    short				myIndex;
    ComponentResult		result = noErr;

    // on entry to this function, theText is a handle to the text sample data,
    // which is a big-endian 16-bit length word followed by the text itself
	myTextSize = EndianU16_BtoN(*(short *)(*theText));
    myTextPtr = (char *)(*theText + sizeof(short));
	
	// Nobody wants a string that is too long
	if (myTextSize > fixedLen)
		myTextSize = fixedLen;

    // copy Pascal string in handle to C string
    for (myIndex = 0; myIndex < myTextSize; myIndex++, myTextPtr++)
		sampleText[myIndex] = *myTextPtr;
		
	sampleText[myIndex] = '\0';  //null terminate

    // Output to rev
	DispatchRevolutionMessageToObject(textCallbackTarget, textCallbackCommand, sampleText);
    
    return result;
}


//////////
//
// QT_MCActionFilterProcCallback 
// Intercept some actions for the movie controller.
//
// NOTE: The theRefCon parameter is the index of the player in the playerNameArray
//
//////////
PASCAL_RTN Boolean QT_MCActionFilterProcCallback (MovieController theMC, short theAction, void *theParams, long theRefCon)
{
    Boolean			isHandled = false;        // false => allow controller to process the action
    Movie			myMovie = NULL;
	QTDoScriptPtr   spCommandAndArgs;		// For use with Flash FSCommand
	char *			convertedString = NULL;

    switch (theAction) {
        // Intercept application number and string
        case mcActionExecuteOneActionForQTEvent:
            isHandled = (QT_ExecuteOneAction((ResolvedQTEventSpec*)theParams, theRefCon));
            break;
        // Handle DebugStr messages
        case mcActionShowMessageString:
			convertedString = QTUtils_ConvertPascalToCString ((StringPtr) theParams);
			
			DispatchRevolutionMessageToObject(playerNameArray[theRefCon], "QTDebugStr", convertedString);
			if (convertedString)
				free(convertedString);

			isHandled = true;
            
            break;
            // handle get-external-movie requests
        case mcActionGetExternalMovie:
            QT_FindExternalMovieTarget(theMC, (QTGetExternalMoviePtr)theParams);
            break;

        // return the name of this movie; theParams is a handle to a Pascal string
        // If the player has a tooltip name then use that.  Otherwise use the name embedded
        // in the movie
        case mcActionGetMovieName:
            myMovie = MCGetMovie(theMC);
        
            if (myMovie != NULL) {
                char *			myName = NULL;
                Handle          	myNameHandle = (Handle)theParams;
                
                // get the target name of the current movie
                myName = QT_GetMovieTargetName(myMovie, theRefCon);

                if ((myName != NULL) || (myNameHandle != NULL)) {
                    // reset the size of the handle passed to us to hold the movie target name
                    SetHandleSize(myNameHandle, strlen(myName + 1));
                    if (MemError() == noErr) {
                        // copy the movie target name into the resized handle
                        BlockMove(myName, *myNameHandle + 1, strlen(myName));
                        *myNameHandle[0] = strlen(myName);
                        isHandled = true;
                    }
                }

                free(myName);
            }
                    
            break;

        // return the ID of this movie; theParams is a pointer to a long
        case mcActionGetMovieID:            
            myMovie = MCGetMovie(theMC);
            if (myMovie != NULL) {
                long		myID;
                Boolean		myMovieHasID = false;

                // get the target name of the current movie
                myID = QT_GetMovieTargetID(myMovie, &myMovieHasID);
                if (myMovieHasID) {
                    *(long *)theParams = myID;
                    isHandled = true;
                }
            }

                break;

		// Process Flash fscommands
		case mcActionDoScript:			
			if (theParams != NULL) {
				spCommandAndArgs = (QTDoScriptPtr)theParams;
				DispatchRevMsgToObjWith2Params(playerNameArray[theRefCon], "FSCommand", spCommandAndArgs->command, spCommandAndArgs->arguments);
				//if (strcmp (spCommandAndArgs->command, "myCommand") == 0) {
					//...Do Something interesting here.
				//}
			}
			
			isHandled = true;
			break;

        default:
            break;

    } // switch (theAction)

    return(isHandled);
}


//
// Intercepts hot spots being clicked
//
PASCAL_RTN void QT_HotSpotClickedIntercept (QTVRInstance theQTVR, QTVRInterceptPtr theMsg, SInt32 theRefCon, Boolean *cancel)
{
#ifdef __MWERKS__
#pragma unused (theQTVR)
#endif // __MWERKS__

    Boolean				cancelInterceptedProc = false;
    char				message[256];
    
    switch (theMsg->selector) {
        case kQTVRTriggerHotSpotSelector:
			snprintf(message, 256, "%lu", (UInt32)theMsg->parameter[0]);
			DispatchRevolutionMessageToObject(playerNameArray[theRefCon], "hotspotClicked", message);
        default:
            break;
    }
	    
    *cancel = cancelInterceptedProc;
}


//
// Intercept mouse enter/mouse leave hotspots
PASCAL_RTN OSErr QT_MouseOverHotspotProcCallback (QTVRInstance theQTVR, UInt32 theHotSpotID, UInt32 theFlags, SInt32 theRefCon)
{
#ifdef __MWERKS__
#pragma unused (theQTVR)
#endif // __MWERKS__

	char			data[U4L];
	char *			message = NULL;
    OSErr			myErr = noErr;
	
	snprintf (data, U4L, "%lu", theHotSpotID);
    
    if (theFlags == kQTVRHotSpotEnter)
    {		
		message = malloc(15);
		message = "QTHotSpotEnter";
    }
    else if (theFlags == kQTVRHotSpotLeave)
    {
		message = malloc(15);
		message = "QTHotSpotLeave";
    }
	
	DispatchRevolutionMessageToObject(playerNameArray[theRefCon], message, data);
	
    return myErr;
}


//
// Sends the QTApplicationNumberAndString message to revolution
//
PASCAL_RTN void QT_ApplicationNumberAndString (QTAtomContainer container, QTAtom curParent, long theRefCon)
{
    long itsSize = 0;
    Ptr itsData;
    char *appNumber = NULL;
    char *appString = NULL;
    QTAtomType atomType = kWhichAction;
    QTAtom theChild = NULL;

    atomType = kActionParameter;

    // Get number (param 1)
    theChild = QTUtils_GetTypeAndData(container, curParent, atomType, 1, &itsSize, &itsData);
    if (theChild != 0)
    {
        appNumber = malloc(32);
        snprintf (appNumber, 32, "%ld", *(long *)itsData);
    }

    // Get string (param 2)
    theChild = QTUtils_GetTypeAndData (container, curParent, atomType, 2, &itsSize, &itsData);
    if (theChild != 0)
    {
         appString = QTUtils_ConvertPascalToCString((StringPtr)itsData);
    }

	DispatchRevMsgToObjWith2Params(playerNameArray[theRefCon], "QTApplicationNumberAndString", appNumber, appString);

	if (appNumber)
		free(appNumber);
	if (appString)
		free(appString);
}


// Checks for certain actions such as ApplicationNumberAndString to pass on to the player
PASCAL_RTN Boolean QT_ExecuteOneAction(ResolvedQTEventSpec *theSpec, long theRefCon)
{
    Boolean actionHandled = false;

    if (theSpec->actionAtom.container == NULL)
        return actionHandled;
    
    if (QTUtils_CheckActionAtom(theSpec->actionAtom.container, theSpec->actionAtom.atom, kActionApplicationNumberAndString))
    {
        QT_ApplicationNumberAndString(theSpec->actionAtom.container, theSpec->actionAtom.atom, theRefCon);
        actionHandled = true;
    }

    return actionHandled;
}


//
// QT Intermovie Communication functions
// Functions required for intermovie communication support
//

//////////
//
// QT_FindUserDataItemWithPrefix
// Return the index of the user data item of the specified type whose data begins with the specified string of characters.
//
//////////
static long QT_FindUserDataItemWithPrefix (UserData theUserData, OSType theType, char *thePrefix)
{
    Handle			myData = NULL;
    long			myCount = 0;
    long			myIndex = 0;
    long			myItemIndex = 0;
    OSErr			myErr = noErr;
    // make sure we've got some valid user data
    if (theUserData == NULL)
        goto bail;
    // allocate a handle for GetUserData
    myData = NewHandle(0);
    if (myData == NULL)
        goto bail;
    myCount = CountUserDataType(theUserData, theType);
    for (myIndex = 1; myIndex <= myCount; myIndex++) {
        myErr = GetUserData(theUserData, myData, theType, myIndex);
        if (myErr == noErr) {
            if (GetHandleSize(myData) < strlen(thePrefix))
                continue;
            // see if the user data begins with the specified prefix (IdenticalText is case-insensitive)
            if (IdenticalText(*myData, thePrefix, strlen(thePrefix), strlen(thePrefix), NULL) == 0) {
                myItemIndex = myIndex;
                goto bail;
            }
        }
    }
bail:
        if (myData != NULL)
            DisposeHandle(myData);
    return(myItemIndex);
}


//////////
//
// QT_GetUserDataPrefixedValue
// Return the string value associated with the specified prefix. The string value may or may not be
// enclosed in double quotes, so we need to handle both cases. (With double quotes is preferred.)
//
// The caller is responsible for disposing of the pointer returned by this function (by calling free).
//
//////////
static char *QT_GetUserDataPrefixedValue (UserData theUserData, OSType theType, char *thePrefix)
{
    long			myIndex = 0;
    Handle			myData = NULL;
    long			myLength = 0;
    long			myOffset = 0;
    char 			*myString = NULL;
    OSErr			myErr = noErr;
    if (theUserData == NULL)
        goto bail;
    // allocate a handle for GetUserData
    myData = NewHandle(0);
    if (myData == NULL)
        goto bail;
    myIndex = QT_FindUserDataItemWithPrefix(theUserData, theType, thePrefix);
    if (myIndex > 0) {
        myErr = GetUserData(theUserData, myData, theType, myIndex);
        if (myErr == noErr) {
            if ((*myData)[strlen(thePrefix)] == '"') {
                myLength = GetHandleSize(myData) - strlen(thePrefix) - 2;
                myOffset = 1;
            } else {
                myLength = GetHandleSize(myData) - strlen(thePrefix);
                myOffset = 0;
            }
            myString = malloc(myLength + 1);
            if (myString != NULL) {
                memcpy(myString, *myData + strlen(thePrefix) + myOffset, myLength);
                myString[myLength] = '\0';
            }
        }
    }
bail:
        if (myData != NULL)
            DisposeHandle(myData);
    return(myString);
}


//////////
//
// QT_FindExternalMovieTarget
// Find the external movie targeted by theEMRecPtr.
//
//////////
void QT_FindExternalMovieTarget (MovieController theMC, QTGetExternalMoviePtr theEMRecPtr)
{
#if ALLOW_SELF_TARGETING
#pragma unused(theMC)
#endif
    Movie                       myTargetMovie = NULL;
    MovieController             myTargetMC = NULL;
    Boolean                     myFoundIt = false;
    int                         x = 0;

    /*char buffer[256];
    char buffer2[256];
    char *value = NULL;
    int retvalue = 0;
    int retvalue2 = 0;
    char *value2 = NULL;
    */

    if (theEMRecPtr == NULL)
        return;

    // loop through the number of controllers registered with the external
    // looking for the one with the id we want.
    // NOTE: Ideally this wouldn't need to have the controllers registered but I don't
    // know how to loop through all the controllers in a Revolution window.
    for (x = 0; x < totalMovieControllers; ++x)
    {
        Movie				myMovie = NULL; 
        MovieController                 myMC = NULL;

        myMC = movieControllerArray[x];

#if ALLOW_SELF_TARGETING
        if (myMC != NULL) { 
#else
            if ((myMC != NULL) && (myMC != theMC)) { 
#endif
                myMovie = MCGetMovie(myMC); 

                if (theEMRecPtr->targetType == kTargetMovieName) {                    
                    char 		*myStr = NULL;               

                    myStr = QT_GetMovieTargetName(myMovie, x);
                    if (myStr != NULL) {
                        if (IdenticalText(&theEMRecPtr->movieName[1], myStr, theEMRecPtr->movieName[0], strlen(myStr), NULL) == 0)
                            myFoundIt = true;
                        free(myStr);
                    }
                }

                if (theEMRecPtr->targetType == kTargetMovieID) {
                    long		myID = 0;
                    Boolean		myMovieHasID = false;

                    myID = QT_GetMovieTargetID(myMovie, &myMovieHasID);
                    if ((theEMRecPtr->movieID == myID) && myMovieHasID)
                        myFoundIt = true;
                }

                if (myFoundIt) {
                    myTargetMovie = myMovie;
                    myTargetMC = myMC;
                    break;		// break out of for loop
                }
            }
        }	// for

        *theEMRecPtr->theMovie = myTargetMovie;
        *theEMRecPtr->theController = myTargetMC;
    }


//////////
//
// QT_GetMovieTargetName
// Get the movie target name stored in the specified movie.
//
// The caller is responsible for disposing of the pointer returned by this function (by calling free).
//
//////////
char *QT_GetMovieTargetName (Movie theMovie, int movieArrayIndex)
{
    UserData		myUserData = NULL;
    char                *myString = NULL;
   int storedNameLength = 0;

    // make sure we've got a movie
    if (theMovie == NULL)
        goto bail;
    
   // validate index passed -- it's -1 at least one place
   if ((movieArrayIndex >= 0) && (movieArrayIndex <= (totalMovieControllers + 1)))
      if (NULL != movieNameArray[movieArrayIndex])
         storedNameLength = strlen(movieNameArray[movieArrayIndex]);
		
	if (storedNameLength > 0) {
	   // I don't think we should return this directly, we should copy it ...alex
		//myString = movieNameArray[movieArrayIndex];
		myString = malloc(storedNameLength + 1);
		strncpy(myString, movieNameArray[movieArrayIndex], storedNameLength + 1);
	}
	else
	{
		// get the movie's user data list
		myUserData = GetMovieUserData(theMovie);
		if (myUserData == NULL)
			goto bail;
			
		// find the "value" of the user data item of type 'plug' that begins with the string "moviename="
		myString = QT_GetUserDataPrefixedValue(myUserData, FOUR_CHAR_CODE('plug'), kMovieNamePrefix);
	}
bail:
        return(myString);
}


//////////
//
// QT_GetMovieTargetID
// Get the movie target ID stored in the specified movie.
//
//////////
long QT_GetMovieTargetID (Movie theMovie, Boolean *theMovieHasID)
{
    UserData		myUserData = NULL;
    long			   myID = 0;
    char 			*myString = NULL;
    StringPtr 		myPString = NULL;
    Boolean			myMovieHasID = false;
    //OSErr			myErr = noErr;
    // make sure we've got a movie
    if (theMovie == NULL)
        goto bail;
        
    // get the movie's user data list
    myUserData = GetMovieUserData(theMovie);
    if (myUserData == NULL)
        goto bail;
    // find the "value" of the user data item of type 'plug' that begins with the string "movieid="
    myString = QT_GetUserDataPrefixedValue (myUserData, FOUR_CHAR_CODE('plug'), kMovieIDPrefix);
    // convert the string into a number
    if (myString != NULL) {
        myPString = QTUtils_ConvertCToPascalString(myString);
        StringToNum(myPString, &myID);
        myMovieHasID = true;
    }
bail:
    if (myString)
      free(myString);
    if (myPString)
       free(myPString);
    if (theMovieHasID != NULL)
        *theMovieHasID = myMovieHasID;
    return(myID);
}