/* GetDriveType.h

   externals for Runtime Revolution

   created by External Builder on 1/17/04
   for Mark Wieder
*/

extern void XCabort();
extern char Xname[];
extern Xternal Xtable[];

extern void revGetDriveType(char *args[], int nargs, char **retstring, Bool *pass, Bool *error);
